"""Typed recipe build and image-import request/result wire contracts."""

from __future__ import annotations

import ipaddress
from typing import Annotated, Literal

from pydantic import Field, StringConstraints, model_validator

from .wire_model import WireModel

Digest = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{64}$")]
OciDigest = Annotated[str, StringConstraints(pattern=r"^sha256:[0-9a-f]{64}$")]
UuidId = Annotated[
    str,
    StringConstraints(
        pattern=r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
    ),
]
NodeId = Annotated[str, StringConstraints(pattern=r"^spk_[0-9a-f]{32}$")]


class RecipeBuildCleanupRequest(WireModel):
    """Stop only the transient service belonging to one retained build attempt."""

    build_id: UuidId
    operation_id: UuidId


class RecipeBuildCleanupEvidence(WireModel):
    """The build service is stopped; the fenced attempt is the whole answer."""


BuildArgumentName = Annotated[
    str,
    StringConstraints(min_length=1, max_length=64, pattern=r"^[a-z][a-z0-9._-]{0,63}$"),
]
EnvironmentName = Annotated[
    str,
    StringConstraints(min_length=1, max_length=128, pattern=r"^[A-Z][A-Z0-9_]{0,127}$"),
]
MetadataName = Annotated[
    str,
    StringConstraints(
        min_length=1, max_length=128, pattern=r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,127}$"
    ),
]
OsFeature = Annotated[
    str, StringConstraints(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._-]+$")
]
OsVersion = Annotated[
    str, StringConstraints(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._+-]+$")
]
_CAPABILITIES = {
    "CHOWN",
    "DAC_OVERRIDE",
    "FOWNER",
    "FSETID",
    "KILL",
    "MKNOD",
    "NET_BIND_SERVICE",
    "SETFCAP",
    "SETGID",
    "SETPCAP",
    "SETUID",
}


def _bundle_path(value: str) -> bool:
    return (
        bool(value)
        and not value.startswith("/")
        and "\\" not in value
        and "\x00" not in value
        and all(part not in {"", ".", ".."} for part in value.split("/"))
    )


def _pinned_image(reference: str, manifest_digest: str) -> bool:
    name, separator, digest = reference.rpartition("@")
    return bool(
        separator
        and name
        and len(name) <= 512
        and digest == manifest_digest
        and name[0].isalnum()
        and all(
            char.isascii() and (char.islower() or char.isdigit() or char in "._:/-")
            for char in name
        )
    )


def _public_host(value: str) -> bool:
    lowered = value.lower()
    if not value or len(value) > 253 or value.startswith(".") or value.endswith("."):
        return False
    if lowered in {
        "localhost",
        "localhost.localdomain",
        "metadata",
        "metadata.google.internal",
        "instance-data.ec2.internal",
    } or lowered.endswith((".localhost", ".localdomain", ".internal")):
        return False
    if not all(char.isascii() and (char.isalnum() or char in ".-") for char in value):
        return False
    if all(char.isdigit() or char == "." for char in value):
        try:
            address = ipaddress.ip_address(value)
        except ValueError:
            return False
        if not isinstance(address, ipaddress.IPv4Address):
            return True
        first, second = address.packed[:2]
        return (
            first not in {0, 10, 127, 169, 192, 198, 224}
            and not (first == 100 and 64 <= second <= 127)
            and not (first == 172 and 16 <= second <= 31)
            and not (first == 169 and second == 254)
            and not (first == 192 and second == 168)
            and not (first == 198 and 18 <= second <= 19)
        )
    return True


def _validate_options(options: RecipeBuildOptions) -> None:
    contexts = [item.name for item in options.additional_contexts]
    if len(set(contexts)) != len(contexts) or any(
        not _bundle_path(item.path) for item in options.additional_contexts
    ):
        raise ValueError("additional build contexts are invalid")
    for entries in (options.annotations, options.labels, options.layer_labels):
        names = [item.name for item in entries]
        if len(set(names)) != len(names):
            raise ValueError("build metadata is invalid")
    environment = [item.name for item in options.environment]
    if len(set(environment)) != len(environment):
        raise ValueError("build environment is invalid")
    if options.ignorefile is not None and not _bundle_path(options.ignorefile):
        raise ValueError("build ignorefile is invalid")
    if len(set(options.os_features)) != len(options.os_features):
        raise ValueError("build OS features are invalid")
    if len(set(options.unset_environment)) != len(options.unset_environment):
        raise ValueError("build unset environment is invalid")
    if len(set(options.unset_labels)) != len(options.unset_labels):
        raise ValueError("build unset labels are invalid")


# The Rust producer accepts JSON strings, booleans, and integral numbers for
# build environment values.  Keeping this union strict prevents Pydantic from
# turning JSON floats/nulls into an accepted value.
JsonScalar = (
    Annotated[str, StringConstraints(max_length=1024)]
    | Annotated[int, Field(strict=True, ge=-(2**63), le=2**63 - 1)]
    | bool
)


class RecipeBuildEnvironmentArgument(WireModel):
    name: EnvironmentName
    value: JsonScalar


class RecipeBuildBaseImage(WireModel):
    manifest_digest: OciDigest
    reference: str = Field(min_length=1, max_length=512)


class RecipeBuildNetwork(WireModel):
    """Public hosts the build may reach; an empty list builds offline."""

    hosts: list[str] = Field(max_length=64)


class RecipeBuildAdditionalContext(WireModel):
    name: BuildArgumentName
    path: str = Field(min_length=1, max_length=512)


class RecipeBuildMetadata(WireModel):
    name: MetadataName
    value: Annotated[str, StringConstraints(max_length=1024, pattern=r"^[^\x00]*$")]


class RecipeBuildOptions(WireModel):
    additional_contexts: list[RecipeBuildAdditionalContext] = Field(max_length=16)
    annotations: list[RecipeBuildMetadata] = Field(max_length=64)
    environment: list[RecipeBuildEnvironmentArgument] = Field(max_length=64)
    format: Literal["oci", "docker"]
    identity_label: bool
    ignorefile: str | None = Field(default=None, max_length=512)
    jobs: int = Field(ge=1, le=32)
    labels: list[RecipeBuildMetadata] = Field(max_length=64)
    layer_compression: Literal["disabled", "gzip"]
    layer_labels: list[RecipeBuildMetadata] = Field(max_length=64)
    layers: bool
    no_hostname: bool
    no_hosts: bool
    omit_history: bool
    os_features: list[OsFeature] = Field(max_length=32)
    os_version: OsVersion | None = None
    shm_bytes: int = Field(ge=65_536, le=16 * 1024**4)
    skip_unused_stages: bool
    squash: Literal["none", "new", "all"]
    timestamp: int | None = Field(default=None, ge=0, le=4_102_444_800)
    unset_environment: list[EnvironmentName] = Field(max_length=64)
    unset_labels: list[MetadataName] = Field(max_length=64)


class RecipeBuildAdapterDefinition(WireModel):
    """One reviewed, digest-identified platform adaptation of a built image.

    The recipe Dockerfile owns the pinned upstream runtime, compilation, model
    patches and engine arguments.  The platform owns the final Vonk contract
    layered on top of that built image: the ``ai.vonkforge.runtime-interface``
    label, the canonical ``/opt/vonk/bin/<engine>`` launcher and the runtime
    user/ownership.  Hosting that in one reviewed adapter instead of recipe
    boilerplate requires an identity that changes when the adaptation changes,
    so this definition -- not the compatible ``v1`` label -- is what the digest
    covers.  ``containerfile`` is the rendered, ordered adaptation stage and is
    the only content the builder executes.
    """

    adapter_id: str = Field(pattern=r"^[a-z0-9][a-z0-9._-]{0,127}$")
    containerfile: str = Field(min_length=1, max_length=65_536)
    engine: str = Field(pattern=r"^[a-z0-9][a-z0-9-]{1,62}$")
    image_user: str = Field(pattern=r"^[1-9][0-9]*(:[1-9][0-9]*)?$")

    @model_validator(mode="after")
    def containerfile_is_bounded_text(self) -> RecipeBuildAdapterDefinition:
        if "\x00" in self.containerfile:
            raise ValueError("adapter content must not contain NUL")
        if "VONK_RECIPE_IMAGE" not in self.containerfile:
            raise ValueError("adapter must build from the recipe image argument")
        return self


class RecipeBuildAdapter(WireModel):
    """The adaptation stage applied after the recipe image is built.

    ``adapter_sha256`` is the canonical digest of ``definition``.  The agent
    re-derives it from the received definition and refuses to adapt when they
    disagree, so a Controller/agent drift cannot silently install a different
    adaptation than the one the prepared-image identity recorded.
    """

    adapter_sha256: Digest
    definition: RecipeBuildAdapterDefinition


class RecipeBuildLimits(WireModel):
    """Resource limits; builds never get a GPU, privileges, host mounts or a
    container socket."""

    cpu_cores: int = Field(ge=1, le=256)
    memory_bytes: int = Field(gt=0, le=16 * 1024**4)
    output_bytes: int = Field(gt=0, le=16 * 1024**4)
    processes: int = Field(ge=1, le=65_535)
    temporary_bytes: int = Field(gt=0, le=16 * 1024**4)
    timeout_seconds: int = Field(ge=1, le=86_400)


class RecipeBuildRequest(WireModel):
    """Build one recipe image for linux/arm64."""

    adapter: RecipeBuildAdapter
    base_image_storage_bytes: int = Field(ge=0, le=16 * 1024**4)
    base_images: list[RecipeBuildBaseImage] = Field(max_length=8)
    capabilities: list[str] = Field(max_length=11)
    build_id: UuidId
    build_input_sha256: Digest = Field(pattern=r"^[0-9a-f]{64}$")
    dockerfile: str = Field(min_length=1, max_length=512)
    limits: RecipeBuildLimits
    network: RecipeBuildNetwork
    options: RecipeBuildOptions
    recipe_content_sha256: Digest = Field(pattern=r"^[0-9a-f]{64}$")
    recipe_revision_id: UuidId
    source_bundle_bytes: int = Field(ge=1, le=64 * 1024**2)
    source_bundle_sha256: Digest = Field(pattern=r"^[0-9a-f]{64}$")

    @model_validator(mode="after")
    def validate_execution_policy(self) -> RecipeBuildRequest:
        if not _bundle_path(self.dockerfile):
            raise ValueError("build Dockerfile path is invalid")
        if any(capability not in _CAPABILITIES for capability in self.capabilities):
            raise ValueError("capabilities are not allowed")
        if (
            len(set(self.capabilities)) != len(self.capabilities)
            or (not self.base_images and self.base_image_storage_bytes != 0)
            or (
                self.base_images
                and not 1 <= self.base_image_storage_bytes <= 16 * 1024**4
            )
        ):
            raise ValueError("build identity or capability policy is invalid")
        references = [item.reference for item in self.base_images]
        if len(set(references)) != len(references) or any(
            not _pinned_image(item.reference, item.manifest_digest)
            for item in self.base_images
        ):
            raise ValueError("build base image pinning is invalid")
        if len(set(self.network.hosts)) != len(self.network.hosts) or any(
            not _public_host(host) for host in self.network.hosts
        ):
            raise ValueError("public build network hosts are invalid")
        _validate_options(self.options)
        return self


class RecipeBuildEvidence(WireModel):
    image_bytes: int = Field(gt=0, le=16 * 1024**4)
    image_digest: OciDigest = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    oci_layout_sha256: Digest = Field(pattern=r"^[0-9a-f]{64}$")


class RecipeImageImportRequest(WireModel):
    build_id: UuidId
    image_bytes: int = Field(gt=0, le=16 * 1024**4)
    image_digest: OciDigest = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    mapping_generation: int = Field(ge=1)
    mapping_id: UuidId
    oci_layout_sha256: Digest = Field(pattern=r"^[0-9a-f]{64}$")
    source_node_id: NodeId


class RecipeImageImportEvidence(WireModel):
    """The image is imported; the Controller already holds its identity."""
