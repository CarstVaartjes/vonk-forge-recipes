from __future__ import annotations

import ipaddress
import json
import re
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import fields, is_dataclass
from datetime import UTC, datetime
from enum import StrEnum
from types import MappingProxyType
from typing import Annotated, Any, Literal
from urllib.parse import parse_qsl, urlsplit
from uuid import UUID

from jsonschema import Draft202012Validator, FormatChecker
from pydantic import (
    BaseModel,
    Field,
    RootModel,
    TypeAdapter,
    ValidationError,
    model_validator,
)

from .failure_evidence import FailureDiagnostics
from .wire_model import ErrorCode, OperationProgress, WireModel

# Backstop above a full 4096-object distribution assignment (~0.5 MiB); the
# real GLM shape is ~18 KiB, only 3x under the previous 64 KiB.
MAX_DOCUMENT_BYTES = 2 * 1024 * 1024
MAX_COMPILED_EXECUTION_PLAN_DOCUMENT_BYTES = 16 * 1024 * 1024
MAX_COMPILED_EXECUTION_PLAN_CLAIM_BYTES = (
    MAX_COMPILED_EXECUTION_PLAN_DOCUMENT_BYTES + MAX_DOCUMENT_BYTES
)
DIGEST = re.compile(r"[0-9a-f]{64}\Z")
VERSIONED_PLATFORM_TARGET = re.compile(
    r"platform/releases/"
    r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)/"
    r"[0-9a-f]{64}\.json\Z"
)
UNSAFE_KEY = re.compile(
    r"password|secret|token|authorization|private.?key|command|shell|environment",
    re.IGNORECASE,
)
MODEL_REVISION = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64}|sha256:[0-9a-f]{64})\Z")
MODEL_REPOSITORY = re.compile(
    r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}"
    r"(?:/[A-Za-z0-9][A-Za-z0-9._-]{0,127}){1,7}\Z"
)
MODEL_QUERY_COMPONENT = re.compile(r"[A-Za-z0-9._~-]{1,128}\Z")
PINNED_OCI_IMAGE = re.compile(r"[a-z0-9][a-z0-9._:/-]{0,511}@sha256:[0-9a-f]{64}\Z")


def _ascii_case_pattern(token: str, *, initial_upper: bool = False) -> str:
    prefix = token[0].upper() if initial_upper else f"[{token[0].upper()}{token[0]}]"
    return prefix + "".join(
        f"[{character.upper()}{character}]" for character in token[1:]
    )


PATH_KEY_TOKENS = ("path", "file", "filename", "filepath", "directory", "folder")
PATH_KEY_ANY_CASE = "|".join(_ascii_case_pattern(token) for token in PATH_KEY_TOKENS)
PATH_KEY_CAMEL_CASE = "|".join(
    _ascii_case_pattern(token, initial_upper=True) for token in PATH_KEY_TOKENS
)
# A forbidden term starts at the key edge, after '_'/'-', or as an uppercase
# term after lowercase/digit. It ends at the key edge, before '_'/'-', or
# before an uppercase continuation. Matching inside each term is ASCII
# case-insensitive; a lowercase continuation such as "pathology" remains safe.
PATH_KEY = re.compile(
    rf"(?:^|[_-])(?:{PATH_KEY_ANY_CASE})(?:$|[_-]|[A-Z])"
    rf"|[a-z0-9](?:{PATH_KEY_CAMEL_CASE})(?:$|[_-]|[A-Z])"
)
UNSAFE_SCHEMA_KEY_PATTERN = (
    r"[Pp][Aa][Ss][Ss][Ww][Oo][Rr][Dd]|"
    r"[Ss][Ee][Cc][Rr][Ee][Tt]|[Tt][Oo][Kk][Ee][Nn]|"
    r"[Aa][Uu][Tt][Hh][Oo][Rr][Ii][Zz][Aa][Tt][Ii][Oo][Nn]|"
    r"[Pp][Rr][Ii][Vv][Aa][Tt][Ee].?[Kk][Ee][Yy]|"
    r"[Cc][Oo][Mm][Mm][Aa][Nn][Dd]|[Ss][Hh][Ee][Ll][Ll]|"
    r"[Ee][Nn][Vv][Ii][Rr][Oo][Nn][Mm][Ee][Nn][Tt]"
)
AGENT_PACKAGE_URL = re.compile(
    r"https://install\.vonkforge\.ai/"
    r"[A-Za-z0-9._~!$&'()*+,;=:%/-]{1,1900}/vonk-forge-agent\.deb\Z"
)


class AgentProtocolError(ValueError):
    """A protocol message is invalid or outside the agent trust boundary."""


_UUID_PATTERN = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
CanonicalUUID = Annotated[
    str,
    Field(
        strict=True,
        min_length=36,
        max_length=36,
        pattern=_UUID_PATTERN,
        json_schema_extra={"format": "uuid"},
    ),
]
DigestText = Annotated[
    str,
    Field(strict=True, pattern=r"^[0-9a-f]{64}$"),
]


class AgentOperation(StrEnum):
    RUNTIME_PREFLIGHT = "runtime.preflight.v1"
    AGENT_UPGRADE = "agent.upgrade.v1"
    ARTIFACT_DISTRIBUTION = "artifact.distribution.v1"
    RECIPE_BUILD = "recipe.build.v1"
    RECIPE_BUILD_CLEANUP = "recipe.build.cleanup.v1"
    RECIPE_IMAGE_IMPORT = "recipe.image.import.v1"
    RECIPE_INSTALL = "recipe.install"
    RECIPE_START = "recipe.start"
    RECIPE_JOB_RUN = "recipe.job.run.v1"
    RECIPE_STOP = "recipe.stop"
    RECIPE_UNINSTALL = "recipe.uninstall"
    RECIPE_RECONCILE = "recipe.reconcile"


class ArtifactDistributionPayload(WireModel):
    """The complete payload accepted by the artifact transfer operation."""

    plan_digest: str = Field(pattern=r"^[0-9a-f]{64}$")


from .package_upgrade import PackageActivationReceipt, PackageRollbackAuthority


class AgentUpgradePayload(WireModel):
    """Signed package authority for the current agent upgrade operation."""

    rollback: PackageRollbackAuthority
    source_package_url: str = Field(
        pattern=r"^https://install\.vonkforge\.ai/[A-Za-z0-9._~!$&'()*+,;=:%/-]{1,1900}/vonk-forge-agent\.deb$"
    )
    source_package_bytes: int = Field(strict=True, ge=1, le=1024**3)
    architecture: Literal["linux-arm64"]
    package_bytes: int = Field(strict=True, ge=1, le=1024**3)
    package_sha256: DigestText
    package_signature: Annotated[str, Field(pattern=r"^[0-9a-f]{128}$")]
    package_url: Annotated[
        str,
        Field(
            pattern=r"^https://install\.vonkforge\.ai/[A-Za-z0-9._~!$&'()*+,;=:%/-]{1,1900}/vonk-forge-agent\.deb$"
        ),
    ]
    package_version: Annotated[
        str, Field(pattern=r"^[0-9A-Za-z][0-9A-Za-z.+~-]{0,127}$")
    ]
    schema_version: Literal[1]
    target_binary_digest: DigestText
    target_build_digest: Annotated[str, Field(pattern=r"^sha256:[0-9a-f]{64}$")]


class AgentInstallResult(WireModel):
    installed_bytes: int = Field(strict=True, ge=0, le=16 * 1024**4)


class AgentUpgradeResult(WireModel):
    """Evidence emitted after the Rust agent reports an exact upgrade."""

    architecture: Literal["linux-arm64"]
    binary_digest: DigestText
    build_digest: Annotated[str, Field(pattern=r"^sha256:[0-9a-f]{64}$")]
    package_sha256: DigestText
    package_version: Annotated[
        str, Field(pattern=r"^[0-9A-Za-z][0-9A-Za-z.+~-]{0,127}$")
    ]
    status: Literal["upgraded"]
    activation_receipt: PackageActivationReceipt


class RecipeStartResult(WireModel):
    """The serving rank reports its endpoint; every other rank reports ``{}``."""

    endpoint: str | None = None


class ArtifactDistributionResult(WireModel):
    downloaded_bytes: int = Field(strict=True, ge=0, le=16 * 1024**4)


class AgentFailureKind(StrEnum):
    TEMPORARY_DEPENDENCY = "temporary-dependency"
    UNCERTAIN_EFFECT = "uncertain-effect"
    INVALID_AUTHORITY = "invalid-authority"
    INVALID_CONTRACT = "invalid-contract"
    INTEGRITY_FAILURE = "integrity-failure"
    RESOURCE_PREREQUISITE = "resource-prerequisite"


class AgentFailureResult(WireModel):
    failure_kind: AgentFailureKind | None = None
    retry_after_seconds: int | None = Field(
        default=None, strict=True, ge=0, le=2**32 - 1
    )
    diagnostics: FailureDiagnostics | None = None
    package_activation: PackageActivationReceipt | None = None
    reason: str | None = Field(default=None, min_length=1, max_length=1024)
    error_code: ErrorCode | None = None
    summary: str | None = Field(default=None, min_length=1, max_length=1024)
    uncertain: bool | None = None
    recovery: str | None = Field(default=None, min_length=1, max_length=128)
    status: Literal["failed"] | None = None
    operation: AgentOperation | None = None
    stage: str | None = Field(default=None, min_length=1, max_length=128)
    diagnostic: str | None = Field(default=None, min_length=1, max_length=512)
    helper_error_code: str | None = Field(default=None, min_length=1, max_length=128)
    helper_exit_code: int | None = Field(default=None, strict=True, ge=0, le=255)

    @model_validator(mode="after")
    def requires_failure_identity(self) -> AgentFailureResult:
        if self.reason is None and self.error_code is None:
            raise ValueError("failure result requires reason or error_code")
        return self


PROTOCOL_FORMAT_CHECKER = FormatChecker()


@PROTOCOL_FORMAT_CHECKER.checks("date-time")
def _is_utc_date_time(value: Any) -> bool:
    if not isinstance(value, str):
        return True
    try:
        deadline = datetime.fromisoformat(value)
    except ValueError:
        return False
    return deadline.tzinfo is not None and deadline.utcoffset() == UTC.utcoffset(
        deadline
    )


def canonical_message(value: Any) -> bytes:
    """Encode a protocol value with deterministic UTF-8 JSON."""
    try:
        return json.dumps(
            _to_wire(value),
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as error:
        raise AgentProtocolError("message must contain JSON values") from error


def _model_field_to_wire(original: Any, serialized: Any) -> Any:
    """Retain nested model metadata after Pydantic applies field serializers."""
    if isinstance(original, RootModel):
        return _model_field_to_wire(original.root, serialized)
    if isinstance(original, BaseModel) and isinstance(serialized, Mapping):
        return _model_to_wire(original, serialized)
    if isinstance(original, Mapping) and isinstance(serialized, Mapping):
        return {
            str(key): _model_field_to_wire(original[key], item)
            for key, item in serialized.items()
        }
    if isinstance(original, (tuple, list)) and isinstance(serialized, (tuple, list)):
        return [
            _model_field_to_wire(source, item)
            for source, item in zip(original, serialized, strict=True)
        ]
    return _to_wire(serialized)


def _model_to_wire(value: BaseModel, document: Mapping[str, Any]) -> dict[str, Any]:
    fields = {
        (field.serialization_alias or name)
        if value.model_config.get("serialize_by_alias", False)
        else name: (name, field)
        for name, field in type(value).model_fields.items()
    }
    result = {}
    for name, item in document.items():
        declared = fields.get(name)
        if declared is not None:
            attribute, field = declared
            if not field.is_required() and field.default is None and item is None:
                continue
            result[name] = _model_field_to_wire(getattr(value, attribute), item)
        else:
            # Declared extension data has its own meaning; null is not absence.
            result[name] = _to_wire(item)
    return result


def _to_wire(value: Any) -> Any:
    if isinstance(value, RootModel):
        return _model_field_to_wire(value.root, value.model_dump(mode="json"))
    if isinstance(value, BaseModel):
        return _model_to_wire(value, value.model_dump(mode="json"))
    if isinstance(value, StrEnum):
        return value.value
    if isinstance(value, datetime):
        return value.isoformat()
    if is_dataclass(value) and not isinstance(value, type):
        return {
            field.name: _to_wire(getattr(value, field.name)) for field in fields(value)
        }
    if isinstance(value, Mapping):
        return {str(key): _to_wire(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_to_wire(item) for item in value]
    return value


def _canonical_copy(value: Any, *, name: str) -> Any:
    try:
        copied = json.loads(canonical_message(value))
    except AgentProtocolError as error:
        raise AgentProtocolError(f"{name} must be JSON") from error
    return _freeze(copied)


def _freeze(value: Any) -> Any:
    if isinstance(value, dict):
        return MappingProxyType({key: _freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    return value


def _validate_safe_keys(
    value: Any,
    *,
    field_name: str | None = None,
    allow_secret_refs: bool = False,
    secret_value: bool = False,
    operation: AgentOperation | None = None,
    path: tuple[str | int, ...] = (),
    typed_result_strings: bool = False,
) -> None:
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise AgentProtocolError("JSON object keys must be strings")
            typed_recipe_build_key = operation is AgentOperation.RECIPE_BUILD and (
                (
                    path == ("options",)
                    and key in {"environment", "ignorefile", "unset_environment"}
                )
                or (
                    len(path) == 3
                    and path[0] == "options"
                    and path[1] == "additional_contexts"
                    and isinstance(path[2], int)
                    and key == "path"
                )
            )
            typed_distribution_object_name = (
                operation is AgentOperation.ARTIFACT_DISTRIBUTION
                and len(path) == 3
                and path[0] == "distribution_assignment"
                and path[1] == "objects"
                and isinstance(path[2], int)
                and key == "name"
            )
            typed_compiled_plan_key = operation in {
                AgentOperation.RECIPE_INSTALL,
                AgentOperation.RECIPE_START,
                AgentOperation.RECIPE_STOP,
                AgentOperation.RECIPE_JOB_RUN,
            } and path[:1] == ("compiled_execution_plan",)
            if _is_path_key(key) and not (
                typed_recipe_build_key
                or typed_distribution_object_name
                or typed_compiled_plan_key
                or (
                    operation is AgentOperation.RECIPE_JOB_RUN
                    and path == ("output_limits",)
                    and key == "max_file_bytes"
                )
            ):
                raise AgentProtocolError(f"filesystem path key is not allowed: {key}")
            if UNSAFE_KEY.search(key) and not (
                typed_recipe_build_key
                or (allow_secret_refs and (key == "secrets" or field_name == "secrets"))
            ):
                raise AgentProtocolError(f"unsafe protocol key: {key}")
            _validate_safe_keys(
                item,
                field_name=key,
                allow_secret_refs=allow_secret_refs or key == "deployment",
                secret_value=field_name == "secrets",
                operation=operation,
                path=(*path, key),
                typed_result_strings=typed_result_strings,
            )
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _validate_safe_keys(
                item,
                allow_secret_refs=allow_secret_refs,
                secret_value=secret_value,
                operation=operation,
                path=(*path, index),
                typed_result_strings=typed_result_strings,
            )
    elif isinstance(value, str):
        if secret_value:
            if not value.startswith("secret://"):
                raise AgentProtocolError("secret reference is not canonical")
            return
        if field_name == "platform_target_name":
            if VERSIONED_PLATFORM_TARGET.fullmatch(value) is None:
                raise AgentProtocolError("platform target identifier is not canonical")
        elif (
            (
                operation is AgentOperation.RECIPE_BUILD
                and _typed_build_string(path, value)
            )
            or (
                operation is AgentOperation.RECIPE_JOB_RUN
                and _typed_recipe_job_string(path, value)
            )
            or (
                operation is AgentOperation.AGENT_UPGRADE
                and path in {("package_url",), ("source_package_url",)}
                and AGENT_PACKAGE_URL.fullmatch(value) is not None
            )
            or (
                operation is AgentOperation.ARTIFACT_DISTRIBUTION
                and len(path) == 4
                and path[0] == "distribution_assignment"
                and path[1] == "objects"
                and isinstance(path[2], int)
                and path[3] == "name"
            )
            or (
                typed_result_strings
                and ("/" in value or "\\" in value)
                and _typed_result_string(path, value)
            )
        ) or (
            operation
            in {
                AgentOperation.RECIPE_INSTALL,
                AgentOperation.RECIPE_START,
                AgentOperation.RECIPE_STOP,
                AgentOperation.RECIPE_JOB_RUN,
            }
            and path[:1] == ("compiled_execution_plan",)
        ):
            return
        elif "/" in value or "\\" in value:
            raise AgentProtocolError("filesystem path values are not allowed")


def _is_path_key(key: str) -> bool:
    return bool(PATH_KEY.search(key))


def _typed_build_string(path: tuple[str | int, ...], value: str) -> bool:
    def bundle_path() -> bool:
        return (
            0 < len(value.encode("utf-8")) <= 512
            and not value.startswith("/")
            and "\\" not in value
            and "\x00" not in value
            and all(part not in {"", ".", ".."} for part in value.split("/"))
        )

    if path == ("platform",):
        return value == "linux/arm64"
    if path == ("adapter", "definition", "containerfile"):
        # The platform-owned adaptation stage is the one declared build leaf
        # that legitimately carries absolute paths and shell text.  It travels
        # with its canonical digest, which the agent re-derives before use.
        return 0 < len(value.encode("utf-8")) <= 65_536 and "\x00" not in value
    if path == ("dockerfile",):
        return bundle_path()
    if path == ("options", "ignorefile"):
        return bundle_path()
    if (
        len(path) == 4
        and path[:2] == ("options", "additional_contexts")
        and isinstance(path[2], int)
        and path[3] == "path"
    ):
        return bundle_path()
    if (
        len(path) == 4
        and path[0] == "options"
        and path[1] in {"annotations", "environment", "labels", "layer_labels"}
        and isinstance(path[2], int)
        and path[3] in {"name", "value"}
    ):
        return len(value) <= 1024 and "\x00" not in value
    if (
        len(path) == 3
        and path[:2] == ("options", "unset_labels")
        and isinstance(path[2], int)
    ):
        return len(value) <= 128 and "\x00" not in value
    if (
        len(path) == 3
        and path[0] == "base_images"
        and isinstance(path[1], int)
        and path[2] == "reference"
    ):
        return PINNED_OCI_IMAGE.fullmatch(value) is not None
    return (
        len(path) == 3
        and path[0] == "arguments"
        and isinstance(path[1], int)
        and path[2] == "value"
        and len(value) <= 1024
        and "\x00" not in value
    )


def _typed_recipe_job_string(path: tuple[str | int, ...], value: str) -> bool:
    if (
        (
            len(path) == 3
            and path[0] == "inputs"
            and isinstance(path[1], int)
            and path[2] == "media_type"
        )
        or (
            len(path) == 3
            and path[:2] == ("output_limits", "allowed_media_types")
            and isinstance(path[2], int)
        )
        or (
            len(path) == 3
            and path[0] == "output_mappings"
            and isinstance(path[1], int)
            and path[2] == "media_type"
        )
    ):
        return bool(
            re.fullmatch(
                r"[a-z0-9][a-z0-9!#$&^_.+-]{0,63}/[a-z0-9][a-z0-9!#$&^_.+-]{0,63}",
                value,
            )
        )
    return False


def _typed_result_string(path: tuple[str | int, ...], value: str) -> bool:
    # These declared leaves are inert captured observations, never authority.
    # Their enclosing Pydantic model enforces the complete diagnostic byte bound.
    if path in {("diagnostics", "stdout", "text"), ("diagnostics", "stderr", "text")}:
        return len(value) <= 2048 and "\x00" not in value
    if (
        len(path) == 4
        and path[0] == "diagnostics"
        and path[1] in {"versions", "sandbox", "storage", "preflight"}
        and isinstance(path[2], int)
        and path[3] == "value"
    ):
        return len(value) <= 256 and "\x00" not in value
    if path == ("endpoint",):
        return _recipe_endpoint(value)
    if (
        len(path) == 4
        and path[:2] == ("output_manifest", "files")
        and isinstance(path[2], int)
        and path[3] == "media_type"
    ):
        return bool(
            re.fullmatch(
                r"[a-z0-9][a-z0-9!#$&^_.+-]{0,63}/[a-z0-9][a-z0-9!#$&^_.+-]{0,63}",
                value,
            )
        )
    return False


def _recipe_endpoint(value: str) -> bool:
    try:
        parsed = urlsplit(value)
        hostname = parsed.hostname
        port = parsed.port
        address = ipaddress.ip_address(hostname) if hostname is not None else None
    except ValueError:
        return False
    return bool(
        parsed.scheme == "http"
        and hostname
        and port is not None
        and 1 <= port <= 65535
        and parsed.username is None
        and parsed.password is None
        and parsed.path in {"", "/"}
        and not parsed.query
        and not parsed.fragment
        and address is not None
        and not address.is_loopback
        and not address.is_unspecified
        and not address.is_multicast
    )


def _model_identity(value: str) -> bool:
    repository, marker, revision = value.rpartition("@")
    if (
        marker != "@"
        or not 1 <= len(repository) <= 512
        or MODEL_REVISION.fullmatch(revision) is None
        or "\\" in repository
    ):
        return False
    if MODEL_REPOSITORY.fullmatch(repository) is not None:
        return True
    try:
        parsed = urlsplit(repository)
        _ = parsed.port
    except ValueError:
        return False
    return bool(
        parsed.scheme == "https"
        and parsed.hostname
        and parsed.username is None
        and parsed.password is None
        and parsed.path not in {"", "/"}
        and _safe_model_query(parsed.query)
        and not parsed.fragment
    )


def parse_model_identity(value: str) -> tuple[str, str]:
    """Parse the canonical result identity ``repository@revision``."""

    if not isinstance(value, str) or not _model_identity(value):
        raise AgentProtocolError("model identity is invalid")
    repository, _marker, revision = value.rpartition("@")
    return repository, revision


def format_model_identity(publisher: str, slug: str, content_sha256: str) -> str:
    """Format the catalog model identity used by result evidence."""

    value = f"{publisher}/{slug}@{content_sha256}"
    parse_model_identity(value)
    return value


def _safe_model_query(query: str) -> bool:
    if not query:
        return True
    if len(query) > 256:
        return False
    try:
        fields = parse_qsl(
            query,
            keep_blank_values=True,
            strict_parsing=True,
            max_num_fields=8,
        )
    except ValueError:
        return False
    return bool(
        fields
        and all(
            len(key) <= 64
            and MODEL_QUERY_COMPONENT.fullmatch(key) is not None
            and (not value or MODEL_QUERY_COMPONENT.fullmatch(value) is not None)
            and UNSAFE_KEY.search(key) is None
            for key, value in fields
        )
    )


def _validate_bounded_document(
    value: Any,
    *,
    name: str,
    operation: AgentOperation | None = None,
    typed_result_strings: bool = False,
    maximum_bytes: int = MAX_DOCUMENT_BYTES,
) -> Any:
    if not isinstance(value, Mapping):
        raise AgentProtocolError(f"{name} must be a JSON object")
    _validate_safe_keys(
        value,
        operation=operation,
        typed_result_strings=typed_result_strings,
    )
    copied = _canonical_copy(value, name=name)
    if len(canonical_message(copied)) > maximum_bytes:
        raise AgentProtocolError(f"{name} is too large")
    return copied


def _mapping(value: Any) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise AgentProtocolError("message must be a JSON object")
    if not all(isinstance(key, str) for key in value):
        raise AgentProtocolError("JSON object keys must be strings")
    return value


def _fields(value: Mapping[str, Any], *, required: set[str]) -> None:
    if set(value) != required:
        missing = sorted(required - set(value))
        unknown = sorted(set(value) - required)
        detail = (
            f"missing fields: {', '.join(missing)}"
            if missing
            else f"unknown fields: {', '.join(unknown)}"
        )
        raise AgentProtocolError(detail)


def _uuid(value: Any, *, name: str) -> str:
    if not isinstance(value, str):
        raise AgentProtocolError(f"{name} must be a UUID")
    try:
        parsed = UUID(value)
    except ValueError as error:
        raise AgentProtocolError(f"{name} must be a UUID") from error
    if str(parsed) != value:
        raise AgentProtocolError(f"{name} must be a canonical UUID")
    return value


def _deadline(value: Any) -> datetime:
    if isinstance(value, datetime):
        deadline = value
    elif isinstance(value, str):
        try:
            deadline = datetime.fromisoformat(value)
        except ValueError as error:
            raise AgentProtocolError(
                "deadline must be an ISO-8601 UTC timestamp"
            ) from error
    else:
        raise AgentProtocolError("deadline must be an ISO-8601 UTC timestamp")
    if deadline.tzinfo is None or deadline.utcoffset() != UTC.utcoffset(deadline):
        raise AgentProtocolError("deadline must be aware UTC")
    return deadline.astimezone(UTC)


from .build_import import (
    RecipeBuildCleanupEvidence,
    RecipeBuildCleanupRequest,
    RecipeBuildEvidence,
    RecipeBuildRequest,
    RecipeImageImportEvidence,
    RecipeImageImportRequest,
)
from .recipe_jobs import RecipeJobRunRequest, RecipeJobRunResult
from .recipe_operations import (
    RecipeInstallPayload,
    RecipeReconcilePayload,
    RecipeReconcileResult,
    RecipeStartPayload,
    RecipeStopPayload,
    RecipeStopResult,
    RecipeUninstallPayload,
    RecipeUninstallResult,
)
from .runtime_preflight import RuntimePreflightRequest, RuntimePreflightResult

AgentPayload = (
    RuntimePreflightRequest
    | AgentUpgradePayload
    | ArtifactDistributionPayload
    | RecipeBuildRequest
    | RecipeBuildCleanupRequest
    | RecipeImageImportRequest
    | RecipeJobRunRequest
    | RecipeInstallPayload
    | RecipeStartPayload
    | RecipeStopPayload
    | RecipeReconcilePayload
    | RecipeUninstallPayload
)
AgentResultPayload = (
    RuntimePreflightResult
    | AgentInstallResult
    | RecipeStartResult
    | RecipeStopResult
    | RecipeReconcileResult
    | RecipeUninstallResult
    | RecipeBuildEvidence
    | RecipeBuildCleanupEvidence
    | RecipeImageImportEvidence
    | RecipeJobRunResult
    | ArtifactDistributionResult
    | AgentFailureResult
    | AgentUpgradeResult
)
PAYLOAD_MODELS: dict[AgentOperation, type[BaseModel]] = {
    AgentOperation.RUNTIME_PREFLIGHT: RuntimePreflightRequest,
    AgentOperation.AGENT_UPGRADE: AgentUpgradePayload,
    AgentOperation.ARTIFACT_DISTRIBUTION: ArtifactDistributionPayload,
    AgentOperation.RECIPE_BUILD: RecipeBuildRequest,
    AgentOperation.RECIPE_BUILD_CLEANUP: RecipeBuildCleanupRequest,
    AgentOperation.RECIPE_IMAGE_IMPORT: RecipeImageImportRequest,
    AgentOperation.RECIPE_JOB_RUN: RecipeJobRunRequest,
    AgentOperation.RECIPE_INSTALL: RecipeInstallPayload,
    AgentOperation.RECIPE_START: RecipeStartPayload,
    AgentOperation.RECIPE_STOP: RecipeStopPayload,
    AgentOperation.RECIPE_UNINSTALL: RecipeUninstallPayload,
    AgentOperation.RECIPE_RECONCILE: RecipeReconcilePayload,
}


def canonical_payload(operation: AgentOperation | str, payload: Any) -> bytes:
    """Validate the selected current payload model before canonical hashing."""
    try:
        kind = AgentOperation(operation)
        model = PAYLOAD_MODELS[kind]
        document = (
            payload.model_dump(mode="python")
            if isinstance(payload, BaseModel)
            else payload
        )
        typed = model.model_validate(document)
    except (KeyError, TypeError, ValueError) as error:
        raise AgentProtocolError("operation protocol payload is invalid") from error
    return canonical_message(typed)


# Result validation is contextual because the result envelope deliberately
# carries no operation discriminator.  Keep this registry alongside the
# payload registry so Controller ingress can resolve the stored operation and
# validate the exact result graph before accepting it.
RESULT_MODELS: dict[AgentOperation, type[BaseModel]] = {
    AgentOperation.RUNTIME_PREFLIGHT: RuntimePreflightResult,
    AgentOperation.AGENT_UPGRADE: AgentUpgradeResult,
    AgentOperation.ARTIFACT_DISTRIBUTION: ArtifactDistributionResult,
    AgentOperation.RECIPE_INSTALL: AgentInstallResult,
    AgentOperation.RECIPE_START: RecipeStartResult,
    AgentOperation.RECIPE_STOP: RecipeStopResult,
    AgentOperation.RECIPE_UNINSTALL: RecipeUninstallResult,
    AgentOperation.RECIPE_RECONCILE: RecipeReconcileResult,
    AgentOperation.RECIPE_BUILD: RecipeBuildEvidence,
    AgentOperation.RECIPE_BUILD_CLEANUP: RecipeBuildCleanupEvidence,
    AgentOperation.RECIPE_IMAGE_IMPORT: RecipeImageImportEvidence,
    AgentOperation.RECIPE_JOB_RUN: RecipeJobRunResult,
}


def validate_result_for_operation(
    operation: AgentOperation | str,
    result: Any,
    *,
    state: str,
) -> BaseModel:
    """Validate a result against the operation stored by the Controller.

    Success and failure both use the current typed graph. A one-shot recipe
    job reports its process result on failure; infrastructure failures use the
    shared failure model. Neither permits another operation's success receipt.

    The generic failure model must identify itself: a ``failed`` envelope that
    is not a recipe-process receipt has to carry ``status="failed"`` and a
    stable ``error_code`` matching the shared ``ERROR_CODE_PATTERN``.  That
    rule is enforced by ``AgentResult`` itself, so the agent producer and the
    Controller ingress cannot disagree about a usable failure.
    """

    try:
        operation_kind = AgentOperation(operation)
    except (TypeError, ValueError) as error:
        raise AgentProtocolError("agent result operation is invalid") from error
    try:
        model = RESULT_MODELS[operation_kind]
    except KeyError as error:
        raise AgentProtocolError(
            f"result model is not registered for {operation_kind.value}"
        ) from error
    if state != "succeeded":
        model = AgentFailureResult
    try:
        parsed = (
            TypeAdapter(AgentFailureResult | RecipeJobRunResult).validate_json(
                canonical_message(result)
            )
            if state != "succeeded" and operation_kind == AgentOperation.RECIPE_JOB_RUN
            else model.model_validate_json(canonical_message(result))
        )
        if (
            state == "failed"
            and isinstance(parsed, RecipeJobRunResult)
            and parsed.exit_code == 0
        ):
            raise ValueError("failed recipe job requires a nonzero process exit code")
        return parsed
    except ValidationError as error:
        raise AgentProtocolError(
            f"{operation_kind.value} result does not match its typed model: "
            f"{_validation_locations(error)}"
        ) from error
    except (TypeError, ValueError) as error:
        raise AgentProtocolError(
            f"{operation_kind.value} result is invalid: {error}"
        ) from error


def _validation_locations(error: ValidationError, *, limit: int = 8) -> str:
    """Render bounded field paths and rule types, never rejected values."""

    entries: list[str] = []
    for item in error.errors()[:limit]:
        location = ".".join(str(part) for part in item.get("loc", ())) or "<root>"
        kind = str(item.get("type", "value_error"))
        entries.append(f"{location}:{kind}"[:80])
    if not entries:
        return "<unknown>"
    return ", ".join(entries)[:256]


class _ProtocolEnvelopeModel(WireModel):
    """Wire envelope base with the derived extension-map security schema."""

    @classmethod
    def model_json_schema(cls, *args: Any, **kwargs: Any) -> dict[str, Any]:
        document = super().model_json_schema(*args, **kwargs)
        _add_protocol_schema_constraints(document)
        return document


class AgentClaim(_ProtocolEnvelopeModel):
    fence: CanonicalUUID
    operation: AgentOperation
    payload: AgentPayload
    deadline: datetime

    @model_validator(mode="before")
    @classmethod
    def normalize_wire_scalars(cls, value: Any) -> Any:
        if not isinstance(value, Mapping):
            return value
        document = dict(value)
        if "operation" in document and not isinstance(
            document["operation"], AgentOperation
        ):
            try:
                document["operation"] = AgentOperation(document["operation"])
            except (TypeError, ValueError):
                pass
        operation = document.get("operation")
        payload = document.get("payload")
        expected_model = PAYLOAD_MODELS.get(operation)
        if expected_model is not None and isinstance(payload, Mapping):
            document["payload"] = expected_model.model_validate(payload)
        if "deadline" in document:
            document["deadline"] = _deadline(document["deadline"])
        return document

    @model_validator(mode="after")
    def validate_wire(self) -> AgentClaim:
        _uuid(self.fence, name="fence")
        expected_model = PAYLOAD_MODELS.get(self.operation)
        if expected_model is None or not isinstance(self.payload, expected_model):
            raise AgentProtocolError(
                f"payload model is not registered for {self.operation.value}"
            )
        compiled_plan = getattr(self.payload, "compiled_execution_plan", None)
        if compiled_plan is not None and len(canonical_message(compiled_plan)) > (
            MAX_COMPILED_EXECUTION_PLAN_DOCUMENT_BYTES
        ):
            raise AgentProtocolError("compiled execution plan is too large")
        payload_document = json.loads(canonical_message(self.payload))
        maximum_bytes = (
            MAX_COMPILED_EXECUTION_PLAN_CLAIM_BYTES
            if self.operation
            in {
                AgentOperation.RECIPE_INSTALL,
                AgentOperation.RECIPE_START,
                AgentOperation.RECIPE_STOP,
                AgentOperation.RECIPE_JOB_RUN,
            }
            else MAX_DOCUMENT_BYTES
        )
        _validate_bounded_document(
            payload_document,
            name="payload",
            operation=self.operation,
            maximum_bytes=maximum_bytes,
        )
        object.__setattr__(self, "payload", self.payload)
        object.__setattr__(self, "deadline", _deadline(self.deadline))
        return self

    @classmethod
    def parse(cls, raw: Any) -> AgentClaim:
        try:
            if isinstance(raw, Mapping) and isinstance(raw.get("payload"), Mapping):
                operation = raw.get("operation")
                try:
                    operation_kind = AgentOperation(operation)
                except (TypeError, ValueError):
                    operation_kind = None
                _validate_bounded_document(
                    raw["payload"],
                    name="payload",
                    operation=operation_kind,
                    maximum_bytes=(
                        MAX_COMPILED_EXECUTION_PLAN_CLAIM_BYTES
                        if operation_kind
                        in {
                            AgentOperation.RECIPE_INSTALL,
                            AgentOperation.RECIPE_START,
                            AgentOperation.RECIPE_STOP,
                            AgentOperation.RECIPE_JOB_RUN,
                        }
                        else MAX_DOCUMENT_BYTES
                    ),
                )
            return cls.model_validate(raw)
        except AgentProtocolError:
            raise
        except ValidationError as error:
            raise AgentProtocolError(str(error)) from error


class AgentProgress(_ProtocolEnvelopeModel):
    fence: CanonicalUUID
    progress: OperationProgress | None = None

    @model_validator(mode="before")
    @classmethod
    def normalize_wire_scalars(cls, value: Any) -> Any:
        if not isinstance(value, Mapping):
            return value
        document = dict(value)
        if "progress" in document and isinstance(document["progress"], Mapping):
            # Canonical JSON is the one adapter needed to thaw durable mappings.
            document["progress"] = json.loads(canonical_message(document["progress"]))
        return document

    @model_validator(mode="after")
    def validate_wire(self) -> AgentProgress:
        _uuid(self.fence, name="fence")
        if self.progress is not None:
            object.__setattr__(
                self,
                "progress",
                OperationProgress.model_validate(
                    json.loads(canonical_message(self.progress)), strict=True
                ),
            )
        return self

    @classmethod
    def parse(cls, raw: Any) -> AgentProgress:
        try:
            return cls.model_validate(raw)
        except AgentProtocolError:
            raise
        except ValidationError as error:
            raise AgentProtocolError(str(error)) from error


class AgentDirective(_ProtocolEnvelopeModel):
    """Authenticated heartbeat response for deadline renewal and cancellation."""

    fence: CanonicalUUID
    deadline: datetime
    cancel_requested: bool

    @model_validator(mode="before")
    @classmethod
    def normalize_wire_scalars(cls, value: Any) -> Any:
        if not isinstance(value, Mapping):
            return value
        document = dict(value)
        if "deadline" in document:
            document["deadline"] = _deadline(document["deadline"])
        return document

    @model_validator(mode="after")
    def validate_wire(self) -> AgentDirective:
        _uuid(self.fence, name="fence")
        _deadline(self.deadline)
        return self

    @classmethod
    def parse(cls, raw: Any) -> AgentDirective:
        try:
            return cls.model_validate(raw)
        except AgentProtocolError:
            raise
        except ValidationError as error:
            raise AgentProtocolError(str(error)) from error


class AgentResult(_ProtocolEnvelopeModel):
    fence: CanonicalUUID
    state: Literal["succeeded", "failed", "cancelled", "waiting-for-operator"]
    result: AgentResultPayload

    @model_validator(mode="after")
    def validate_wire(self) -> AgentResult:
        _uuid(self.fence, name="fence")
        if (
            self.state == "failed"
            and isinstance(self.result, AgentFailureResult)
            and (self.result.status != "failed" or self.result.error_code is None)
        ):
            # A job receipt reports its own process outcome on failure; any
            # other failed operation uses the shared failure model, which must
            # identify itself with a failed status and a stable error code.
            # The envelope is the one place both the agent producer and the
            # Controller ingress validate, so the rule cannot drift.
            raise ValueError(
                "failed result requires status='failed' and a stable error_code"
            )
        result_document = json.loads(canonical_message(self.result))
        object.__setattr__(
            self,
            "result",
            self.result,
        )
        _validate_bounded_document(
            result_document,
            name="result",
            typed_result_strings=True,
        )
        return self

    @classmethod
    def parse(cls, raw: Any) -> AgentResult:
        try:
            if isinstance(raw, Mapping) and isinstance(raw.get("result"), Mapping):
                _validate_bounded_document(
                    raw["result"],
                    name="result",
                    typed_result_strings=True,
                )
            return cls.model_validate(raw)
        except AgentProtocolError:
            raise
        except ValidationError as error:
            raise AgentProtocolError(str(error)) from error


def schema_validator(schema_name: str) -> Draft202012Validator:
    """Return the package-mandated Draft 2020-12 validator for a wire schema."""
    if schema_name not in {
        "agent-job.schema.json",
        "agent-result.schema.json",
        "agent-directive.schema.json",
        "recipe-job-run.schema.json",
    }:
        raise AgentProtocolError(f"unknown protocol schema: {schema_name}")
    registry: dict[str, type[BaseModel]] = {
        "agent-job.schema.json": AgentClaim,
        "agent-result.schema.json": AgentResult,
        "agent-directive.schema.json": AgentDirective,
    }
    if schema_name == "recipe-job-run.schema.json":
        # Recipe job wire shape is generated from the Pydantic model graph.
        # Keep the import local because recipe_jobs imports these primitives.
        from .recipe_jobs import RecipeJobRunRequest

        registry[schema_name] = RecipeJobRunRequest
    document = registry[schema_name].model_json_schema()
    return Draft202012Validator(document, format_checker=PROTOCOL_FORMAT_CHECKER)


def _add_protocol_schema_constraints(document: dict[str, Any]) -> None:
    """Add recursive boundary constraints to schemas derived from WireModel.

    Pydantic describes the recursive JSON value types, while these two
    constraints are security semantics shared by every extension map. Keeping
    them attached during registry derivation makes ``schema_validator`` and
    the runtime parser enforce the same boundary without a second schema file.
    """

    safe_property_names = {
        "allOf": [
            {"not": {"pattern": UNSAFE_SCHEMA_KEY_PATTERN}},
            {"not": {"pattern": PATH_KEY.pattern}},
        ]
    }
    json_value = document.get("$defs", {}).get("JsonValue")
    if isinstance(json_value, Mapping):
        for branch in json_value.get("anyOf", ()):
            if isinstance(branch, dict) and branch.get("type") == "object":
                branch["propertyNames"] = safe_property_names

    def constrain_extension_objects(value: object) -> None:
        if isinstance(value, dict):
            if value.get("type") == "object" and value.get("additionalProperties") == {
                "$ref": "#/$defs/JsonValue"
            }:
                value["propertyNames"] = safe_property_names
            for child in value.values():
                constrain_extension_objects(child)
        elif isinstance(value, list):
            for child in value:
                constrain_extension_objects(child)

    constrain_extension_objects(document)

    properties = document.get("properties", {})
    for name in ("payload", "result"):
        value = properties.get(name)
        if isinstance(value, dict):
            if isinstance(value.get("anyOf"), list):
                value["oneOf"] = value.pop("anyOf")
            if value.get("type") == "object":
                value["propertyNames"] = safe_property_names
    result = properties.get("result")
    if (
        isinstance(result, dict)
        and result.get("type") == "object"
        and isinstance(json_value, Mapping)
    ):
        # Result strings are operator evidence and cannot carry client paths.
        # Keep claim payload strings broad because typed operation payloads
        # include authorized URLs and platform targets.
        result_schema = deepcopy(json_value)
        result_schema_name = "ResultJsonValue"
        result_schema_text = json.dumps(result_schema)
        result_schema_text = result_schema_text.replace(
            "#/$defs/JsonValue", "#/$defs/ResultJsonValue"
        )
        result_schema = json.loads(result_schema_text)

        def restrict_result_values(value: object) -> None:
            if not isinstance(value, dict):
                return
            if value.get("type") == "string":
                value["not"] = {"pattern": r"[/\\]"}
            if value.get("type") == "object":
                value["propertyNames"] = safe_property_names
            for child in value.values():
                if isinstance(child, dict):
                    restrict_result_values(child)
                elif isinstance(child, list):
                    for item in child:
                        restrict_result_values(item)

        restrict_result_values(result_schema)
        document.setdefault("$defs", {})[result_schema_name] = result_schema
        result["additionalProperties"] = {"$ref": f"#/$defs/{result_schema_name}"}
    deadline = properties.get("deadline")
    if isinstance(deadline, dict):
        deadline["pattern"] = r"(?:Z|\+00:00)$"


def validate_schema_message(schema_name: str, raw: Any) -> Any:
    """Apply the format-aware wire schema and its mandatory runtime limits."""
    parsers = {
        "agent-job.schema.json": AgentClaim.parse,
        "agent-result.schema.json": AgentResult.parse,
        "agent-directive.schema.json": AgentDirective.parse,
    }
    if schema_name == "recipe-job-run.schema.json":
        from .recipe_jobs import RecipeJobRunRequest

        parsers[schema_name] = RecipeJobRunRequest.parse
    try:
        parser = parsers[schema_name]
    except KeyError as error:
        raise AgentProtocolError(f"unknown protocol schema: {schema_name}") from error
    return parser(raw)
