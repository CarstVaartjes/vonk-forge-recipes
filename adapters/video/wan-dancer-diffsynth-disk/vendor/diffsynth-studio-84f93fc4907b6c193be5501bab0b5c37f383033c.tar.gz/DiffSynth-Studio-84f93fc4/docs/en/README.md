# DiffSynth-Studio Documentation

Welcome to the magical world of Diffusion models! `DiffSynth-Studio` is an open-source Diffusion model engine developed and maintained by the [ModelScope Community](https://www.modelscope.cn/). We aim to build a universal Diffusion model framework that fosters technological innovation through framework construction, aggregates the power of the open-source community, and explores the boundaries of generative model technology!

<details>

<summary>Documentation Reading Guide</summary>

```mermaid
graph LR;
    use["I want to use models for inference and training"]-->sec1["Section 1: Getting Started"];
    use["I want to use models for inference and training"]-->sec2["Section 2: Model Details"];
    use["I want to use models for inference and training"]-->sec3["Section 3: Training Framework"];
    develop["I want to develop based on this framework"]-->sec3["Section 3: Training Framework"];
    develop["I want to develop based on this framework"]-->sec4["Section 4: Model Integration"];
    develop["I want to develop based on this framework"]-->sec5["Section 5: API Reference"];
    explore["I want to explore new technologies based on this project"]-->sec4["Section 4: Model Integration"];
    explore["I want to explore new technologies based on this project"]-->sec5["Section 5: API Reference"];
    explore["I want to explore new technologies based on this project"]-->sec6["Section 6: Diffusion Templates"];
    explore["I want to explore new technologies based on this project"]-->sec7["Section 7: Research Guide"];
    problem["I encountered a problem"]-->sec8["Section 8: Frequently Asked Questions"];
```

</details>

## Section 1: Getting Started

This section introduces the basic usage of `DiffSynth-Studio`, including how to enable VRAM management for inference on GPUs with extremely low VRAM, and how to train various base models, LoRAs, ControlNets, and other models.

* [Installation Dependencies](./Pipeline_Usage/Setup.md)
* [Model Inference](./Pipeline_Usage/Model_Inference.md)
* [Accelerated Inference](./Pipeline_Usage/Accelerated_Inference.md)
* [VRAM Management](./Pipeline_Usage/VRAM_management.md)
* [Model Quantization](./Pipeline_Usage/Quantization.md)
* [Model Training](./Pipeline_Usage/Model_Training.md)
* [Environment Variables](./Pipeline_Usage/Environment_Variables.md)
* [GPU/NPU Support](./Pipeline_Usage/GPU_support.md)
* [Inference WebUI](./Pipeline_Usage/Inference_WebUI.md)

## Section 2: Model Details

This section introduces the Diffusion models supported by `DiffSynth-Studio`. Some model pipelines feature special functionalities such as controllable generation and parallel acceleration.

* [FLUX.1](./Model_Details/FLUX.md)
* [Wan](./Model_Details/Wan.md)
* [Qwen-Image](./Model_Details/Qwen-Image.md)
* [Qwen-Video-Edit](./Model_Details/Qwen-Video-Edit.md)
* [FLUX.2](./Model_Details/FLUX2.md)
* [Z-Image](./Model_Details/Z-Image.md)
* [Anima](./Model_Details/Anima.md)
* [LTX-2](./Model_Details/LTX-2.md)
* [ERNIE-Image](./Model_Details/ERNIE-Image.md)
* [JoyAI-Image](./Model_Details/JoyAI-Image.md)
* [ACE-Step](./Model_Details/ACE-Step.md)
* [HiDream-O1-Image](./Model_Details/HiDream-O1-Image.md)
* [Stable Diffusion](./Model_Details/Stable-Diffusion.md)
* [Stable Diffusion XL](./Model_Details/Stable-Diffusion-XL.md)
* [Image Quality Metrics](./Model_Details/Image-Quality-Metrics.md)
* [Ideogram 4](./Model_Details/Ideogram-4.md)
* [Krea-2](./Model_Details/Krea-2.md)
* [Boogu-Image](./Model_Details/Boogu-Image.md)
* [LingBot-Video](./Model_Details/LingBot-Video.md)
* [MiniMax-H3](./Model_Details/MiniMax-H3.md)
* [MiniMax-Music3](./Model_Details/MiniMax-Music3.md)

## Section 3: Training Framework

This section introduces the design philosophy of the training framework in `DiffSynth-Studio`, helping developers understand the principles of Diffusion model training algorithms.

* [Basic Principles of Diffusion Models](./Training/Understanding_Diffusion_models.md)
* [Standard Supervised Training](./Training/Supervised_Fine_Tuning.md)
* [Enabling FP8 Precision in Training](./Training/FP8_Precision.md)
* [End-to-End Distillation Accelerated Training](./Training/Direct_Distill.md)
* [Two-Stage Split Training](./Training/Split_Training.md)
* [Differential LoRA Training](./Training/Differential_LoRA.md)
* [Enabling DeepSpeed](./Training/DeepSpeed.md)
* [Offload Training](./Training/Offload_Training.md)

## Section 4: Model Integration

This section introduces how to integrate models into `DiffSynth-Studio` to utilize the framework's basic functions, helping developers provide support for new models in this project or perform inference and training of private models.

* [Integrating Model Architecture](./Developer_Guide/Integrating_Your_Model.md)
* [Building a Pipeline](./Developer_Guide/Building_a_Pipeline.md)
* [Enabling Fine-Grained VRAM Management](./Developer_Guide/Enabling_VRAM_management.md)
* [Model Training Integration](./Developer_Guide/Training_Diffusion_Models.md)
* [Integrating a Quantization Backend](./Developer_Guide/Integrating_Quantization_Backend.md)

> We have open-sourced [**DiffSynth-Studio Model Integration Skills**](https://www.modelscope.cn/collections/DiffSynth-Studio/DiffSynth-Studio-Model-Integration-Skills). This is a composable collection of Agent Skills that automates the entire workflow of integrating external diffusion models (image / video / audio) into DiffSynth-Studio. It distills and defines the model integration standards of DiffSynth-Studio, consolidating best practices such as codebase analysis, model code integration, Pipeline design, low-VRAM management, and training support into reusable standard procedures. Following these standards can significantly lower the integration barrier, reduce repetitive debugging, and greatly improve the efficiency of integrating new models. We recommend starting from the [`diffsynth-integrator`](https://www.modelscope.cn/skills/DiffSynth-Studio/diffsynth-integrator) [example](https://www.modelscope.cn/skills/DiffSynth-Studio/diffsynth-integrator/file/view/master/example.md?status=1) to get started quickly and accelerate model integration.

## Section 5: API Reference

This section introduces the independent core module `diffsynth.core` in `DiffSynth-Studio`, explaining how internal functions are designed and operate. Developers can use these functional modules in other codebase developments if needed.

* [`diffsynth.core.attention`](./API_Reference/core/attention.md): Attention mechanism implementation
* [`diffsynth.core.data`](./API_Reference/core/data.md): Data processing operators and general datasets
* [`diffsynth.core.gradient`](./API_Reference/core/gradient.md): Gradient checkpointing
* [`diffsynth.core.loader`](./API_Reference/core/loader.md): Model download and loading
* [`diffsynth.core.quant`](./API_Reference/core/quant.md): Model quantization
* [`diffsynth.core.vram`](./API_Reference/core/vram.md): VRAM management

## Section 6: Diffusion Templates

This section introduces the controllable generation plugin framework for Diffusion models, explaining the framework's operation mechanism and how to use Template models for inference and training.

* [Introducing Diffusion Templates](./Diffusion_Templates/Introducing_Diffusion_Templates.md)
* [Diffusion Templates Architecture Details](./Diffusion_Templates/Understanding_Diffusion_Templates.md)
* [Template Model Inference](./Diffusion_Templates/Template_Model_Inference.md)
* [Template Model Training](./Diffusion_Templates/Template_Model_Training.md)

## Section 7: Research Guide

This section introduces how to use `DiffSynth-Studio` to train new models, helping researchers explore new model technologies.

* [Training models from scratch](./Research_Tutorial/train_from_scratch.md)
* [Inference improvement techniques](./Research_Tutorial/inference_time_scaling.md)
* [Designing controllable generation models](./Research_Tutorial/controllable_models.md)
* Creating new training paradigms 【coming soon】

## Section 8: Frequently Asked Questions

This section summarizes common developer questions. If you encounter issues during usage or development, please refer to this section. If you still cannot resolve the problem, please submit an issue on GitHub.

* [Frequently Asked Questions](./QA.md)
