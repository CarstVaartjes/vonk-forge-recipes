欢迎来到 DiffSynth-Studio 的文档
=====================

.. toctree::
   :maxdepth: 2
   :caption: 文档介绍

   README

.. toctree::
   :maxdepth: 2
   :caption: 上手使用

   Pipeline_Usage/Setup
   Pipeline_Usage/Model_Inference
   Pipeline_Usage/Accelerated_Inference
   Pipeline_Usage/VRAM_management
   Pipeline_Usage/Quantization
   Pipeline_Usage/Model_Training
   Pipeline_Usage/Environment_Variables
   Pipeline_Usage/GPU_support
   Pipeline_Usage/Inference_WebUI

.. toctree::
   :maxdepth: 2
   :caption: 模型详解

   Model_Details/FLUX
   Model_Details/Wan
   Model_Details/Qwen-Image
   Model_Details/Qwen-Video-Edit
   Model_Details/FLUX2
   Model_Details/Z-Image
   Model_Details/Anima
   Model_Details/LTX-2
   Model_Details/ERNIE-Image
   Model_Details/JoyAI-Image
   Model_Details/ACE-Step
   Model_Details/HiDream-O1-Image
   Model_Details/Stable-Diffusion
   Model_Details/Stable-Diffusion-XL
   Model_Details/Image-Quality-Metrics
   Model_Details/Ideogram-4
   Model_Details/Krea-2
   Model_Details/Boogu-Image
   Model_Details/LingBot-Video
   Model_Details/MiniMax-H3
   Model_Details/MiniMax-Music3

.. toctree::
   :maxdepth: 2
   :caption: 训练框架

   Training/Understanding_Diffusion_models
   Training/Supervised_Fine_Tuning
   Training/FP8_Precision
   Training/Direct_Distill
   Training/Split_Training
   Training/Differential_LoRA
   Training/DeepSpeed
   Training/Offload_Training

.. toctree::
   :maxdepth: 2
   :caption: 模型接入

   Developer_Guide/Integrating_Your_Model
   Developer_Guide/Building_a_Pipeline
   Developer_Guide/Enabling_VRAM_management
   Developer_Guide/Training_Diffusion_Models
   Developer_Guide/Integrating_Quantization_Backend

.. toctree::
   :maxdepth: 2
   :caption: API 参考

   API_Reference/core/attention
   API_Reference/core/data
   API_Reference/core/gradient
   API_Reference/core/loader
   API_Reference/core/quant
   API_Reference/core/vram

.. toctree::
   :maxdepth: 2
   :caption: Diffusion Templates

   Diffusion_Templates/Introducing_Diffusion_Templates.md
   Diffusion_Templates/Understanding_Diffusion_Templates.md
   Diffusion_Templates/Template_Model_Inference.md
   Diffusion_Templates/Template_Model_Training.md

.. toctree::
   :maxdepth: 2
   :caption: 学术导引

   Research_Tutorial/train_from_scratch
   Research_Tutorial/inference_time_scaling
   Research_Tutorial/controllable_models

.. toctree::
   :maxdepth: 2
   :caption: 常见问题

   QA

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
