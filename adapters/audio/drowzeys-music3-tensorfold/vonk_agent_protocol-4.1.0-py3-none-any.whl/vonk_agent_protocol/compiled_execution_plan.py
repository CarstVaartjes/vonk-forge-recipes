"""Typed compiled launch plan shared by Controller and agents.

Platform constants are not carried: images are linux/arm64, containers run
with a read-only root, no capabilities and no new privileges, model and input
mounts are read-only, the output mount is writable, job inputs live under
/inputs and outputs under /outputs.
"""

from __future__ import annotations

import ipaddress
import re
from typing import Annotated, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictBool,
    StrictInt,
    StrictStr,
    StringConstraints,
    ValidationInfo,
    field_validator,
    model_validator,
)

from .contracts import AgentProtocolError
from .host_helper import MAX_ARGV_BYTES

Digest = Annotated[str, StringConstraints(pattern=r"^[0-9a-f]{64}$")]
ImageDigest = Annotated[str, StringConstraints(pattern=r"^sha256:[0-9a-f]{64}$")]
_EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
# A canonical launch can project one mount for each selected model artifact,
# plus the fixed input and output mounts.  Keep this derived from the existing
# compiled artifact ceiling rather than imposing a small engine-specific cap.
MAX_COMPILED_EXECUTION_PLAN_ARTIFACTS = 4096
MAX_COMPILED_EXECUTION_PLAN_MOUNTS = MAX_COMPILED_EXECUTION_PLAN_ARTIFACTS + 2
# The generated wire schema declares this vector's `maxItems`, so this is a
# structural mirror of the schema, not the size authority. The size authority is
# `MAX_ARGV_BYTES`, derived from the canonical host-runtime request ceiling.
MAX_ARGV_ITEMS = 4096
# Only the start/job payload memory fields still use this; they move to the
# plan's placement (always unified memory on DGX Spark).
MemoryKind = Literal["unified", "host", "accelerator"]
# Only the Controller's uninstall reader supplies this process-local context.
# It cannot be selected by fields in a persisted or incoming JSON document.
COMPILED_PLAN_STORAGE_CONTEXT = object()


class CompiledExecutionPlanError(ValueError):
    """The schema-2 launch projection is invalid."""


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)


def _safe_path(value: str, *, absolute: bool) -> str:
    if absolute and value == "/":
        return value
    parts = (
        value[1:].split("/") if absolute and value.startswith("/") else value.split("/")
    )
    if (
        not value
        or len(value) > 512
        or "\\" in value
        or "\x00" in value
        or any(part in {"", ".", ".."} for part in parts)
        or (absolute and not value.startswith("/"))
        or (not absolute and value.startswith("/"))
    ):
        raise ValueError("path is unsafe")
    return value


def _valid_name(value: str) -> bool:
    return bool(re.fullmatch(r"[a-z0-9][a-z0-9_.-]{0,63}\Z", value))


def _valid_role(value: str) -> bool:
    return bool(re.fullmatch(r"[a-z][a-z0-9_-]{0,63}\Z", value))


def _validate_argv(value: list[str], *, required: bool = False) -> list[str]:
    if (
        (required and (not value or not value[0]))
        or len(value) > MAX_ARGV_ITEMS
        or any("\x00" in item or len(item.encode()) > 65536 for item in value)
        or sum(len(item.encode()) for item in value) > MAX_ARGV_BYTES
    ):
        raise ValueError("argv is invalid")
    return value


def _validate_ip(value: str | None) -> str | None:
    if value is None:
        return value
    parsed = ipaddress.ip_address(value)
    if (
        parsed.is_loopback
        or parsed.is_link_local
        or parsed.is_multicast
        or parsed.is_unspecified
        or str(parsed) != value
    ):
        raise ValueError("address is invalid")
    return value


class CompiledIdentity(_Strict):
    recipe_revision_sha256: Digest
    model_artifact_set_sha256: Digest


class CompiledEnvironmentEntry(_Strict):
    name: str = Field(min_length=1, max_length=128)
    value: str = Field(max_length=65536)

    @field_validator("name")
    @classmethod
    def name_is_canonical(cls, value: str) -> str:
        if not re.fullmatch(r"[A-Z][A-Za-z0-9_]*\Z", value):
            raise ValueError("environment name is invalid")
        return value

    @field_validator("value")
    @classmethod
    def value_is_safe(cls, value: str) -> str:
        if "\x00" in value or len(value.encode()) > 65536:
            raise ValueError("environment value is invalid")
        return value


class CompiledPlacement(_Strict):
    endpoint_address: str | None = Field(json_schema_extra={"format": "ip"})
    rank: int = Field(ge=0)
    role: str = Field(min_length=1, max_length=64)
    world_size: int = Field(ge=1)
    local_address: str | None = Field(json_schema_extra={"format": "ip"})
    master_address: str | None = Field(json_schema_extra={"format": "ip"})
    master_port: int | None = Field(ge=1024, le=65535)
    port: int | None = Field(default=..., ge=1, le=65535)
    reserved_memory_bytes: int = Field(gt=0, le=16 * 1024**4)
    memory_floor_bytes: int = Field(ge=0, le=16 * 1024**4)

    _addresses_are_safe = field_validator(
        "endpoint_address", "local_address", "master_address"
    )(_validate_ip)


class CompiledRuntime(_Strict):
    executable: str = Field(min_length=1, max_length=65536)
    argv: list[str] = Field(max_length=MAX_ARGV_ITEMS)
    env: list[CompiledEnvironmentEntry] = Field(max_length=128)
    placement: CompiledPlacement

    @field_validator("executable")
    @classmethod
    def executable_is_absolute(cls, value: str) -> str:
        if (
            not value.startswith("/")
            or "\x00" in value
            or "\r" in value
            or "\n" in value
            or len(value.encode()) > 65536
        ):
            raise ValueError("executable is unsafe")
        return value

    _argv_is_safe = field_validator("argv")(_validate_argv)


class CompiledArtifactMount(_Strict):
    """A read-only model mount."""

    target: str

    @field_validator("target")
    @classmethod
    def target_is_model_path(cls, value: str) -> str:
        value = _safe_path(value, absolute=True)
        if value != "/models" and not value.startswith("/models/"):
            raise ValueError("model mount target is unsafe")
        return value


class CompiledModelIdentity(_Strict):
    # Model references are public catalog text, rather than container names.
    # Keep the wire boundary bounded and NUL-safe while preserving Unicode and
    # spaces accepted by the canonical model contract.
    publisher: str = Field(min_length=1, max_length=128)
    slug: str = Field(min_length=1, max_length=64)
    content_sha256: Digest

    @field_validator("publisher")
    @classmethod
    def publisher_is_safe_text(cls, value: str) -> str:
        if "\x00" in value:
            raise ValueError("model identity publisher is invalid")
        return value

    @field_validator("slug")
    @classmethod
    def slug_is_canonical(cls, value: str) -> str:
        if not _valid_name(value):
            raise ValueError("model identity slug is invalid")
        return value


class CompiledArtifact(_Strict):
    selection_id: str = Field(min_length=1, max_length=64)
    file_id: str = Field(min_length=1, max_length=64)
    path: str
    sha256: Digest
    size_bytes: int = Field(ge=0, le=16 * 1024**4)
    roles: list[str] = Field(min_length=1)
    mount: CompiledArtifactMount
    model: CompiledModelIdentity

    @field_validator("path")
    @classmethod
    def path_is_relative(cls, value: str) -> str:
        if (
            not value
            or len(value) > 512
            or "\\" in value
            or "\x00" in value
            or any(not part or part in {".", ".."} for part in value.split("/"))
        ):
            raise ValueError("model path is unsafe")
        return value

    @field_validator("selection_id", "file_id")
    @classmethod
    def names_are_canonical(cls, value: str) -> str:
        if not _valid_name(value):
            raise ValueError("artifact identity is invalid")
        return value

    @field_validator("roles")
    @classmethod
    def roles_are_canonical(cls, value: list[str]) -> list[str]:
        if value != sorted(set(value)) or any(not _valid_role(role) for role in value):
            raise ValueError("artifact roles are not canonical")
        return value

    @model_validator(mode="after")
    def weights_are_not_empty(self) -> CompiledArtifact:
        if self.size_bytes == 0 and any(
            role in {"model", "weight", "weights"} for role in self.roles
        ):
            raise ValueError("zero-sized model artifact role is invalid")
        return self


class CompiledRuntimeImage(_Strict):
    """A runtime image in the Controller's layered store.

    ``image_digest`` is its manifest digest and ``oci_layout_sha256`` the same
    digest's hex, its address in the store; ``image_bytes`` is the size of its
    layers. Sparks pull it into Docker as
    ``localhost/vonk/compiled-runtime-<oci_layout_sha256>@<image_digest>``.
    """

    image_digest: ImageDigest
    oci_layout_sha256: Digest
    image_bytes: int = Field(gt=0, le=16 * 1024**4)
    build_id: str = Field(min_length=1, max_length=128)
    local_image_config_id: ImageDigest
    runtime_interface_label: str = Field(min_length=1, max_length=128)

    @property
    def local_image_reference(self) -> str:
        return (
            f"localhost/vonk/compiled-runtime-{self.oci_layout_sha256}"
            f"@{self.image_digest}"
        )


class CompiledSecurityMount(_Strict):
    """Model and input mounts are read-only; the output mount is writable."""

    source: Literal["model", "inputs", "outputs"]
    target: str

    @field_validator("target")
    @classmethod
    def target_is_safe(cls, value: str) -> str:
        return _safe_path(value, absolute=True)

    @property
    def read_only(self) -> bool:
        return self.source != "outputs"

    @model_validator(mode="after")
    def policy_matches_source(self) -> CompiledSecurityMount:
        if self.source == "outputs" and self.target != "/outputs":
            raise ValueError("outputs mount policy is invalid")
        if self.source == "inputs" and self.target != "/inputs":
            raise ValueError("inputs mount policy is invalid")
        if self.source == "model" and (
            self.target != "/models" and not self.target.startswith("/models/")
        ):
            raise ValueError("model mount policy is invalid")
        return self


class CompiledSecurity(_Strict):
    """Per-workload security choices; everything else is a platform constant."""

    gpu: StrictBool
    network_mode: Literal["none", "bridge", "host"]
    user: str
    mounts: list[CompiledSecurityMount]

    @model_validator(mode="after")
    def security_is_bounded(self) -> CompiledSecurity:
        targets = [mount.target for mount in self.mounts]
        if len(self.mounts) > MAX_COMPILED_EXECUTION_PLAN_MOUNTS or len(targets) != len(
            set(targets)
        ):
            raise ValueError("security policy is invalid")
        parts = self.user.split(":")
        if len(parts) not in {1, 2} or any(
            not part or part.startswith("0") or not part.isdigit() for part in parts
        ):
            raise ValueError("security user is invalid")
        return self


class CompiledTopology(_Strict):
    name: str
    node_count: int = Field(gt=0)

    @field_validator("name")
    @classmethod
    def name_is_canonical(cls, value: str) -> str:
        if not _valid_name(value):
            raise ValueError("topology name is invalid")
        return value


class CompiledLifecycle(_Strict):
    stop_timeout_seconds: int = Field(ge=1, le=600)


class CompiledEndpoint(_Strict):
    """An OpenAI-compatible endpoint."""

    port: int = Field(ge=1024, le=65535)
    model_aliases: list[str] = Field(min_length=1)
    health_path: str = Field(max_length=256)

    @field_validator("health_path")
    @classmethod
    def health_path_is_safe(cls, value: str) -> str:
        if ".." in value:
            raise ValueError("health path is unsafe")
        return _safe_path(value, absolute=True)


class CompiledJobInputSlot(_Strict):
    """Agent-side parity model for the public ``RecipeInputSlot`` contract.

    The agent protocol wheel intentionally cannot import the public recipe
    contracts wheel.  Keep this fixed wire structure in lockstep with that
    source contract; engine-specific job parameters remain elsewhere in the
    job request and are deliberately extensible.
    """

    id: Annotated[StrictStr, Field(pattern=r"^[A-Za-z][A-Za-z0-9_-]{0,31}$")]
    label: StrictStr = Field(min_length=1, max_length=64)
    description: StrictStr = Field(min_length=1, max_length=256)
    media_types: list[StrictStr] = Field(min_length=1, max_length=16)
    extensions: list[StrictStr] = Field(max_length=16)
    min_files: StrictInt = Field(ge=0, le=32)
    max_files: StrictInt = Field(ge=1, le=32)
    max_file_bytes: StrictInt = Field(ge=1, le=512 * 1024**2)
    max_total_bytes: StrictInt = Field(ge=1, le=1024**3)

    @model_validator(mode="after")
    def limits_are_consistent(self) -> CompiledJobInputSlot:
        if self.min_files > self.max_files:
            raise ValueError("job input slot file count limits are inconsistent")
        if self.max_file_bytes > self.max_total_bytes:
            raise ValueError("job input slot byte limits are inconsistent")
        if len(self.media_types) != len(set(self.media_types)):
            raise ValueError("job input slot media types must be unique")
        if len(self.extensions) != len(set(self.extensions)):
            raise ValueError("job input slot extensions must be unique")
        if any(
            re.fullmatch(r"\.[a-z0-9][a-z0-9._-]{0,15}", extension) is None
            for extension in self.extensions
        ):
            raise ValueError("job input slot extension is invalid")
        return self


class CompiledJobInput(_Strict):
    """Typed compiled form of the public ``RecipeJobInput`` declaration;
    inputs are staged read-only under /inputs."""

    required: StrictBool
    media_types: list[StrictStr] = Field(min_length=1, max_length=16)
    max_bytes: StrictInt = Field(ge=1, le=1024**3)
    slots: list[CompiledJobInputSlot] | None = Field(
        default=None, min_length=1, max_length=32
    )

    @field_validator("media_types")
    @classmethod
    def media_types_are_canonical(cls, value: list[str]) -> list[str]:
        if len(value) != len(set(value)):
            raise ValueError("job input media types must be unique")
        if any(
            re.fullmatch(r"[a-z0-9!#$&^_.+-]+/[a-z0-9!#$&^_.+-]+", media_type) is None
            for media_type in value
        ):
            raise ValueError("job input media type is invalid")
        return value

    @model_validator(mode="after")
    def slots_match_contract(self) -> CompiledJobInput:
        if self.slots is None:
            return self
        identifiers = [slot.id for slot in self.slots]
        if len(identifiers) != len(set(identifiers)):
            raise ValueError("job input slot IDs must be unique")
        allowed_media_types = set(self.media_types)
        if any(
            not set(slot.media_types) <= allowed_media_types
            or slot.max_total_bytes > self.max_bytes
            for slot in self.slots
        ):
            raise ValueError("job input slot exceeds the input contract")
        return self


class CompiledJob(_Strict):
    interface: Literal[
        "image-job", "audio-job", "video-job", "mesh-job", "artifact-job"
    ]
    input: CompiledJobInput | None
    # Maximum inactivity since Docker start or its latest timestamped job output.
    timeout_seconds: int = Field(ge=1, le=3600)


class CompiledExecutionPlan(_Strict):
    identity: CompiledIdentity
    runtime: CompiledRuntime
    artifacts: list[CompiledArtifact] = Field(
        min_length=1, max_length=MAX_COMPILED_EXECUTION_PLAN_ARTIFACTS
    )
    runtime_image: CompiledRuntimeImage
    security: CompiledSecurity
    topology: CompiledTopology
    lifecycle: CompiledLifecycle
    endpoint: CompiledEndpoint | None
    job: CompiledJob | None

    @model_validator(mode="after")
    def cross_fields_match(self, info: ValidationInfo) -> CompiledExecutionPlan:
        if (self.endpoint is None) == (self.job is None):
            raise ValueError("exactly one compiled interface is required")
        placement = self.runtime.placement
        if placement.rank >= placement.world_size:
            raise ValueError("compiled placement identity is inconsistent")
        if self.endpoint is not None:
            if placement.port is None:
                raise ValueError("compiled serving placement port is unavailable")
        elif placement.port is not None:
            raise ValueError("compiled job placement must not have a port")
        if placement.world_size < self.topology.node_count:
            raise ValueError("compiled topology bounds are invalid")
        if placement.world_size == 1 and (
            placement.rank != 0
            or placement.local_address is not None
            or placement.master_address is not None
            or placement.master_port is not None
        ):
            raise ValueError("single-node rendezvous is invalid")
        physical_by_path: dict[tuple[str, str], tuple[object, ...]] = {}
        file_paths: dict[tuple[str, str], str] = {}
        paths: set[tuple[str, str]] = set()
        for artifact in self.artifacts:
            physical = (
                artifact.file_id,
                artifact.sha256,
                artifact.size_bytes,
                artifact.model.publisher,
                artifact.model.slug,
                artifact.model.content_sha256,
            )
            physical_key = (artifact.selection_id, artifact.path)
            previous = physical_by_path.get(physical_key)
            if previous is not None and previous != physical:
                raise ValueError("compiled artifact physical identity conflicts")
            physical_by_path[physical_key] = physical
            file_key = (artifact.selection_id, artifact.file_id)
            previous_path = file_paths.get(file_key)
            if previous_path is not None and previous_path != artifact.path:
                raise ValueError("compiled artifact file identity conflicts")
            file_paths[file_key] = artifact.path
            mount_path = (artifact.mount.target, artifact.path)
            if mount_path in paths:
                raise ValueError("compiled artifact mount target is duplicated")
            paths.add(mount_path)
        # Teardown needs the current typed storage identity, not permission to
        # launch it. Keep all structural, artifact and security checks above;
        # only launch-time fabric/network admission is irrelevant to removal.
        if info.context is COMPILED_PLAN_STORAGE_CONTEXT:
            return self
        native_fabric = placement.world_size > 1 and placement.master_port is not None
        if native_fabric and (
            self.topology.node_count < 2
            or placement.local_address is None
            or placement.master_address is None
            or self.endpoint is None
            or not self.security.gpu
        ):
            raise ValueError("native fabric placement is incomplete")
        expected_network = (
            "host"
            if native_fabric
            else "bridge"
            if placement.endpoint_address is not None
            else "none"
        )
        if self.security.network_mode != expected_network:
            raise ValueError("compiled network policy does not match placement")
        return self

    @classmethod
    def parse(cls, value: object) -> CompiledExecutionPlan:
        try:
            return cls.model_validate(value)
        except Exception as error:
            raise AgentProtocolError("compiled execution plan is invalid") from error

    def to_mapping(self) -> dict[str, object]:
        return self.model_dump(mode="json")


def validate_compiled_execution_plan(value: object) -> CompiledExecutionPlan:
    return CompiledExecutionPlan.parse(value)


__all__ = [
    "CompiledArtifact",
    "CompiledArtifactMount",
    "CompiledEndpoint",
    "CompiledEnvironmentEntry",
    "CompiledExecutionPlan",
    "CompiledExecutionPlanError",
    "CompiledIdentity",
    "CompiledJob",
    "CompiledJobInput",
    "CompiledJobInputSlot",
    "CompiledLifecycle",
    "CompiledModelIdentity",
    "CompiledPlacement",
    "CompiledRuntime",
    "CompiledRuntimeImage",
    "CompiledSecurity",
    "CompiledSecurityMount",
    "CompiledTopology",
    "validate_compiled_execution_plan",
]
