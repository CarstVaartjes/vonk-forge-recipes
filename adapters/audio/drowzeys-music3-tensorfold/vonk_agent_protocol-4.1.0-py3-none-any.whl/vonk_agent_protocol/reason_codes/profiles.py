"""Profiles reason codes."""

from ..wire_model import WireEnum


class ProfileReasonCode(WireEnum):
    """Reasons a fleet profile cannot be applied or is waiting."""

    ADMISSION_BUSY = "profile.admission_busy"
    ADMISSION_DEFECT = "profile.admission_defect"
    ADMISSION_EFFECT_BUSY = "profile.admission_effect_busy"
    APPLICATION_INTENT_INVALID = "profile.application_intent.invalid"
    CHOICES_UNREADABLE = "profile.choices_unreadable"
    #: A newer load waits for an older load to finish the assignments it keeps.
    CONTINUING_ASSIGNMENTS_PENDING = "profile.continuing_assignments_pending"
    DEFINITION_UNAVAILABLE = "profile.definition_unavailable"
    CLEANUP_DELEGATED = "profile.cleanup_delegated"
    DISTRIBUTED_CROSS_SCOPE = "profile.distributed_cross_scope"
    FAILURE_REPEATED = "profile.failure_repeated"
    INCOMPLETE_MULTI_SPARK_MODEL = "profile.incomplete_multi_spark_model"
    INTERRUPTION_EXPECTED = "profile.interruption_expected"
    PENDING_CROSS_SCOPE = "profile.pending_cross_scope"
    PREPARATION_NOT_STARTED = "profile.preparation_not_started"
    PREPARATION_SCOPE_MISMATCH = "profile.preparation_scope_mismatch"
    PREPARATION_UNAVAILABLE = "profile.preparation_unavailable"
    RECIPE_UNAVAILABLE = "profile.recipe_unavailable"
    RECOVERY_ASSIGNMENTS_CHANGED = "profile.recovery_assignments_changed"
    RECOVERY_CACHE_PENDING = "profile.recovery_cache_pending"
    RECOVERY_SCOPE_CHANGED = "profile.recovery_scope_changed"
    RECOVERY_WAITING = "profile.recovery_waiting"
    REQUEST_INVALID = "profile.request_invalid"
    RESOURCE_RECHECK_UNAVAILABLE = "profile.resource_recheck_unavailable"
    RETRY_CONFLICT = "profile.retry_conflict"
    RETRY_EXECUTOR_UNAVAILABLE = "profile.retry_executor_unavailable"
    RETRY_INTENT_UNAVAILABLE = "profile.retry_intent_unavailable"
    RETRY_REVIEW_UNAVAILABLE = "profile.retry_review_unavailable"
    REVIEW_STALE = "profile.review_stale"
    RUNTIME_IMAGE_REBUILD_PENDING = "profile.runtime_image_rebuild_pending"
    SHARED_INSTALLATION_SCOPE = "profile.shared_installation_scope"
    SPARK_REMOVED = "profile.spark_removed"
    SPARK_UNAVAILABLE = "profile.spark_unavailable"
    STALE_PLAN = "profile.stale_plan"
    SWITCH_AUTHORITY_UNAVAILABLE = "profile.switch_authority_unavailable"
    SWITCH_SCOPE_UNRESOLVED = "profile.switch_scope_unresolved"
    TOPOLOGY_INCOMPLETE = "profile.topology_incomplete"
    RECOVERY_ARTIFACT_CHANGED = "profile.recovery_artifact_changed"
    RUNTIME_IMAGE_CHANGED = "profile.runtime-image-changed"
    SELECTION_LOST = "profile.selection_lost"
    ASSET_RESERVATION_UNAVAILABLE = "profile.asset_reservation_unavailable"


#: The codes a Fleet profile request is refused with (HTTP 409): it never
#: succeeds as sent, so a client fails fast and shows the detail.  Every other
#: profile conflict is a wait, answered 503 with ``Retry-After``.
PROFILE_REFUSAL_CODES = frozenset(
    {
        ProfileReasonCode.ADMISSION_DEFECT,
        ProfileReasonCode.DEFINITION_UNAVAILABLE,
        ProfileReasonCode.REQUEST_INVALID,
        ProfileReasonCode.REVIEW_STALE,
        ProfileReasonCode.SELECTION_LOST,
        ProfileReasonCode.STALE_PLAN,
    }
)


class ProjectionCode(WireEnum):
    """Warnings and attention items of the fleet and library projections."""

    CPU_LOW_CLOCK = "cpu.low-clock"
    #: The same deterministic evidence repeated up to the one failure limit
    #: with no success between: a platform fault to look at, never acted on.
    EVIDENCE_REPEATING = "evidence.repeating"
    FLEET_FRAME_BUDGET_EXCEEDED = "fleet.frame_budget_exceeded"
    FLEET_FRAME_ENCODING_UNAVAILABLE = "fleet.frame_encoding_unavailable"
    FLEET_STORED_EVENT_PAYLOAD_UNAVAILABLE = "fleet.stored_event_payload_unavailable"
    OBSERVATION_TRANSFER_UNAVAILABLE = "observation.transfer_unavailable"
    #: A desktop session holds memory recipes count on (the Spark runs headless).
    HOST_DESKTOP_RUNNING = "host.desktop-running"
    #: The Spark boots to the desktop.
    HOST_DESKTOP_AT_BOOT = "host.desktop-at-boot"
    #: The GPU clock ceiling is not applied: sustained load can power it off.
    HOST_GPU_CLOCK_UNCAPPED = "host.gpu-clock-uncapped"
    MODEL_STORE_LAYOUT = "model.store_layout"
    INSTALL_PARTIAL = "install.partial"
    INVENTORY_MISSING = "inventory.missing"
    INVENTORY_STALE = "inventory.stale"
    NETWORK_NAS_ROUTE_WIFI_NO_WIRED_PORT = "network.nas-route-wifi-no-wired-port"
    NETWORK_NAS_ROUTE_WIFI_WIRED_PORT_DOWN = "network.nas-route-wifi-wired-port-down"
    NETWORK_NAS_ROUTE_WIFI_WIRED_PORT_UNUSED = (
        "network.nas-route-wifi-wired-port-unused"
    )
    #: Measured: this Spark's recent copies from the NAS are far slower than another's.
    NETWORK_NAS_TRANSFER_SLOW = "network.nas-transfer-slow"
    NODE_OFFLINE = "node.offline"
    PROFILE_RETRYING = "profile.retrying"
    RECIPE_UPDATE_AVAILABLE = "recipe.update_available"
    RUN_DEGRADED = "run.degraded"
    TELEMETRY_DELAYED = "telemetry.delayed"
    TELEMETRY_MISSING = "telemetry.missing"
    TELEMETRY_STALE = "telemetry.stale"
