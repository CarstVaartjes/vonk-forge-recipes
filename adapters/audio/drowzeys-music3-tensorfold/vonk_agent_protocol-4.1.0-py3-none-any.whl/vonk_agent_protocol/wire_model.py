"""Shared strict JSON boundary helpers for Pydantic wire models."""

from __future__ import annotations

import json
from collections.abc import Iterator, Mapping
from copy import deepcopy
from datetime import datetime
from enum import StrEnum
from typing import Annotated, Any, Literal, cast

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    GetCoreSchemaHandler,
    field_validator,
    model_validator,
)
from pydantic_core import CoreSchema, core_schema

# RecipeRun owns generations in a PostgreSQL BIGINT column. The helper and
# agent carry that exact identity; their storage/argv representations must not
# impose a smaller integer domain.
MAX_RUN_GENERATION = 2**63 - 1


def _check_literal_type(value: object, expected: tuple[Any, ...]) -> object:
    if any(type(item) in (bool, int, float) for item in expected) and not any(
        type(value) is type(item) and value == item for item in expected
    ):
        raise ValueError("literal must use its exact JSON scalar type")
    return value


def _wrap_numeric_literals(schema: CoreSchema) -> CoreSchema:
    if not isinstance(schema, dict):
        return schema
    if schema.get("type") == "literal":
        expected = tuple(schema.get("expected", ()))
        if any(type(item) in (bool, int, float) for item in expected):
            return core_schema.no_info_before_validator_function(
                lambda value: _check_literal_type(value, expected), schema
            )
        return schema
    for key, nested in tuple(schema.items()):
        if isinstance(nested, dict):
            schema[key] = _wrap_numeric_literals(cast(CoreSchema, nested))
        elif isinstance(nested, list):
            schema[key] = [
                _wrap_numeric_literals(cast(CoreSchema, item))
                if isinstance(item, dict)
                else item
                for item in nested
            ]
    return schema


def _bind_string_enum_values(schema: CoreSchema) -> CoreSchema:
    """Complete a string enum from its own member value in either mode.

    Pydantic's strict mode resolves a string enum field only from an enum
    *instance*; it rejects the member's own string, which its JSON mode and the
    published JSON Schema both accept.  A JSON consumer that decodes a body to
    Python objects before validating -- FastAPI does exactly that for
    ``body: Model`` parameters -- therefore refused a value the wire contract
    declares valid.  A truthful ``failure_kind`` in an agent result hit that
    edge, so the Controller answered HTTP 422 to every replay and the reporting
    agent lost its lease.

    Only an exact, already-declared member string is bound; every other value
    reaches Pydantic's own enum error unchanged, so this narrows the mode
    difference without weakening the contract.
    """

    if not isinstance(schema, dict):
        return schema
    if schema.get("type") == "enum" and schema.get("sub_type") == "str":
        enum_type = cast(type[StrEnum], schema.get("cls"))
        members = frozenset(schema.get("members", ()))

        def bind_member(value: object) -> object:
            if type(value) is str and value in members:
                return enum_type(value)
            return value

        return core_schema.no_info_before_validator_function(bind_member, schema)
    for key, nested in tuple(schema.items()):
        if isinstance(nested, dict):
            schema[key] = _bind_string_enum_values(cast(CoreSchema, nested))
        elif isinstance(nested, list):
            schema[key] = [
                _bind_string_enum_values(cast(CoreSchema, item))
                if isinstance(item, dict)
                else item
                for item in nested
            ]
    return schema


def typed_tag() -> Any:
    """Mark a union member's tag so the Rust generator types it.

    A tag is a required ``Literal`` field.  The schema keeps its ``const``; the
    marker tells ``vonk-wire-codegen`` to declare a one-variant enum for it
    instead of a free string, so a generated constructor cannot build a member
    whose tag disagrees with its shape.
    """

    return Field(json_schema_extra={"x-vonk-typed-tag": True})


class WireEnum(StrEnum):
    """A closed word set that validates from its own member string in every mode.

    :func:`_bind_string_enum_values` completes an enum field only when the
    field's schema carries the enum inline; a field that refers to an enum
    already defined elsewhere in the schema graph keeps Pydantic's strict
    instance-only check, and the Controller's body decoding (which hands the
    model Python objects) would refuse a member string the wire contract
    declares valid.  Binding at the enum itself covers every referring field.
    """

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return _bind_string_enum_values(handler(source_type))


class StrictJSONModel(BaseModel):
    """Hold the JSON scalar rules that Pydantic's modes disagree about.

    Pydantic's strict mode still accepts ``True`` and ``1.0`` for
    ``Literal[1]`` because they compare equal to ``1`` in Python, so wire
    models require an exact type/value match.  In the other direction strict
    mode rejects a string enum's own member string when the input was decoded
    to Python objects, so a declared member string is bound here once for every
    mode.  Numeric/enum coercion beyond those two rules remains Pydantic's
    responsibility.
    """

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        # Once the class is built its stored schema is this hook's own result.
        # Reuse it, as Pydantic does for models without the hook: otherwise
        # every route, field and nested reference regenerates and deep-copies
        # the complete model schema again.
        # (A class still being built holds a placeholder that is not a dict.)
        built = cls.__dict__.get("__pydantic_core_schema__")
        if source_type is cls and isinstance(built, dict):
            return cast(CoreSchema, built)
        return _bind_string_enum_values(
            _wrap_numeric_literals(deepcopy(handler(source_type)))
        )


class WireModel(StrictJSONModel, Mapping[str, Any]):
    """Immutable JSON message with exact structure and scalar types."""

    model_config = ConfigDict(
        extra="forbid", strict=True, frozen=True, allow_inf_nan=False
    )

    def __getitem__(self, key: str) -> Any:
        if key in self.__class__.model_fields:
            return getattr(self, key)
        try:
            return (self.model_extra or {})[key]
        except (KeyError, TypeError):
            raise KeyError(key) from None

    def __iter__(self) -> Iterator[str]:
        # Mapping iteration exposes explicitly supplied fields. Canonical wire
        # serialization separately applies the model-aware default/null policy.
        declared = (
            name
            for name in self.__class__.model_fields
            if name in self.model_fields_set
        )
        extras = iter(self.model_extra or {})
        return iter((*declared, *extras))

    def __len__(self) -> int:
        return len(self.model_fields_set) + len(self.model_extra or {})


Digest = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]


def strict_json_datetime(value: object) -> object:
    """Parse a JSON string timestamp for a ``datetime`` field in strict mode."""

    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value)
        except ValueError as error:
            raise ValueError("timestamp is invalid") from error
    return value


# The spelling rule of a failure code whose vocabulary is open: a stored
# failure body carries codes from several enums (the agent's ``FailureCode``,
# Controller-side codes) and from agents older than those enums, and the
# Controller's operator failure evidence repeats them.  A field with one closed
# producer vocabulary is typed by that enum instead.
ERROR_CODE_PATTERN = r"^[a-z][a-z0-9_.]{0,63}$"

ErrorCode = Annotated[str, Field(pattern=ERROR_CODE_PATTERN)]


class OperationCheckpoint(WireModel):
    """Restart-safe cursor identifying a durable operation unit."""

    key: str = Field(min_length=1, max_length=128)
    sequence: int = Field(strict=True, ge=0)
    cursor: str | None = Field(default=None, max_length=512)
    digest: Digest | None = None


class OperationMemberProgress(WireModel):
    """Progress for one node, rank, shard, or other operation member."""

    member_id: str = Field(min_length=1, max_length=128)
    phase: str = Field(min_length=1, max_length=80)
    kind: str | None = Field(default=None, min_length=1, max_length=80)
    object_sha256: Digest | None = None
    completed_bytes: int = Field(default=0, strict=True, ge=0)
    total_bytes: int | None = Field(default=None, strict=True, ge=0)
    bytes_per_second: float | None = Field(default=None, strict=True, ge=0, le=10**15)
    eta_seconds: float | None = Field(default=None, strict=True, ge=0, le=10**9)
    smoothed_bytes_per_second: float | None = Field(
        default=None, strict=True, ge=0, le=10**15
    )
    completed_items: int | None = Field(default=None, strict=True, ge=0)
    total_items: int | None = Field(default=None, strict=True, ge=0)
    elapsed_seconds: float | None = Field(default=None, strict=True, ge=0)
    observed_at: str | None = Field(default=None, max_length=64)
    last_progress_at: str | None = Field(default=None, max_length=64)
    activity: Literal["active", "waiting", "possibly_stalled"] | None = None
    state: str = Field(default="running", min_length=1, max_length=32)

    @field_validator("observed_at", "last_progress_at")
    @classmethod
    def timestamp_has_timezone(cls, value: str | None) -> str | None:
        if value is not None and datetime.fromisoformat(value).tzinfo is None:
            raise ValueError("progress timestamp must include a timezone")
        return value

    @model_validator(mode="after")
    def totals_are_consistent(self) -> OperationMemberProgress:
        # Transfer observations may outgrow an earlier estimate, including
        # bytes accumulated across phases. They never invalidate the operation.
        if self.total_bytes is not None:
            object.__setattr__(
                self, "total_bytes", max(self.total_bytes, self.completed_bytes)
            )
        if (
            self.total_items is not None
            and (self.completed_items or 0) > self.total_items
        ):
            raise ValueError("completed items cannot exceed total items")
        return self


class OperationProgress(WireModel):
    """Canonical durable progress payload shared by Controller and agents.

    completed_bytes measures transferred bytes across phases (including Docker
    pulls); it is not an artifact-availability receipt. completed_items counts
    completed objects only. Subprocess observations use activity_sequence.
    """

    phase: str = Field(min_length=1, max_length=80)
    kind: str | None = Field(default=None, min_length=1, max_length=80)
    object_sha256: Digest | None = None
    completed_bytes: int = Field(default=0, strict=True, ge=0)
    total_bytes: int | None = Field(default=None, strict=True, ge=0)
    total_bytes_known: bool = False
    bytes_per_second: float | None = Field(default=None, strict=True, ge=0, le=10**15)
    eta_seconds: float | None = Field(default=None, strict=True, ge=0, le=10**9)
    smoothed_bytes_per_second: float | None = Field(
        default=None, strict=True, ge=0, le=10**15
    )
    completed_items: int | None = Field(default=None, strict=True, ge=0)
    total_items: int | None = Field(default=None, strict=True, ge=0)
    elapsed_seconds: float | None = Field(default=None, strict=True, ge=0)
    observed_at: str | None = Field(default=None, max_length=64)
    last_progress_at: str | None = Field(default=None, max_length=64)
    activity: Literal["active", "waiting", "possibly_stalled"] | None = None
    # An opaque monotonic observation sequence, not transferred bytes or items.
    activity_sequence: int | None = Field(default=None, strict=True, ge=0)
    checkpoint: OperationCheckpoint | None = None
    members: list[OperationMemberProgress] = Field(
        default_factory=list, max_length=1024
    )

    @field_validator("observed_at", "last_progress_at")
    @classmethod
    def timestamp_has_timezone(cls, value: str | None) -> str | None:
        if value is not None and datetime.fromisoformat(value).tzinfo is None:
            raise ValueError("progress timestamp must include a timezone")
        return value

    @model_validator(mode="after")
    def totals_are_explicit_and_consistent(self) -> OperationProgress:
        if self.total_bytes_known != (self.total_bytes is not None):
            raise ValueError(
                "total_bytes_known must be false when total_bytes is unknown and true when present"
            )
        # Transfer observations may outgrow an earlier estimate, including
        # bytes accumulated across phases. They never invalidate the operation.
        if self.total_bytes is not None:
            object.__setattr__(
                self, "total_bytes", max(self.total_bytes, self.completed_bytes)
            )
        if (
            self.total_items is not None
            and (self.completed_items or 0) > self.total_items
        ):
            raise ValueError("completed items cannot exceed total items")
        member_ids = [member.member_id for member in self.members]
        if len(member_ids) != len(set(member_ids)):
            raise ValueError("operation progress members must be unique")
        return self


def normalize_operation_progress(value: Mapping[str, object]) -> dict[str, object]:
    """Validate progress and retain every meaningful declared default."""

    from .contracts import canonical_message

    return json.loads(canonical_message(OperationProgress.model_validate(value)))


__all__ = [
    "ERROR_CODE_PATTERN",
    "ErrorCode",
    "OperationCheckpoint",
    "OperationMemberProgress",
    "OperationProgress",
    "StrictJSONModel",
    "WireEnum",
    "WireModel",
    "normalize_operation_progress",
    "typed_tag",
]
