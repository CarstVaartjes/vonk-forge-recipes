"""The EXL3 linear (``cuda/exl3/linear.py``, ``linear.cu``, ``decode.cuh``) on a GPU, on synthetic layers: the device
decoder against ``format.unpack`` bit for bit, the layer against a float64 reference built from the decoded weight,
and row invariance — every row's bits alone, in 2, 3, 16, 17, 64 and 128-row windows and under every split plan."""

from __future__ import annotations

import numpy as np
import pytest
import torch

from tensorfold.cuda.exl3 import format as fmt
from tensorfold.cuda.exl3 import linear

if not torch.cuda.is_available():
    pytest.skip("CUDA only", allow_module_level=True)

COMBOS = [("3inst", b) for b in (1, 2, 3, 4, 5, 6, 7, 8)] + [("mcg", b) for b in (1, 2, 3, 4, 6, 8)] \
    + [("mul1", b) for b in (1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 7, 8)]
ROWS = (1, 2, 3, 16, 17, 64, 128)


def _tensors(codebook: str, bits: float, kt: int = 16, nt: int = 8, seed: int = 0):
    """A synthetic group: K and N are multiples of 128 (ExLlamaV3 pads), the trellis words random."""
    rng = np.random.default_rng(seed)
    trellis = torch.from_numpy(rng.integers(-2**15, 2**15, size=(kt, nt, fmt.tile_words(bits))).astype(np.int16))
    k, n = 16 * kt, 16 * nt
    suh = torch.from_numpy((rng.standard_normal(k) * 0.05).astype(np.float16))
    svh = torch.from_numpy((rng.standard_normal(n) * 0.05).astype(np.float16))
    return trellis, suh, svh


def _reference(trellis: torch.Tensor, suh: torch.Tensor, svh: torch.Tensor, bits: float, codebook: str,
               x: torch.Tensor) -> torch.Tensor:
    """float64 forward with the same fp16 rounding of the rotated input as the kernel's ``rot_in``."""

    xs = x.double().cpu().numpy() * suh.double().numpy()
    xh = fmt.rotate(xs, -1).astype(np.float16).astype(np.float64)
    wq = fmt.unpack(trellis, bits, codebook).astype(np.float64)
    return torch.from_numpy(fmt.rotate(xh @ wq, -1) * svh.double().numpy())


@pytest.mark.parametrize("codebook,bits", COMBOS)
def test_decode_is_bit_exact(codebook: str, bits: float):
    trellis, _, _ = _tensors(codebook, bits)
    w = linear.unpack_cuda(trellis, codebook)
    ref = torch.from_numpy(fmt.unpack(trellis, bits, codebook)).view(torch.int16)
    assert torch.equal(w.cpu().view(torch.int16), ref)


@pytest.mark.parametrize("codebook,bits", [("mul1", 2), ("mul1", 3), ("mul1", 6), ("3inst", 4), ("mcg", 8)])
@pytest.mark.parametrize("split", [(1, 4), (2, 4), (8, 8), (2, 8)])
def test_row_invariance(codebook: str, bits: float, split: tuple[int, int]):
    """Rows 1..128 identical in every window and under every split of K (the contract's 1, 2, 3, 16, 17, 64, 128)."""

    trellis, suh, svh = _tensors(codebook, bits, kt=64)          # K = 1024: every split divides
    layer = linear.Exl3Linear.from_tensors(trellis, suh, svh, codebook)
    kt = trellis.shape[0]
    if kt % (split[0] * split[1]):
        pytest.skip(f"K/16 = {kt} does not divide over split {split}")
    layer.split = split
    x = torch.randn((128, layer.k), device="cuda").half()
    whole = layer(x)
    for m in ROWS:
        window = layer(x[:m])
        assert torch.equal(window, whole[:m]), f"rows 1..{m}"
        for r in sorted({0, m // 2, m - 1}):
            assert torch.equal(layer(x[r:r + 1])[0], whole[r]), f"row {r} alone vs {m}-row window"


@pytest.mark.parametrize("codebook,bits", [("mul1", 2), ("mul1", 4), ("mul1", 6), ("3inst", 8), ("mcg", 4)])
def test_matches_the_float64_reference(codebook: str, bits: float):
    trellis, suh, svh = _tensors(codebook, bits)
    layer = linear.Exl3Linear.from_tensors(trellis, suh, svh, codebook)
    x = torch.randn((17, layer.k), device="cuda").half()
    got = layer(x, out_dtype=torch.float32)
    want = _reference(trellis, suh, svh, bits, codebook, x)
    assert ((got.double().cpu() - want).norm() / want.norm()).item() < 2e-3


@pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16, torch.float32])
def test_input_and_output_dtypes(dtype):
    trellis, suh, svh = _tensors("mul1", 4)
    layer = linear.Exl3Linear.from_tensors(trellis, suh, svh, "mul1")
    x = torch.randn((8, layer.k), device="cuda").to(dtype)
    half = layer(x.half(), out_dtype=torch.float32)
    got = layer(x, out_dtype=torch.float32)
    assert torch.allclose(got, half, rtol=2e-3, atol=2e-3)
    assert layer(x).dtype == dtype and layer(x, out_dtype=torch.bfloat16).dtype == torch.bfloat16


def test_bias_and_the_scale_words_of_older_checkpoints():
    trellis, suh, svh = _tensors("mcg", 4)
    bias = torch.from_numpy((np.random.default_rng(2).standard_normal(svh.numel()) * 0.05).astype(np.float16))
    plain = linear.Exl3Linear.from_tensors(trellis, suh, svh, "mcg")
    with_bias = linear.Exl3Linear.from_tensors(trellis, suh, svh, "mcg", bias=bias)
    x = torch.randn((3, plain.k), device="cuda").half()
    assert torch.allclose((with_bias(x, out_dtype=torch.float32) - plain(x, out_dtype=torch.float32)).cpu(),
                          bias.float(), rtol=2e-2, atol=2e-2)
    def pack(scales: torch.Tensor) -> torch.Tensor:            # bit b of word w set means element 16w + b is -1
        neg = (np.asarray(scales) < 0).reshape(-1, 16).astype(np.uint16)
        words = (neg * (1 << np.arange(16, dtype=np.uint16))).sum(1).astype(np.uint16)
        return torch.from_numpy(words.view(np.int16).copy())

    packed_su, packed_sv = pack(suh), pack(svh)
    signs = linear.Exl3Linear.from_tensors(trellis, packed_su, packed_sv, "mcg")
    assert torch.equal(signs.suh.cpu(), torch.from_numpy(fmt.unpack_signs(packed_su)))
    assert torch.equal(signs.svh.cpu(), torch.from_numpy(fmt.unpack_signs(packed_sv)))


def test_stored_layout_gives_the_same_bits():
    trellis, suh, svh = _tensors("mul1", 3)
    strips = linear.Exl3Linear.from_tensors(trellis, suh, svh, "mul1", layout="strips")
    stored = linear.Exl3Linear.from_tensors(trellis, suh, svh, "mul1", layout="stored")
    assert stored.words.shape != strips.words.shape or not torch.equal(stored.words, strips.words)
    x = torch.randn((5, strips.k), device="cuda").half()
    assert torch.equal(strips(x), stored(x))
    assert torch.equal(strips.unpack().cpu().view(torch.int16), stored.unpack().cpu().view(torch.int16))


def test_the_plan_depends_on_the_shape_only():
    assert linear.plan(4096, 12288) == linear.plan(4096, 12288)
    assert linear.plan(4096, 12288) == (1, 8)                            # 96 blocks: one per program, eight warps
    assert linear.plan(8192, 4096)[0] > 1                                # 32 blocks: split K to fill the SMs
    assert linear.plan(4096, 152576) == (1, 8)                           # plenty of programs already
    assert linear.plan(4096, 2048)[0] >= linear.plan(8192, 4096)[0]      # narrower still: at least as many splits
    for k, n in ((128, 128), (256, 256), (4096, 12288), (8192, 4096), (4096, 152576), (4096, 2048)):
        sk, wk = linear.plan(k, n)
        per_warp = (k // 16) // (sk * wk)
        assert (k // 16) % (sk * wk) == 0 and per_warp >= 1
        assert per_warp >= 8 or (k // 16) < 8 * 8              # only a tiny layer may go below eight tiles


@pytest.mark.parametrize("codebook,bits", [("mul1", 3), ("mcg", 4), ("3inst", 4)])
@pytest.mark.parametrize("layout", ["strips", "stored"])
def test_split_k_without_bias_agrees_with_zero_bias_and_preserves_rows(codebook, bits, layout):
    """Narrow projections exercise the last split's optional bias load across ragged row windows."""

    trellis, suh, svh = _tensors(codebook, bits, kt=256, nt=128, seed=23)
    plain = linear.Exl3Linear.from_tensors(trellis, suh, svh, codebook, layout=layout)
    zero = linear.Exl3Linear.from_tensors(trellis, suh, svh, codebook, bias=torch.zeros_like(svh), layout=layout)
    bias = torch.linspace(-0.125, 0.125, svh.numel(), dtype=torch.float16)
    biased = linear.Exl3Linear.from_tensors(trellis, suh, svh, codebook, bias=bias, layout=layout)
    assert plain.split[0] > 1 and plain.split == zero.split == biased.split
    rng = torch.Generator(device="cuda").manual_seed(186)
    x = torch.randn((17, plain.k), device="cuda", generator=rng).half()
    for rows in (1, 3, 17):
        out = plain(x[:rows], out_dtype=torch.float32)
        torch.cuda.synchronize()
        assert torch.isfinite(out).all()
        with_zero = zero(x[:rows], out_dtype=torch.float32)
        assert torch.equal(out, with_zero)
        nonzero = out != 0                 # adding +0 may turn an absent bias's -0 into +0
        assert torch.equal(out[nonzero].view(torch.int32), with_zero[nonzero].view(torch.int32))
        expected = bias.to(device="cuda", dtype=torch.float32).expand(rows, -1)
        got_bias = biased(torch.zeros_like(x[:rows]), out_dtype=torch.float32)
        assert torch.equal(expected.view(torch.int32), got_bias.view(torch.int32))
        alone = torch.cat([plain(row[None], out_dtype=torch.float32) for row in x[:rows]])
        assert torch.equal(out.view(torch.int32), alone.view(torch.int32))


MODES = (0, 6)                  # linear.MODE: linear_kernel at every row count; the mid-M kernels

MODES = (0, 6, 7)               # linear.MODE: linear_kernel at every row count; the mid-M kernels; linear_wc

# (bits, K, N, split): the 27B's projections with the loader's splits, a split layer of 32+ column blocks, others
MODE_SHAPES = [(4, 17408, 5120, (1, 8)), (4, 5120, 10240, (5, 4)), (4, 5120, 6144, (5, 2)), (4, 6144, 5120, (16, 2)),
               (3, 17408, 5120, (4, 2)), (6, 5120, 4096, (5, 2)), (6, 1024, 2048, (1, 8)), (2, 2048, 1024, (2, 4))]


@pytest.mark.parametrize("bits,k,n,split", MODE_SHAPES, ids=lambda v: str(v))
@pytest.mark.parametrize("codebook", ["mul1", "3inst"])
def test_every_kernel_mode_gives_linear_kernels_bits(monkeypatch, codebook, bits, k, n, split):
    """Rows 1..128: each mode's output equals linear_kernel's bit for bit, and a row alone equals it inside 128."""

    trellis, suh, svh = _tensors(codebook, bits, kt=k // 16, nt=n // 16, seed=k + n)
    layer = linear.Exl3Linear.from_tensors(trellis, suh, svh, codebook)
    layer.split = split
    x = torch.randn((128, k), device="cuda").half()
    monkeypatch.setattr(linear, "MODE", 0)
    ref = layer(x)
    for mode in MODES[1:]:
        monkeypatch.setattr(linear, "MODE", mode)
        for m in range(1, 129):
            assert torch.equal(layer(x[:m]), ref[:m]), f"mode {mode}, {m} rows"
        for r in (0, 17, 127):
            assert torch.equal(layer(x[r:r + 1]), ref[r:r + 1]), f"mode {mode}, row {r} alone"
