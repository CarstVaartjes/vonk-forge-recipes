import select
import socket
import threading
from typing import Any, Callable


class RequestCancelled(Exception):
    pass


class Cancellation:
    def __init__(self, disconnected: Callable[[], bool] | None = None):
        self._event = threading.Event()
        self._disconnected = disconnected

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        if not self._event.is_set() and self._disconnected is not None and self._disconnected():
            self.cancel()
        return self._event.is_set()

    def check(self) -> None:
        if self.cancelled:
            raise RequestCancelled("request cancelled")


def _readable(connection: socket.socket) -> bool:
    """Whether a read would not block; ``poll`` where available, since ``select`` refuses descriptors past 1023."""

    if hasattr(select, "poll"):
        p = select.poll()
        p.register(connection, select.POLLIN | select.POLLPRI)
        return bool(p.poll(0))
    ready, _, _ = select.select([connection], [], [], 0)
    return bool(ready)


def socket_cancellation(connection: socket.socket) -> Cancellation:
    def disconnected() -> bool:
        try:
            if connection.fileno() < 0:
                return True
            if not _readable(connection):
                return False
            return connection.recv(1, socket.MSG_PEEK | getattr(socket, "MSG_DONTWAIT", 0)) == b""
        except BlockingIOError:
            return False
        except OSError:
            return True
        except ValueError:
            return False

    return Cancellation(disconnected)


class PrefillGuard:
    def __init__(self, cancellation: Cancellation, memory: Any = None, *, wide: bool = True):
        self.cancellation, self.memory = cancellation, memory
        self.wide = bool(wide)          # whether this fill step may take several plan chunks in one forward
        self.refused = False                    # one reason line per fill once memory refuses a copy (issue #155)

    def pass_width(self, cache: Any, sizes: list[int]) -> int:
        """How many of these consecutive plan chunks one forward may take: 1 unless wide, then what memory fits."""

        if not self.wide:
            return 1
        return len(sizes) if self.memory is None else self.memory.pass_width(cache, sizes)

    def pass_room(self, cache: Any, sizes: list[int], extra: int) -> bool:
        """Whether this pass fits with ``extra`` bytes more beside it (no memory accounting here: yes)."""

        return self.memory is None or self.memory.pass_room(cache, sizes, extra)

    def before_chunk(self, cache: Any, tokens: int) -> None:
        self.cancellation.check()
        if self.memory is not None:
            self.memory.before_chunk(cache, tokens)
        self.cancellation.check()

    def after_chunk(self, cache: Any, tokens: int) -> None:
        self.cancellation.check()
        if self.memory is not None:
            self.memory.after_chunk(cache, tokens)
        self.cancellation.check()

    def allow_checkpoint(self, cache: Any) -> bool:
        self.cancellation.check()
        return self.memory is None or self.memory.allow_checkpoint(cache)

    def refuse(self, boundary: int, cache: Any) -> None:
        """Memory refused this prompt's checkpoint copy: log the reason once per fill (#155)."""

        if self.refused or self.memory is None or not hasattr(self.memory, "refusal_reason"):
            return
        reason = self.memory.refusal_reason(cache)
        if reason:
            self.refused = True
            print(f"[tensorfold] kept nothing at {boundary} tokens: {reason}; a turn reusing this prefix "
                  "re-prefills it", flush=True)
