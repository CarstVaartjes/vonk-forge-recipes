"""Qwen kernels."""
