"""GLM kernels."""
