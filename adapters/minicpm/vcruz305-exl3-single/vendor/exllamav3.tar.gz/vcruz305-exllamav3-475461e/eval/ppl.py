import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import argparse
from exllamav3.util.file import disk_lru_cache
from exllamav3.util.progress import ProgressBar
from exllamav3.util.misc import prepend_hf_chat_context
from exllamav3 import model_init, Tokenizer, Config
from datasets import load_dataset
from exllamav3.util.memory import free_mem
from exllamav3.util.measures import compute_target_log_probs
import torch
import math
import json


@disk_lru_cache("get_dataset_text")
def get_dataset_text(spec: dict):
    assert spec["dataset"] == "wiki2", "Only wiki2 implemented atm"
    dataset_text = "\n\n".join(
        load_dataset("Salesforce/wikitext", "wikitext-2-raw-v1", split = "test")
        ["text"]
    )
    return dataset_text


def get_test_tokens(tokenizer, rows, eval_len = 2048, eval_stride = 2048):
    with ProgressBar("Tokenizing", rows) as pb:
        dataset_spec = { "dataset": "wiki2" }
        eval_tokens = tokenizer.encode(get_dataset_text(dataset_spec))
        num_tokens = eval_tokens.shape[-1]
        seqs = []
        for a in range(0, num_tokens - eval_len, eval_stride):
            b = a + eval_len
            seqs.append(eval_tokens[:, a:b])
            pb.update(len(seqs))
            if len(seqs) >= rows:
                break
    return torch.cat(seqs, dim = 0)[:, :]


@disk_lru_cache("_load_wikitext2_raw")
def _load_wikitext2_raw() -> str:
    """
    Get raw wikitext2 test split exactly as used by perplexity.c (datasets version differs slightly on whitespace)
    """

    import tempfile, zipfile, pathlib, urllib.request

    _WIKITEXT2_URL = "https://huggingface.co/datasets/ggml-org/ci/resolve/main/wikitext-2-raw-v1.zip"

    cache_dir = pathlib.Path(tempfile.gettempdir()) / "llama_cpp_ppl_wikitext2"
    cache_dir.mkdir(parents = True, exist_ok = True)

    raw_path = cache_dir / "wikitext-2-raw" / "wiki.test.raw"
    if not raw_path.exists():

        zip_path = cache_dir / "wikitext-2-raw-v1.zip"
        if not zip_path.exists():
            print(f"Downloading WikiText-2 raw to {zip_path} ...")
            urllib.request.urlretrieve(_WIKITEXT2_URL, str(zip_path))

        with zipfile.ZipFile(str(zip_path), "r") as zf:
            zf.extractall(str(cache_dir))

        zip_path.unlink(missing_ok = True)
        if not raw_path.exists():
            raise FileNotFoundError(f"Failed to extract to {raw_path}.")

    with open(raw_path, "r", encoding = "utf-8") as f:
        return f.read()


def get_test_rows_file(path: str, max_rows: int | None):
    """
    Pre-tokenized test rows from a file, as (ids [rows, max_len] right-padded, ranges): per row,
    logits at positions [a, b - 1) are scored against the tokens at [a + 1, b), matching qbench.

    .safetensors: "ids" [rows, len] int64, plus either "prefix_len" (scalar: score positions from
    there on, the qbench tokens_*.safetensors layout) or "ranges" [rows, 2] int64 (per-row [a, b)
    over logits positions; rows may be right-padded beyond b). Neither: whole rows, like -l/-r.

    .json: a qbench_prompts.py trace (variable-length (input_ids, response_ids) pairs), scored on
    the sampled response tokens only, exactly as a qbench project with `test_trace` does.
    """
    if path.endswith(".json"):
        with open(path, "r") as f:
            trace = json.load(f)
        rows = trace["rows"][:max_rows] if max_rows else trace["rows"]
        assert rows, f"{path} contains no rows"
        max_len = max(len(r["input_ids"]) + len(r["response_ids"]) for r in rows)
        ids = torch.zeros((len(rows), max_len), dtype = torch.long)
        ranges = []
        for i, r in enumerate(rows):
            seq = r["input_ids"] + r["response_ids"]
            ids[i, :len(seq)] = torch.tensor(seq, dtype = torch.long)
            ranges.append((len(r["input_ids"]) - 1, len(seq)))
        return ids, ranges
    from safetensors import safe_open
    with safe_open(path, framework = "pt", device = "cpu") as f:
        keys = set(f.keys())
        assert "ids" in keys, f"{path} has no 'ids' tensor"
        ids = f.get_tensor("ids").to(torch.long)
        assert ids.dim() == 2, f"'ids' must be [rows, len], got {tuple(ids.shape)}"
        if max_rows:
            ids = ids[:max_rows]
        if "ranges" in keys:
            rg = f.get_tensor("ranges").to(torch.long)[:ids.shape[0]]
            assert rg.shape == (ids.shape[0], 2), f"'ranges' must be [rows, 2], got {tuple(rg.shape)}"
            ranges = [(int(a), int(b)) for a, b in rg.tolist()]
        else:
            prefix_len = int(f.get_tensor("prefix_len").flatten()[0].item()) if "prefix_len" in keys else 0
            ranges = [(prefix_len, ids.shape[1])] * ids.shape[0]
    for a, b in ranges:
        assert 0 <= a < b - 1 <= ids.shape[1] - 1, f"bad scoring range {(a, b)} for rows of {ids.shape[1]}"
    return ids, ranges


def get_test_tokens_gguf(tokenizer) -> list[int]:
    text = _load_wikitext2_raw()
    token_ids = tokenizer.encode(text, add_bos = False)
    return token_ids[0].tolist()


def eval_gguf(model, config, tokenizer, args, forward_fn):

    # Dataset
    tokens = get_test_tokens_gguf(tokenizer)
    bos_id = tokenizer.bos_token_id
    n_ctx = args.ctx_size

    if len(tokens) < 2 * n_ctx:
        raise ValueError(
            f"Need at least {2 * n_ctx} tokens for n_ctx={n_ctx}, "
            f"but the dataset tokenizes to only {len(tokens)} tokens."
        )

    # Chunking (non-overlapping)
    n_chunks = len(tokens) // n_ctx
    first = n_ctx // 2
    print(f"Perplexity: {len(tokens)} tokens, {n_chunks} chunks, n_ctx={n_ctx}, scoring positions [{first}, {n_ctx - 2}]")

    total_nll = 0.0
    total_nll2 = 0.0
    total_count = 0
    per_chunk_ppl: list[float] = []

    for i in range(n_chunks):
        start = i * n_ctx
        chunk_tokens = tokens[start : start + n_ctx]

        # Optionally overwrite first token in each chunk with BOS
        if bos_id is not None:
            chunk_tokens = [bos_id] + chunk_tokens[1:]

        input_ids = torch.tensor([chunk_tokens], dtype=torch.long)
        logits = forward_fn(model, input_ids)

        score_logits = logits[0, first : n_ctx - 1]  # [n_ctx - 1 - first, vocab]
        score_tokens = tokens[start + first + 1 : start + n_ctx]
        score_tokens = torch.tensor(score_tokens, dtype = torch.long, device = score_logits.device)

        # Matches llama.cpp's log_softmax function: logit[tok] - max - log(sum_exp)
        token_nlls = -compute_target_log_probs(score_logits, score_tokens, tokenizer.actual_vocab_size)

        nll_sum = token_nlls.sum().item()
        nll2_sum = (token_nlls * token_nlls).sum().item()
        n_scored = len(score_tokens)
        total_nll += nll_sum
        total_nll2 += nll2_sum
        total_count += n_scored
        running_ppl = math.exp(total_nll / total_count)
        per_chunk_ppl.append(running_ppl)

        print(f"[{i + 1}]{running_ppl:.4f}", end=",", flush=True)

    print()

    # Aggregate
    mean_nll = total_nll / total_count
    ppl = math.exp(mean_nll)
    mean_nll2 = total_nll2 / total_count
    variance = mean_nll2 - mean_nll * mean_nll
    if variance > 0 and total_count > 1:
        nll_stderr = math.sqrt(variance / (total_count - 1))
    else:
        nll_stderr = 0.0
    ppl_stderr = nll_stderr * ppl

    print(f"Final estimate: PPL = {ppl:.4f} +/- {ppl_stderr:.5f}")


def eval_default(model, config, tokenizer, args, forward_fn):

    # Dataset
    vocab_size = tokenizer.actual_vocab_size
    if args.test_file:
        assert not args.gen_prompt, "-gp does not apply to pre-tokenized rows (-t)"
        eval_ids, ranges = get_test_rows_file(args.test_file, args.rows)
        print(f" -- Test rows from {args.test_file}: {eval_ids.shape[0]} rows, "
              f"{sum(b - a - 1 for a, b in ranges)} scored tokens")
    else:
        eval_ids = get_test_tokens(tokenizer, args.rows, eval_len = args.length)
        if args.gen_prompt:
            eval_ids = prepend_hf_chat_context(tokenizer, eval_ids)
        ranges = [(0, eval_ids.shape[1])] * eval_ids.shape[0]

    # Test
    logprob_sum = 0.0
    logprob_count = 0
    num_rows = eval_ids.shape[0]
    with ProgressBar("Evaluating", num_rows) as pb:
        for row in range(num_rows):
            pb.update(row)
            a, b = ranges[row]
            # Only the row's real length goes through the model (padding beyond b is inert
            # anyway); logits at [a, b - 1) predict the tokens at [a + 1, b)
            input_ids = eval_ids[row:row + 1, :b]
            logits = forward_fn(model, input_ids)
            logits = logits[:, a:b - 1, :]
            target_ids = input_ids[:, a + 1:b].to(logits.device)
            del input_ids
            target_log_probs = compute_target_log_probs(logits, target_ids, vocab_size)
            logprob_sum += target_log_probs.sum().item()
            logprob_count += target_ids.numel()
            del logits
            del target_log_probs
            del target_ids
            torch.cuda.empty_cache()
        pb.update(num_rows)
        mean_log_prob = logprob_sum / logprob_count
        perplexity = math.exp(-mean_log_prob)

    if args.test_file:
        print(f" -- Evaluated: {num_rows} rows, {logprob_count} scored tokens")
    else:
        print(f" -- Evaluated: {num_rows} rows of {eval_ids.shape[1]} tokens")
    print(f" -- Perplexity: {perplexity:.6f}")



@torch.inference_mode()
def main(args):

    if not args.hf:
        model, config, _, tokenizer = model_init.init(
            args,
            override_dynamic_seq_len = 2048,
            max_output_size = 2048,
            max_output_factor = 5,
        )
        def forward_fn_exl3(_model, _input_ids):
            return _model.forward(_input_ids, {"attn_mode": "flash_attn_nc"})
        forward_fn = forward_fn_exl3

        bpw_layer, bpw_head, vram_bits = model.get_storage_info()
        print(f" -- Model: {args.model_dir}")
        print(f" -- Bitrate: {bpw_layer:.2f} bpw / {bpw_head:.2f} bpw (head)")
    else:
        from transformers import AutoModelForCausalLM

        config = Config.from_directory(args.model_dir)
        tokenizer = Tokenizer.from_config(config)

        # MXFP4 checkpoints (gpt-oss): dequantize at load rather than letting Transformers use
        # the fused MXFP4 triton kernels, which crash on unsupported GPU/triton combinations
        hf_kwargs = {}
        qcfg = config.read_cfg(dict, "quantization_config", None)
        if qcfg and qcfg.get("quant_method") == "mxfp4":
            from transformers import Mxfp4Config
            hf_kwargs["quantization_config"] = Mxfp4Config(dequantize = True)
            if not args.hf_tight and not args.hf_fp32:
                hf_kwargs["dtype"] = torch.bfloat16

        # -gs doubles as a per-device GiB budget: an explicit device map from accelerate's planner,
        # since Transformers' own "auto" planner fills every device to the brim (its conversion
        # transients, e.g. fusing 256 experts' gate/up projections, then OOM) or refuses outright
        device_map = "auto" if args.hf_device is None else torch.device(args.hf_device)
        if args.hf_device is None and args.gpu_split:
            from exllamav3.util.hf_util import hf_device_map_from_split
            device_map = hf_device_map_from_split(args.model_dir, args.gpu_split.split(","))
            # The grouped_mm expert path mixes devices when a model is split (native KimiLinear on
            # transformers 5.17); the eager expert loop is the reference path anyway
            hf_kwargs["experts_implementation"] = "eager"
        model = AutoModelForCausalLM.from_pretrained(
            args.model_dir,
            device_map = device_map,
            dtype = torch.half if args.hf_tight else torch.float if args.hf_fp32 else hf_kwargs.pop("dtype", None),
            **hf_kwargs,
        )

        if args.hf_tight:
            free_mem()
            model.half()
            free_mem()
        if args.hf_fp32:
            free_mem()
            model.float()
            free_mem()

        def forward_fn_hf(_model, _input_ids):
            return _model.forward(_input_ids.to(_model.device))["logits"]
        forward_fn = forward_fn_hf


    assert not (args.gguf and args.test_file), "-t does not apply to GGUF-equivalent mode (-g)"
    if not args.gguf:
        eval_default(model, config, tokenizer, args, forward_fn)
    else:
        eval_gguf(model, config, tokenizer, args, forward_fn)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(allow_abbrev = False)
    model_init.add_args(parser, cache = False)
    parser.add_argument("-r", "--rows", type = int, help = "Number of rows", default = 100)
    parser.add_argument("-l", "--length", type = int, help = "Length", default = 2048)
    parser.add_argument("-t", "--test_file", type = str, default = None, help = "Pre-tokenized test rows instead of wiki2: a .safetensors file with 'ids' [rows, len] (+ optional 'prefix_len' or 'ranges' [rows, 2], the qbench tokens file layout) or a qbench_prompts.py .json trace (scored on the sampled response tokens). -r caps the rows, -l is ignored")
    parser.add_argument("-g", "--gguf", action = "store_true", help = "Use GGUF-equivalent eval logic (ignores -r and -l)")
    parser.add_argument("-c", "--ctx-size", type = int, help = "For GGUF-equiv.: size of the prompt context (default: 512)", default = 512)
    parser.add_argument("-hf", "--hf", action = "store_true", help = "Use Transformers as backend (-m must be HF model)")
    parser.add_argument("-hf_d", "--hf_device", type = int, help = "Use specific single device ID for Transformers (default: device_map='auto')", default = None)
    parser.add_argument("-hf_t", "--hf_tight", action = "store_true", help = "For Transformers: Force FP16 dtype to save memory")
    parser.add_argument("-hf_fp32", "--hf_fp32", action = "store_true", help = "For Transformers: Force FP32 dtype")
    parser.add_argument("-gp", "--gen_prompt", action = "store_true", help = "Prepend chat template generation prompt to every row (doesn't apply to GGUF mode)")

    _args = parser.parse_args()
    main(_args)
