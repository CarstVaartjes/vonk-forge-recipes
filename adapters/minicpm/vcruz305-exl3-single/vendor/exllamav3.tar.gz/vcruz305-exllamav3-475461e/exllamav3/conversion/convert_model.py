import argparse
import torch
import time
import sys
from .. import Config, Model, Tokenizer
from ..modules import Linear, Embedding
from ..modules.linear import convert_exl3_group
from ..modules.mlp import merge_out_sensitivity, finalize_out_sensitivity
from ..modules.quant.exl3_lib.quantize import auto_split, get_temp_buffers, quantize_exl3
from ..modules.quant import LinearFP16, LinearEXL3
from ..util.progress import ProgressBar
from ..util.memory import free_mem, malloc_trim
from ..util import Timer, human_time
from ..util.tensor import save_tensor_image
from ..util.measures import cosine_error, sqnr
from .calibration_data import get_default_calibration, get_file_calibration
from .compile import compile_model, dsize
from . import retry_outliers as ro
from .ngram import quantize_embedding
from .allocation import create_q_strategy, create_q_strategy_from_recipe, print_strategy, HALF_RATES
from ..loader.safetensors_alt import save_file, safe_open
import os, shutil
import json
import threading
from pathlib import Path
from collections import deque
import re

col_default = "\u001b[0m"
col_red = "\u001b[31;1m"

torch.set_printoptions(precision = 5, sci_mode = False, linewidth = 200)


def monkeypatch_triton_autotuner_thread_safety():
    """
    Triton's Autotuner.run() stores the call's arguments as `self.nargs` on the shared
    kernel object and nulls the attribute on exit.

    capture_module_parallel / advance_state_parallel run one worker thread per device
    through the same JIT kernels, so a thread finishing run() while another is still inside
    the seconds-long benchmark loop poisons {**self.nargs, ...}

    Every use of nargs is confined to the calling thread's run() frame, so rebinding the
    attribute to thread-local storage removes the race with no behavioral change
    single-threaded. A data descriptor on the class also overrides pre-existing instance
    attributes, so the patch is safe to apply at any point.
    """
    try:
        from triton.runtime.autotuner import Autotuner
    except ImportError:
        return
    if getattr(Autotuner, "_exl3_tls_nargs", False):
        return

    def _get_nargs(self):
        tls = self.__dict__.get("_exl3_nargs_tls")
        return getattr(tls, "value", None) if tls is not None else None

    def _set_nargs(self, value):
        tls = self.__dict__.get("_exl3_nargs_tls")
        if tls is None:
            tls = self.__dict__.setdefault("_exl3_nargs_tls", threading.local())
        tls.value = value

    Autotuner.nargs = property(_get_nargs, _set_nargs)
    Autotuner._exl3_tls_nargs = True

monkeypatch_triton_autotuner_thread_safety()


parser = argparse.ArgumentParser(allow_abbrev = False)
parser.add_argument("-i", "--in_dir", type = str, default = None, help = "Input (model) directory")
parser.add_argument("-w", "--work_dir", type = str, default = None, help = "Working directory")
parser.add_argument("-o", "--out_dir", type = str, default = None, help = "Output directory")
parser.add_argument("-ss", "--shard_size", type = int, help = "Max shard size in MB, default: 8192")
parser.add_argument("-b", "--bits", type = float, help = "Bits per weight")
parser.add_argument("-rcp", "--recipe", type = str, default = None, help = "Per-tensor bitrate recipe (YAML from sc_optimize.py), used in place of the budgeted allocation from --bits / --head_bits.")
parser.add_argument("-hb", "--head_bits", type = float, default = None, help = "Bits per weight, output (head) layer: 1-8, 1.5/2.5/3.5 (mul1 codebook), or 16 to store unquantized, default: 6")
parser.add_argument("-mb", "--mtp_bits", type = float, default = None, help = "Bits per weight, MTP layers: 1-8, 1.5/2.5/3.5 (mul1 codebook), or 16 to store unquantized, default: 4")
parser.add_argument("-vb", "--vision_bits", type = int, default = None, help = "Bits per weight, vision model layers, 1-8, or 16 to store unquantized, default: architecture's default (6 for validated towers, else 16)")
parser.add_argument("-hq", "--hq", action = "store_true", help = "Increase bitrate of select layers for supported models (MoE mostly)")
parser.add_argument("-ngb", "--ngram_bits", type = int, default = None, help = "Bits per weight for hashed n-gram embedding tables, 1-8, default: --bits rounded")
parser.add_argument("-eb", "--embed_bits", type = int, default = None, help = "Bits per weight, token embedding table: 1-8, or 16 to store unquantized, default: 16")
parser.add_argument("-ngf", "--ngram_file", type = str, default = None, help = "Pre-quantized n-gram table file (from util/convert_ngram.py) to use instead of quantizing the table")
parser.add_argument("-r", "--resume", action = "store_true", help = "Resume interrupted job from working directory")
parser.add_argument("-cd", "--cal_data", type = str, default = None, help = "Calibration data file (safetensors with packed token rows, e.g. from sc_trace.py) used instead of the bundled corpus mix")
parser.add_argument("-cr", "--cal_rows", type = int, help = "Calibration data size, rows, default: 250")
parser.add_argument("-cc", "--cal_cols", type = int, help = "Calibration data size, columns, default: 2048")
parser.add_argument("-cpi", "--checkpoint_interval", type = int, default = 120, help = "Minimum checkpoint interval, in seconds")
parser.add_argument("-lcpi", "--last_checkpoint_index", type = int, default = None, help = "Last module index to checkpoint (for debug purposes)")
parser.add_argument("-v", "--verbose", action = "store_true", help = "Verbose mode")
parser.add_argument("-d", "--devices", type = str, default = "0", help = "List of devices to use for quantization, e.g. --devices 0,1,2")
parser.add_argument("-dr", "--device_ratios", type = str, default = "", help = "Split ratio for devices, e.g. --device_ratio 2,2,4")
parser.add_argument("-img", "--image_dump", action = "store_true", help = "Save model tensors as images (saved to working directory)")
parser.add_argument("-cdn", "--calib_devices", type = str, default = "auto", help = "Calibration forward devices: auto (one when batching, otherwise all), or first N --devices; quantization still uses all. Momentary, resume-safe")
parser.add_argument("-cbs", "--calib_batch_rows", type = str, default = "auto", help = "Calibration rows per forward: auto (32, capped at calibration rows), or a positive integer. Momentary, resume-safe")
parser.add_argument("-cb", "--codebook", type = str, default = "mul1", help = "Codebook: mul1 (default), mcg or 3inst")
parser.add_argument("-hess", "--hessians", type = str, default = None, help = "Directory of precomputed per-tensor Hessians (<key>.safetensors with hin (in, in) and/or hout (out, out), square or packed upper triangle, and/or hout_diag, e.g. YAQA-style Kronecker factors from a separate gradient pass, see util/yaqa_hessians.py). Tensors with hin skip the calibration forward passes; tensors with hout use two-sided LDLQ")
parser.add_argument("-h1", "--hessians_one_sided", action = "store_true", help = "With --hessians: keep the regular one-sided LDLQ for tensors that have hout, leaving the output side to --out_scales yaqa")
parser.add_argument("-sh", "--scaled_hessian", action = "store_true", help = "Factor the calibration Hessian per tensor with the tensor's input channel scales folded in, so LDLQ's error feedback weights each row by what its error costs at the output (one more Cholesky per tensor; experimental)")
parser.add_argument("-hreg", "--hessians_reg", type = float, default = None, help = "Diagonal regularization of the output-side Hessian, relative to its mean diagonal (default: same as input side, 0.025). Larger values blend toward plain one-sided LDLQ")
parser.add_argument("-pm", "--parallel_mode", action = "store_true", help = "Deprecated (no-op): parallel mode is now the default; layers with fewer tensors than devices fall back to tile splitting")
parser.add_argument("--max_module", type = int, help = "End quantization after this many modules, includes embedding and norm layers (for debug purposes)", default = None)
parser.add_argument("--dump_hessians", type = str, default = None, help = "Write each module's raw captured Hessians (fp32 sum of x^T x before finalization, one file per module) to this directory, so a later repair can re-encode with the exact Hessians. Off by default; output unchanged")
parser.add_argument("--retry_outliers", action = "store_true", help = "Re-encode a matrix with other seeds (idx + 1000 k, k <= --retry_max_seeds) when its proxy error is > --retry_ratio x its peer group's median or its global scale < --retry_min_gscale (encoder scale-search collapse). Retried matrices and winning seeds go to <work_dir>/retry_outliers.jsonl and <out_dir>/exl3_retry_log.json. Off by default; output unchanged")
parser.add_argument("--retry_ratio", type = float, default = None, help = "--retry_outliers: proxy error ratio over the group median, default: 5")
parser.add_argument("--retry_min_gscale", type = float, default = None, help = "--retry_outliers: global scale below which a matrix is re-encoded, default: 0.2")
parser.add_argument("--retry_max_seeds", type = int, default = None, help = "--retry_outliers: seeds tried per matrix, default: 32")
parser.add_argument("--retry_budget", type = int, default = None, help = "--retry_outliers: re-encode budget per module in units of 4M weights, default: 1024")

group = parser.add_mutually_exclusive_group()
group.add_argument("--out_scales", type = str, default = "auto", choices = ["auto", "always", "never", "yaqa"], help = "Output channel scales: always, never, auto (default): always, except for gate and up projections of gated MLPs whose calibration statistics predict a lower error without, or yaqa: per-channel scales that account for how much each output channel matters, from the diagonal of the output-side Hessians in --hessians (tensors without one are treated as in auto)")

parser.add_argument("--override_anyway", action = "store_true", help = "Allow resuming even when overriding settings that will break the existing job.")

num_ref_states = 5

progress_lock = threading.Lock()
curr_progress = 0
max_progress = 0

def check_system():
    if os.environ.get("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE") is not None:
        print(
            "\n"
            f" !! {col_red}IMPORTANT: The environment variable TORCH_ALLOW_TF32_CUBLAS_OVERRIDE is set!{col_default}\n"
            f" !! {col_red}This causes Torch to run in reduced precision mode, which is likely to cause this "
            f"script to fail or result in broken models.{col_default}\n"
            "\n"
        )


def save_dict(filename, dict_, args):
    path = os.path.join(args["work_dir"], filename)
    with open(path, "w", encoding = "utf8") as f:
        f.write(json.dumps(dict_, indent = 4))


def load_dict(filename, args):
    path = os.path.join(args["work_dir"], filename)
    with open(path, "r", encoding = "utf8") as f:
        return json.load(f)


def load_tensor(filename, args):
    path = os.path.join(args["work_dir"], filename)
    with safe_open(path, framework = "pt", device = "cpu") as f:
        if "tensor" in f.keys():
            return f.get_tensor("tensor")
        else:
            tensors = []
            i = 0
            while f"tensor.{i}" in f.keys():
                tensors.append(f.get_tensor(f"tensor.{i}"))
                i += 1
            return tensors


def save_tensor(tensor, filename: str, args):
    path = os.path.join(args["work_dir"], filename)
    if isinstance(tensor, dict):
        save_file({
            k: v for k, v in tensor.items()
        }, path)
    elif isinstance(tensor, list):
        save_file({
            f"tensor.{i}": t for i, t in enumerate(tensor)
        }, path)
    else:
        save_file({
            f"tensor": tensor
        }, path)


def prepare_env(args):
    qtensors_dir = os.path.join(args["work_dir"], "qtensors")
    ckpt_dir = os.path.join(args["work_dir"], "ckpt")
    images_dir = os.path.join(args["work_dir"], "images")
    os.makedirs(args["work_dir"], exist_ok = True)
    os.makedirs(qtensors_dir, exist_ok = True)
    os.makedirs(ckpt_dir, exist_ok = True)
    os.makedirs(images_dir, exist_ok = True)


def prepare(args) -> (dict, dict, bool, str):
    check_system()

    if not args.work_dir:
        return None, None, False, "Must specify --work_dir"
    if not args.in_dir and not args.resume:
        return None, None, False, "Specify either --in_dir to start a new job or --resume to resume an interrupted job"
    if not args.out_dir and not args.resume:
        return None, None, False, "Must specify --out_dir or --resume"
    if args.codebook not in ["mcg", "mul1", "3inst"]:
        return None, None, False, "Codebook must be 'mcg', 'mul1' or '3inst'"
    if args.bits is not None and (args.bits > 8 or args.bits < 1):
        return None, None, False, "--bits must be between 1 and 8"
    if args.head_bits is not None and (args.head_bits > 8 or args.head_bits < 1) and args.head_bits != 16:
        return None, None, False, "--head_bits must be between 1 and 8, or 16"
    if args.mtp_bits is not None and (args.mtp_bits > 8 or args.mtp_bits < 1) and args.mtp_bits != 16:
        return None, None, False, "--mtp_bits must be between 1 and 8, or 16"
    if not args.resume and args.bits is None and not args.recipe:
        return None, None, False, "Specify either --bits or --recipe"

    # Per-tensor recipe: parsed up front so its bitrates can stand in for --bits/--head_bits.
    # The tensor map is stored in the job args below, so a resumed job keeps quantizing to the
    # strategy it started with even if the recipe file changes on disk
    recipe_tensors = None
    recipe_bits = None
    recipe_head_bits = None
    if args.recipe:
        if not os.path.isfile(args.recipe):
            return None, None, False, f"Recipe file not found: {args.recipe}"
        import yaml
        with open(args.recipe, "r", encoding = "utf8") as f:
            recipe = yaml.safe_load(f)
        recipe_tensors = recipe.get("tensors") if isinstance(recipe, dict) else None
        if not isinstance(recipe_tensors, dict) or not recipe_tensors:
            return None, None, False, "Recipe must contain a non-empty 'tensors' mapping"
        # Integer bitrates 1-8 (or 16 = unquantized), plus the half-integer trellis rates (mul1 codebook)
        def ok(v):
            if isinstance(v, bool) or not isinstance(v, (int, float)): return False
            return (float(v).is_integer() and (1 <= v <= 8 or v == 16)) or float(v) in HALF_RATES
        bad = [k for k, v in recipe_tensors.items() if not ok(v)]
        if bad:
            return None, None, False, f"Recipe bitrates must be integers 1-8, 16, or one of {HALF_RATES}; bad keys e.g.: {bad[:5]}"
        recipe_bits = recipe.get("achieved_bpw") or recipe.get("target_bpw")
        if args.bits is None and recipe_bits is None:
            return None, None, False, "Recipe has no target_bpw/achieved_bpw; pass --bits for reporting"
        recipe_head_bits = recipe.get("head_bits")
        if args.bits is not None:
            print(" !! Warning: --recipe given, --bits is used for reporting only")
        if args.hq:
            print(" !! Warning: --hq has no effect with --recipe")

    in_args = { "work_dir": args.work_dir }
    if args.resume:
        in_args = load_dict("args.json", in_args)
        in_args.pop("calib_batch_rows", None)
        in_args.pop("calib_devices", None)
        in_args["work_dir"] = args.work_dir

    prepare_env(in_args)

    def override(arg, can_override, default):
        if (arg not in args or vars(args)[arg] is None) and arg not in in_args:
            if default is not None:
                in_args[arg] = default
            else:
                raise ValueError(f" ## Missing required argument: {arg}")
        if arg in args and vars(args)[arg] is not None:
            new = vars(args)[arg]
            if arg in in_args and in_args[arg] != new:
                if not new:
                    # An unset store_true flag (or a zero default) can't be told from "unspecified":
                    # the resumed job's saved value stands (e.g. --hq stays on when resuming without it)
                    return
                if can_override:
                    print(
                        f" !! Warning: Overriding {arg} from existing job, was: {in_args[arg]}, "
                        f"new value: {new}"
                    )
                else:
                    raise ValueError(
                        f" ## Error: Resuming job with {arg} = {in_args[arg]}, "
                        f"cannot override with new value of {new}. "
                        f"Please start a new job to change this value."
                    )
            in_args[arg] = new

    for arg_, can_override, default in [
        ("in_dir", True, None),
        ("out_dir", True, None),
        ("shard_size", True, 8192),
        ("bits", False, recipe_bits),
        ("recipe", False, ""),
        ("head_bits", False, recipe_head_bits or 6),
        ("mtp_bits", True, 4),
        ("vision_bits", True, 0),  # 0 = auto: architecture's default_vision_bits cap, or 16
        ("hq", False, False),
        ("ngram_bits", False, 0),  # 0 = auto: --bits rounded
        ("ngram_file", False, ""),
        ("embed_bits", False, 16),
        ("cal_data", False, ""),
        ("cal_rows", False, 250),
        ("cal_cols", False, 2048),
        ("checkpoint_interval", True, None),
        ("last_checkpoint_index", True, -1),
        ("devices", True, None),
        ("device_ratios", True, None),
        ("codebook", True, "mul1"),
        ("hessians", False, ""),
        ("hessians_reg", False, 0.025),
        ("hessians_one_sided", False, False),
        ("scaled_hessian", False, False),
        ("dump_hessians", True, ""),
        ("retry_outliers", True, False),
        ("retry_ratio", True, ro.DEFAULT_RATIO),
        ("retry_min_gscale", True, ro.DEFAULT_MIN_GSCALE),
        ("retry_max_seeds", True, ro.RETRY_MAX_SEEDS),
        ("retry_budget", True, 1024),
    ]:
        override(arg_, can_override if not args.override_anyway else True, default)

    # Bitrates outside the main budget must be supported rates; the half-integer ones need the mul1 codebook
    half_ok = in_args["codebook"] == "mul1"
    for arg_ in ("head_bits", "mtp_bits"):
        v = in_args[arg_]
        if v == 16 or (float(v).is_integer() and 1 <= v <= 8):
            in_args[arg_] = int(v)
        elif not (half_ok and v in HALF_RATES):
            return None, None, False, f"--{arg_} must be an integer 1-8, 16, or one of {HALF_RATES} with the mul1 codebook, got {v}"
    if in_args["embed_bits"] != 16 and not 1 <= in_args["embed_bits"] <= 8:
        return None, None, False, f"--embed_bits must be an integer 1-8, or 16, got {in_args['embed_bits']}"
    if recipe_tensors is not None and not half_ok and any(v in HALF_RATES for v in recipe_tensors.values()):
        return None, None, False, f"Recipe uses half-integer bitrates, which need the mul1 codebook"

    # Recipe strategy travels with the job; a stored map from a resumed job wins over the file
    if recipe_tensors is not None and "recipe_strategy" not in in_args:
        in_args["recipe_strategy"] = recipe_tensors

    # Momentary args
    in_args["image_dump"] = args.image_dump
    in_args["verbose"] = args.verbose
    in_args["apply_out_scales"] = {"always": True, "never": False, "auto": None, "yaqa": None}[args.out_scales]
    in_args["out_scales_hessian"] = args.out_scales == "yaqa"
    if in_args["out_scales_hessian"] and not in_args["hessians"]:
        return None, None, False, "--out_scales yaqa takes its output-side Hessians from --hessians"
    if in_args["hessians_one_sided"] and not in_args["hessians"]:
        return None, None, False, "--hessians_one_sided needs --hessians"
    in_args["max_module"] = args.max_module
    try:
        in_args["calib_batch_rows"] = min(32, max(1, int(args.cal_rows or 250))) if args.calib_batch_rows == "auto" else int(args.calib_batch_rows)
        if in_args["calib_batch_rows"] < 1:
            raise ValueError
    except (TypeError, ValueError):
        return None, None, False, "--calib_batch_rows must be 'auto' or a positive integer"
    try:
        in_args["calib_devices"] = (1 if in_args["calib_batch_rows"] > 1 else 0) if args.calib_devices == "auto" else int(args.calib_devices)
        if in_args["calib_devices"] < 0:
            raise ValueError
    except (TypeError, ValueError):
        return None, None, False, "--calib_devices must be 'auto' or a non-negative integer"

    if args.resume:
        job_state = load_dict("ckpt/job.json", in_args)
        print(f" -- Resuming existing job")
    else:
        print(f" -- Creating new job")
        job_state = {
            "next_module_idx": 0,
            "q_strategy": None,
        }
        save_dict("args.json", {k: v for k, v in in_args.items() if k not in {"calib_batch_rows", "calib_devices"}}, in_args)
        save_dict("ckpt/job.json", job_state, in_args)

    warn_experimental = False
    print(f"    Input directory: {in_args['in_dir']}")
    print(f"    Output directory: {in_args['out_dir']}")
    print(f"    Working directory: {in_args['work_dir']}")
    print(f"    Calibration size: {in_args['cal_rows']} rows, {in_args['cal_cols']} columns")
    if in_args.get("cal_data"):
        print(f"    Calibration data: {in_args['cal_data']}")
    print(f"    Target bitrate: {in_args['bits']} (decoder), {in_args['head_bits']} (head)")
    if in_args.get("recipe_strategy"):
        print(f"    Recipe: {in_args.get('recipe')} ({len(in_args['recipe_strategy'])} tensors)")
    print(f"    Output scales: " + (
        "yaqa" if in_args["out_scales_hessian"] else
        {True: "always", False: "never", None: "auto"}[in_args["apply_out_scales"]]
    ))
    print(f"    Codebook: {in_args['codebook']}")

    if warn_experimental:
        print(
            f" !! {col_red}WARNING, experimental options are selected. The quantized model may not work in future "
            f"versions of ExLlamaV3 {col_default}"
        )

    if not args.resume:
        qt_dir = os.path.join(in_args["work_dir"], "qtensors")
        clear = [p for p in Path(qt_dir).glob("*.safetensors") if p.is_file()]
        if len(clear):
            print(f" !! Deleting {len(clear)} safetensors file(s) from {qt_dir}")
        in_args["clear_files"] = clear

    return in_args, job_state, True, None


def get_base_model(args):
    config = Config.from_directory(args["in_dir"])
    print(f" -- Loaded model config")
    print(f"    Architecture: {config.architecture}")
    model = Model.from_config(config)
    use_reference_state = not model.caps.get("uncalibrated_quantize", False)
    assert model.caps.get("can_quantize", True), "Cannot quantize this model type."
    print(f" -- Created model instance:")
    print(model.get_layout_tree(4))
    mtp_model = model.from_config(config, component = "mtp") if "mtp" in config.model_classes else None
    if mtp_model:
        print(f" -- Created MTP model instance:")
        print(mtp_model.get_layout_tree(4))
    vision_bits = args.get("vision_bits", 0)
    assert vision_bits in (0, 16) or 1 <= vision_bits <= 8, \
        f" ## --vision_bits must be 1-8, or 16 to store the vision model unquantized"
    if vision_bits not in (0, 16) and "vision" not in config.model_classes:
        print(f" !! Warning, --vision_bits given but model has no vision component, ignoring")
        vision_bits = 16
    vision_model = model.from_config(config, component = "vision") \
        if vision_bits != 16 and "vision" in config.model_classes else None
    if vision_bits == 0:
        # Auto: architectures whose towers are validated for (effectively lossless) low-bpw
        # quantization declare a default in the vision model's caps; anything else stays fp16.
        # --vision_bits 16 remains the explicit override to copy the tower unquantized
        vision_bits = vision_model.caps.get("default_vision_bits", 16) if vision_model else 16
        if vision_bits == 16:
            vision_model = None
    args["vision_bits"] = vision_bits
    if vision_model:
        print(f" -- Created vision model instance (quantizing to {vision_bits} bpw):")
        print(vision_model.get_layout_tree(4))
    if use_reference_state:
        tokenizer = Tokenizer.from_config(config)
        print(f" -- Loaded tokenizer")
        print(f"    Vocab size: {tokenizer.actual_vocab_size}")
    else:
        tokenizer = None
    if hasattr(config, "rope_settings"):
        if config.rope_settings:
            config.rope_settings.print()
        else:
            print(f" -- No RoPE settings")
    return config, model, mtp_model, vision_model, tokenizer, use_reference_state


def prepare_state(args, job_state, config, model, tokenizer):
    idx = job_state["next_module_idx"]
    if idx == 0:
        print(f" -- Preparing input state")
        if args.get("cal_data"):
            print(f"    Calibration data: {args['cal_data']}")
            state = get_file_calibration(args, tokenizer)
        else:
            state = get_default_calibration(args, tokenizer)
        original_input_ids = None
    else:
        if idx < len(model.modules):
            print(f" -- Resuming at: {model.modules[idx].key}")
        else:
            print(f" -- Resuming after: {model.modules[idx - 1].key}")
        state = load_tensor("ckpt/state.safetensors", args)
        original_input_ids = load_tensor("ckpt/original_input_ids.safetensors", args)
    return state, original_input_ids


def get_state_error(x, ref):
     x = x.view(-1, x.shape[-1]).float()
     ref = ref.view(-1, ref.shape[-1]).float()
     err = torch.linalg.norm(x - ref, 'fro') / torch.linalg.norm(ref, 'fro')
     sq = sqnr(x, ref)
     cos = cosine_error(x, ref)
     return err.item(), cos, sq


def unpack_sym(t, n):
    """
    Symmetric (n, n) matrix from its packed upper triangle (row-major, as written by util/yaqa_hessians.py). Full
    matrices pass through
    """
    if t.dim() == 2:
        return t.float()
    assert t.dim() == 1 and t.numel() == n * (n + 1) // 2, "packed Hessian size"
    out = torch.zeros((n, n), dtype = torch.float)
    out[torch.ones((n, n), dtype = torch.bool).triu_()] = t.float()
    out += out.triu(1).T
    return out


def get_H_data(args, linear, capture_H, state):
    """
    Hessians for one Linear, as (H_data, H_out). H_data: captured online (calibrated conversion), or built from the
    hin (in, in) of the tensor's --hessians file, or the uncalibrated placeholder. H_out: the file's hout (out, out)
    if present, enabling two-sided LDLQ; a --hessians export with hout only keeps the online input-side capture
    """
    hin = hout = None
    path = os.path.join(args["hessians"], linear.key + ".safetensors") if args.get("hessians") else None
    if path and os.path.exists(path):
        two_sided = not args.get("hessians_one_sided")
        with safe_open(path, framework = "pt", device = "cpu") as f:
            hin = unpack_sym(f.get_tensor("hin"), linear.in_features) if "hin" in f.keys() and not state else None
            hout = unpack_sym(f.get_tensor("hout"), linear.out_features) if "hout" in f.keys() and two_sided else None
        assert hin is None or hin.shape == (linear.in_features, linear.in_features), f"{linear.key}: hin shape"
        assert hout is None or hout.shape == (linear.out_features, linear.out_features), f"{linear.key}: hout shape"
    if state:
        return capture_H[linear.qmap], hout
    hd = linear.init_H_data(False)
    if hin is not None:
        hd.update({"H": hin, "H_swap_device": linear.device, "count": 1})
    elif path:
        print(f" !! No precomputed Hessian for {linear.key}, quantizing uncalibrated")
    return hd, hout


def get_out_hessian_diags(args, linears):
    """
    Diagonals of the output-side Hessians of the given Linears for --out_scales yaqa, by key: the hout_diag of each
    tensor's --hessians file, or the diagonal of its hout. Tensors without a file are left out
    """
    diags = {}
    if not args.get("out_scales_hessian"):
        return diags
    for linear in linears:
        path = os.path.join(args["hessians"], linear.key + ".safetensors")
        if not os.path.exists(path):
            continue
        n = linear.out_features
        with safe_open(path, framework = "pt", device = "cpu") as f:
            if "hout_diag" in f.keys():
                diag = f.get_tensor("hout_diag").float()
            elif "hout" in f.keys():
                h = f.get_tensor("hout")
                # Row i of a packed upper triangle starts with its diagonal element
                i = torch.arange(n, dtype = torch.long)
                diag = (h.diagonal() if h.dim() == 2 else h[i * n - i * (i - 1) // 2]).float()
            else:
                continue
        assert diag.shape == (n,), f"{linear.key}: hout diagonal shape"
        diags[linear.key] = diag
    return diags


def make_quant_args(args, idx, K, devices, device_ratios = None, out_sensitivity = None, out_hessian_diag = None):
    quant_args = {
        "seed": idx,
        "K": K,
        "devices": devices,
        "device_ratios": device_ratios,
        "apply_out_scales": args["apply_out_scales"],
        "debug_dir": os.path.join(args["work_dir"], "debug"),
    }
    if out_sensitivity is not None:
        quant_args["out_sensitivity"] = out_sensitivity
    if out_hessian_diag is not None:
        quant_args["out_hessian_diag"] = out_hessian_diag
    if args.get("hessians_reg") is not None:
        quant_args["sigma_reg_out"] = args["hessians_reg"]
    if args.get("scaled_hessian"):
        quant_args["scaled_hessian"] = True
    if args["codebook"] == "mcg":
        quant_args.update({"mcg": True})
    elif args["codebook"] == "mul1":
        quant_args.update({"mul1": True})
    return quant_args


# --retry_outliers bookkeeping: while a module is being quantized, every finished linear reports its result here
# (all four dispatch paths end in print_quantized_linear). None whenever the option is off.
_retry_results = None
_retry_results_lock = threading.Lock()


def retry_capture_begin():
    global _retry_results
    _retry_results = {}


def retry_capture_end():
    global _retry_results
    results, _retry_results = _retry_results, None
    return results


def print_quantized_linear(config, linear, quant_args, proxy_err, time_str = ""):
    if _retry_results is not None:
        with _retry_results_lock:
            _retry_results[linear.key] = {
                "proxy_err": float(proxy_err),
                "g_scale": float(quant_args["g_scale"]),
                "K": quant_args["K"],
                "q_fallback": bool(quant_args["q_fallback"]),
                "zeros": bool(quant_args.get("zeros")),
                "seed": quant_args.get("seed"),
            }
    flags = "y" if quant_args.get("out_scales_hessian") else "o" if quant_args["apply_out_scales"] else "."
    flags += "f" if quant_args["q_fallback"] else "."
    proxy_err_str = (
        "(zero)  " if quant_args["zeros"] else
        "(big)   " if proxy_err >= 9.9 else
        f"{proxy_err:8.6f}" if proxy_err >= 0.0 else
        "(OoM)   "
    )
    proxy_err_label = "proxy_err" if not quant_args["q_fallback"] else "rmse     "
    print(
        f" -- Quantized: {linear.key:{config.stc.max_key_len() + 8}}"
        f"  bpw: {quant_args['K']:5.2f}"
        f"  {proxy_err_label}: {proxy_err_str}"
        f"  {flags}"
        f"  g_sc: {quant_args['g_scale']:.6f}"
        f"{time_str}",
        flush = True
    )


def dump_raw_hessians(dump_dir, module, slice_idx, capture_H, linears):
    """
    --dump_hessians: write the module's captured Hessians exactly as the pipeline holds them before
    finalize_capture_H touches them: fp32, the plain SUM of x^T x over `count` rows (not divided by count, no
    diagonal damping, no sign flips, no Hadamard, no LDL). With these a repair re-runs finalize_capture_H +
    quantize_exl3 on one matrix with another seed and gets the encode the pipeline would have produced.
    One file per module (per slice for sliced modules), tensors named by qmap, the mapping linear key -> qmap and
    each qmap's count / num_total / first_key / inf_nan in the safetensors metadata. Returns the file size.
    """
    os.makedirs(dump_dir, exist_ok = True)
    fname = module.key + (f".s{slice_idx}" if slice_idx is not None else "") + ".hessian.safetensors"
    path = os.path.join(dump_dir, fname)
    tensors, info = {}, {}
    for qmap, hd in capture_H.items():
        H = hd["H"]
        if H.is_meta:
            continue
        tensors[qmap] = H.detach().cpu().contiguous()
        info[qmap] = {
            "k": H.shape[0],
            "count": int(hd["count"]),
            "num_total": int(hd["num_total"]),
            "first_key": hd.get("first_key"),
            "inf_nan": [int(v) for v in hd["inf_nan"].tolist()],
        }
    metadata = {
        "format": "exl3-raw-hessian-v1",
        "module": module.key,
        "slice": "" if slice_idx is None else str(slice_idx),
        "qmaps": json.dumps(info),
        "linear_qmap": json.dumps({l.key: l.qmap for l in linears if l.qmap in tensors}),
        "sigma_reg_default": "0.025",
    }
    tmp = path + ".tmp"
    save_file(tensors, tmp, metadata)
    os.replace(tmp, path)
    return os.path.getsize(path)


def snapshot_raw_H(capture_H, linears):
    """--retry_outliers: private copy of the captured Hessians the module's linears use (finalize_capture_H divides,
    damps and transforms H in place, and for CPU-resident modules that is the captured tensor itself)."""
    snap = {}
    for linear in linears:
        qmap = linear.qmap
        if qmap in capture_H and qmap not in snap:
            hd = capture_H[qmap]
            snap[qmap] = {
                "H": hd["H"].clone(),
                "H_swap_device": hd.get("H_swap_device", hd["H"].device),
                "first_key": hd.get("first_key"),
                "count": hd["count"],
                "num_total": hd["num_total"],
                "inf_nan": hd["inf_nan"].clone(),
                "device": hd.get("device"),
            }
    return snap


def retry_module_outliers(args, module_key, linears, strategy, idx, device, orig_weights, orig_biases, raw_H, results):
    """
    --retry_outliers: after a module has been quantized, re-encode the matrices whose result looks like a scale
    search collapse (ro.find_outliers) with seeds idx + 1000 k, k = 1 .. --retry_max_seeds, from the original weight
    and the raw Hessian snapshot (so a retry is the encode the pipeline would have made with that seed). The first
    acceptable candidate is installed; if none is, the best of all candidates (the original included) is kept and
    the matrix is logged as unresolved. Every retried matrix is appended to <work_dir>/retry_outliers.jsonl.
    """
    ratio, min_gs = args["retry_ratio"], args["retry_min_gscale"]
    outliers, medians = ro.find_outliers(results, ratio, min_gs)
    if not outliers:
        return 0
    by_key = {l.key: l for l in linears}
    log_path = os.path.join(args["work_dir"], "retry_outliers.jsonl")
    budget = args["retry_budget"]
    print(f" -- Retry: {len(outliers)} outlier matrices in {module_key} "
          f"(proxy_err > {ratio:g} x group median or g_sc < {min_gs:g})", flush = True)
    n_replaced = 0
    for key, reason in outliers.items():
        linear = by_key[key]
        K = strategy[key]
        orig = results[key]
        med = medians.get(ro.group_key(key, K))
        cost = max(1, linear.weights_numel() // (4 << 20))
        cands = [{"seed": orig["seed"], "k": 0, "proxy_err": orig["proxy_err"], "g_scale": orig["g_scale"]}]
        outs = [None]
        for k in range(1, args["retry_max_seeds"] + 1):
            if budget < cost:
                print(f" !! Retry budget of {module_key} exhausted, {key} keeps the best encode so far", flush = True)
                break
            budget -= cost
            seed = ro.retry_seed(idx, k)
            qa = make_quant_args(args, seed, K, [device.index])
            h = raw_H[linear.qmap]
            h_data = {
                "H": h["H"].clone(), "H_swap_device": h["H_swap_device"], "first_key": h["first_key"],
                "count": h["count"], "finalized": False, "num_total": h["num_total"],
                "inf_nan": h["inf_nan"].clone(), "device": h["device"],
            }
            try:
                _, pe, out_t = quantize_exl3(orig_weights[key].float(), h_data, qa, False, None, False)
                c = {"seed": seed, "k": k, "proxy_err": float(pe), "g_scale": float(qa["g_scale"])}
            except Exception as e:
                # The guard must never take the conversion down: a failed retry is just a candidate that lost
                print(f" !! Retry encode failed for {key} (seed {seed}): {type(e).__name__}: {e}", flush = True)
                c = {"seed": seed, "k": k, "proxy_err": None, "g_scale": None, "error": f"{type(e).__name__}: {e}"}
                out_t = None
            cands.append(c)
            outs.append(out_t)
            if ro.acceptable(c["proxy_err"], c["g_scale"], med, ratio, min_gs):
                break
        resolved = len(cands) > 1 and ro.acceptable(cands[-1]["proxy_err"], cands[-1]["g_scale"], med, ratio, min_gs)
        win = len(cands) - 1 if resolved else ro.pick_best(cands)
        if win > 0:
            install_exl3_from_tensors(linear, outs[win], orig_biases[key])
            linear.inner.swap_cpu()
            n_replaced += 1
        w = cands[win]
        print(
            f" -- Retried: {key:{len(key) + 2}}  proxy_err: {orig['proxy_err']:.6f} -> {w['proxy_err']:.6f}"
            f"  g_sc: {orig['g_scale']:.6f} -> {w['g_scale']:.6f}"
            f"  seed: {cands[0]['seed']} -> {w['seed']}  tries: {len(cands) - 1}"
            + ("" if resolved else "  !! UNRESOLVED"),
            flush = True
        )
        rec = {
            "key": key, "module": module_key, "idx": idx, "K": K, "trigger": reason, "group_median": med,
            "original": cands[0], "tries": cands[1:], "winner": w, "resolved": resolved,
        }
        with open(log_path, "a", encoding = "utf8") as f:
            f.write(json.dumps(rec) + "\n")
        outs[win] = None
    return n_replaced


def group_quant_linears(linears, strategy, capture_H, max_cat_cols = 500000, max_stack = 2048):
    """
    Partition linears into groups for batched quantization. Tensors sharing a Hessian (same qmap) at the same
    bitrate concatenate along out_features; leftover same-shape, same-bitrate tensors with individual Hessians
    (block-sparse down projections) stack with per-tensor L. Group sizes are capped so the LDLQ work buffers
    stay modest. Returns a list of groups; singleton groups take the plain per-tensor path.
    """
    if capture_H is None:
        return [[linear] for linear in linears]

    groups = []
    shared = {}
    for linear in linears:
        K = strategy[linear.key]
        if K == 16 or linear.qmap not in capture_H:
            groups.append([linear])
        else:
            shared.setdefault((linear.qmap, K, linear.in_features), []).append(linear)

    loners = {}
    for (qmap, K, k), ls in shared.items():
        if len(ls) == 1:
            linear = ls[0]
            loners.setdefault((linear.in_features, linear.out_features, K), []).append(linear)
            continue
        # Shared-Hessian group: chunk by total column count
        cap = max(ls[0].out_features, min(max_cat_cols, int(5e10) // k))
        chunk, cols = [], 0
        for linear in ls:
            if chunk and cols + linear.out_features > cap:
                groups.append(chunk)
                chunk, cols = [], 0
            chunk.append(linear)
            cols += linear.out_features
        if chunk:
            groups.append(chunk)

    for (k, n, K), ls in loners.items():
        # Same-shape stacking group: chunk by batch size
        cap = max(1, min(max_stack, int(5e10) // (k * n)))
        for i in range(0, len(ls), cap):
            groups.append(ls[i : i + cap])

    return groups


def group_label(group):
    prefix = os.path.commonprefix([linear.key for linear in group])
    return f"{prefix}* ({len(group)} tensors)"


def _tile_split_devices(numel, devices, device_ratios):
    """Cap the device count for tile-splitting one tensor: shredding a small tensor
    across many GPUs leaves shards too thin for a meaningful global-scale search
    (observed as g_sc collapsing to the search floor and proxy_err blowing up). Require
    ~1M weights per participating device, preferring the fastest devices."""
    max_dev = max(1, min(len(devices), numel // (1 << 20)))
    if max_dev >= len(devices):
        return devices, device_ratios
    if device_ratios is not None:
        order = sorted(range(len(devices)), key = lambda i: -device_ratios[i])[:max_dev]
        order.sort()
        return [devices[i] for i in order], [device_ratios[i] for i in order]
    return devices[:max_dev], None


def quantize_linears_single(args, linears, config, strategy, idx, devices, device_ratios, capture_H, state,
                            out_sens = None):
    out_sens = out_sens or {}
    out_hess = get_out_hessian_diags(args, linears)

    # Batched group quantization has no two-sided LDLQ: per-tensor path when precomputed Hessians are in play
    allow_grouping = state is not None and not args["image_dump"] and not args["verbose"] and not args.get("hessians_two_sided")
    groups = group_quant_linears(linears, strategy, capture_H if allow_grouping else None)

    for group in groups:
        if len(group) > 1:
            quant_args_list = [
                make_quant_args(
                    args,
                    idx,
                    strategy[l.key],
                    *_tile_split_devices(l.weights_numel(), devices, device_ratios),
                    out_sensitivity = out_sens.get(l.key),
                    out_hessian_diag = out_hess.get(l.key)
                ) for l in group]
            with Timer() as t:
                proxy_errs = convert_exl3_group(
                    group,
                    [capture_H[l.qmap] for l in group],
                    quant_args_list,
                    progress_str = f" -- <step>: {group_label(group)}",
                )
                for linear in group:
                    assert isinstance(linear.inner, LinearEXL3)
                    linear.inner.swap_cpu()
            time_str = f"  [{t.interval / len(group):4.2f} s]"
            for linear, quant_args, proxy_err in zip(group, quant_args_list, proxy_errs):
                print_quantized_linear(config, linear, quant_args, proxy_err, time_str)
            continue

        linear = group[0]
        if strategy[linear.key] == 16:
            print(
                f" -- Unquantized: {linear.key:{config.stc.max_key_len() + 6}}"
                f"  bpw: {16:5.2f}",
                flush = True
            )
        else:
            quant_args = make_quant_args(
                args,
                idx,
                strategy[linear.key],
                *_tile_split_devices(linear.weights_numel(), devices, device_ratios),
                out_sensitivity = out_sens.get(linear.key),
                out_hessian_diag = out_hess.get(linear.key)
            )

            with Timer() as t:
                sr = os.path.join(args["work_dir"], f"images/{linear.key}.reg.jpg") \
                    if args["image_dump"] else None
                H_data_, quant_args["H_out"] = get_H_data(args, linear, capture_H, state)
                proxy_err = linear.convert_exl3(
                    H_data_,
                    quant_args = quant_args,
                    progress_str = f" -- <step>: {linear.key}",
                    verbose = args["verbose"],
                    save_reg = sr,
                )
                assert isinstance(linear.inner, LinearEXL3)
                linear.inner.swap_cpu()
            print_quantized_linear(config, linear, quant_args, proxy_err, f"  [{t.interval:4.2f} s]")


def quantize_linears_parallel(args, linears, config, strategy, idx, devices, device_ratios, capture_H, state,
                              out_sens = None):
    assert not args["image_dump"], "Parallel mode is incompatible with --image_dump"
    out_sens = out_sens or {}
    out_hess = get_out_hessian_diags(args, linears)
    global curr_progress, max_progress

    allow_grouping = state is not None and not args["verbose"] and not args.get("hessians_two_sided")
    groups = group_quant_linears(linears, strategy, capture_H if allow_grouping else None)

    # Split workload by group
    all_dev_groups = [[] for _ in devices]

    tot_numel = sum(linear.weights_numel() for linear in linears)
    if device_ratios is None:
        dev_numel = [tot_numel // len(devices) for _ in devices]
    else:
        tot_split = sum(device_ratios)
        dev_numel = [tot_numel * r // tot_split for _, r in zip(devices, device_ratios)]

    for group in groups:
        g_numel = sum(linear.weights_numel() for linear in group)
        fit = [d_numel - g_numel for d_numel in dev_numel]
        bestfit = max(range(len(fit)), key = lambda x: fit[x])
        dev_numel[bestfit] -= g_numel
        all_dev_groups[bestfit].append(group)

    with progress_lock:
        curr_progress = 0
        max_progress = len(linears)

    # Worker thread. An uncaught exception in a worker must abort the whole job: a thread that
    # dies mid-module would otherwise leave its linears unquantized while the job carries on,
    # compiling a broken model at the end with only a warning in the scrollback
    errors = []

    def work_thread(device_idx, dev_groups):
        try:
            work_thread_(device_idx, dev_groups)
        except BaseException as e:
            errors.append(e)

    def work_thread_(device_idx, dev_groups):
        global curr_progress

        with torch.inference_mode():
            t0 = time.time()
            work_numel = sum(l.weights_numel() for g in dev_groups for l in g)

            for group in dev_groups:
                if len(group) > 1:
                    quant_args_list = [
                        make_quant_args(
                            args, idx, strategy[l.key], [device_idx],
                            out_sensitivity = out_sens.get(l.key), out_hessian_diag = out_hess.get(l.key))
                        for l in group
                    ]
                    proxy_errs = convert_exl3_group(
                        group,
                        [capture_H[l.qmap] for l in group],
                        quant_args_list,
                    )
                    for linear, quant_args_local, proxy_err in zip(group, quant_args_list, proxy_errs):
                        assert isinstance(linear.inner, LinearEXL3)
                        linear.inner.swap_cpu()
                        print_quantized_linear(config, linear, quant_args_local, proxy_err)
                        with progress_lock:
                            curr_progress += 1
                    continue

                linear = group[0]
                quant_args_local = make_quant_args(
                    args, idx, strategy[linear.key], [device_idx],
                    out_sensitivity = out_sens.get(linear.key), out_hessian_diag = out_hess.get(linear.key))

                H_data_, quant_args_local["H_out"] = get_H_data(args, linear, capture_H, state)
                proxy_err = linear.convert_exl3(
                    H_data_,
                    quant_args = quant_args_local,
                    verbose = args["verbose"],
                    save_reg = False,
                    override_swap_device = device_idx
                )
                assert isinstance(linear.inner, LinearEXL3)
                linear.inner.swap_cpu()

                print_quantized_linear(config, linear, quant_args_local, proxy_err)
                with progress_lock:
                    curr_progress += 1

            # The device is idle from here until the slowest thread finishes; its measured speed
            # steers the next module's split
            torch.cuda.synchronize(torch.device(device_idx))
            auto_split.report("quant_thread", device_idx, work_numel, time.time() - t0)

    # Launch
    threads = []
    for i, device_idx in enumerate(devices):
        if len(all_dev_groups[i]):
            t = threading.Thread(target = work_thread, args = (device_idx, all_dev_groups[i]))
            t.daemon = True
            threads.append(t)
    for t in threads:
        t.start()

    try:
        with ProgressBar(" -- Quantizing (parallel)", max_progress, transient = True) as progress:
            while any(t.is_alive() for t in threads) and not errors:
                progress.update(curr_progress)
                time.sleep(0.1)
    except KeyboardInterrupt as e:
        from signal import pthread_kill, SIGTSTP, SIGKILL
        for t in threads:
            pthread_kill(t.ident, SIGTSTP)
            pthread_kill(t.ident, SIGKILL)
        print("Aborted.")
        sys.exit()

    if errors:
        # Abort immediately (the other workers' remaining groups are wasted work); the traceback
        # of the failing worker is what the user needs to see
        print(f" !! Quantization worker failed, aborting job")
        raise errors[0]

    for t in threads:
        t.join(timeout = 0.1)


def check_bad_rows(bad_rows, num_rows, max_fraction = 0.10):
    """Abort the job when too much of the calibration set has been excluded as non-finite: past
    this point the remaining rows no longer represent the calibration distribution, and the
    breakage itself indicates something structurally wrong worth investigating (see the Hessian
    debug dumps in <work_dir>/debug/)."""
    if len(bad_rows) > max_fraction * num_rows:
        raise RuntimeError(
            f"{len(bad_rows)} of {num_rows} calibration rows have produced non-finite states "
            f"(> {max_fraction:.0%}), aborting job. Rows: {sorted(bad_rows)}"
        )


def calibration_row_shards(num_rows, devices, device_ratios):
    """
    Split calibration row indices into one contiguous shard per device, proportional to device_ratios if given.
    Row 0..num_ref_states-1 land in the first device's shard whenever it is non-empty, which keeps the reference
    states on the primary device.
    """
    w = device_ratios if device_ratios else [1] * len(devices)
    tot = sum(w)
    counts = [int(num_rows * r / tot) for r in w]   # ratios may be learned floats
    counts[0] += num_rows - sum(counts)
    shards, start = [], 0
    for c in counts:
        shards.append(range(start, start + c))
        start += c
    return shards


def load_parallel_calib_modules(replica_models, idx, devices, load_slice, source = None):
    """
    Load replicas of module idx onto secondary devices for parallel calibration passes. Returns the list of
    replica modules, or None if replication is unavailable (caller falls back to the serial path).
    """
    if not replica_models and len(devices) > 1:
        return None
    replicas = []
    try:
        for rm, dev in zip(replica_models, devices[1:]):
            rep = rm.modules[idx]
            if source is None and rep.can_defer_load():
                rm.config.stc.begin_deferred_load()
                try:
                    rep.load(torch.device(dev), load_slice = load_slice)
                finally:
                    rm.config.stc.end_deferred_load()
            else:
                rep.load(torch.device(dev), load_slice = load_slice,
                         **({"source": source} if source is not None else {}))
            replicas.append(rep)
        return replicas
    except Exception as e:
        print(f" !! Parallel calibration disabled for module {idx}: {e}")
        for rep in replicas:
            rep.unload()
        free_mem()
        return None


def run_row_workers(title, num_rows, workers, progress_count):
    """
    Run one worker thread per device with a shared progress bar, mirroring the interrupt handling of
    quantize_linears_parallel. Worker exceptions are collected and re-raised.
    """
    errors = []
    def guard(fn):
        def inner():
            try:
                with torch.inference_mode():
                    fn()
            except Exception as e:
                errors.append(e)
        return inner
    threads = [threading.Thread(target = guard(w), daemon = True) for w in workers]
    for t in threads:
        t.start()
    try:
        with ProgressBar(title, num_rows) as progress:
            while any(t.is_alive() for t in threads):
                progress.update(progress_count[0])
                time.sleep(0.05)
            progress.update(progress_count[0])
    except KeyboardInterrupt:
        from signal import pthread_kill, SIGTSTP, SIGKILL
        for t in threads:
            pthread_kill(t.ident, SIGTSTP)
            pthread_kill(t.ident, SIGKILL)
        print("Aborted.")
        sys.exit()
    for t in threads:
        t.join(timeout = 0.1)
    if errors:
        raise errors[0]



# Row batching for the calibration forwards (--calib_batch_rows). Rows are independent sequences of equal
# length, so stacking them along the batch dim gives the same per-row outputs, and the Hessian proxy is a
# plain sum over tokens (only fp32 summation order differs). Reference rows, rows already excluded, and rows
# carrying quant_preserve state keep the original one-row path.
CALIB_BATCH = 1


def _row_batchable(i, bad_rows, get_preserve):
    if i < num_ref_states or i in bad_rows:
        return False
    p = {}
    get_preserve(i, p)
    return len(p) == 1 and not p.get("quant_preserve")


def calib_chunks(rows, bad_rows, get_preserve, allow = True):
    rows = list(rows)
    n = CALIB_BATCH if allow else 1
    pos = 0
    while pos < len(rows):
        i = rows[pos]
        if n <= 1 or not _row_batchable(i, bad_rows, get_preserve):
            yield "one", i
            pos += 1
            continue
        chunk = []
        while pos < len(rows) and len(chunk) < n and _row_batchable(rows[pos], bad_rows, get_preserve):
            chunk.append(rows[pos])
            pos += 1
        if len(chunk) == 1:
            yield "one", chunk[0]
        else:
            yield "batch", chunk


def run_calib_chunks(rows, bad_rows, get_preserve, one, batch, allow = True):
    batch_limit = CALIB_BATCH if allow else 1
    for kind, item in calib_chunks(rows, bad_rows, get_preserve, allow):
        if kind == "one":
            one(item)
            continue
        pending = [item[i:i + batch_limit] for i in range(0, len(item), batch_limit)]
        while pending:
            chunk = pending.pop(0)
            if len(chunk) == 1:
                one(chunk[0])
                continue
            retry = False
            try:
                batch(chunk)
            except torch.cuda.OutOfMemoryError:
                batch_limit = max(1, len(chunk) // 2)
                middle = len(chunk) // 2
                pending[0:0] = [chunk[:middle], chunk[middle:]]
                retry = True
            if retry:
                torch.cuda.empty_cache()


def batch_input_ids(original_input_ids, chunk):
    ids = [original_input_ids[i] for i in chunk]
    return torch.stack(ids, 0) if ids[0].dim() == 1 else torch.cat(ids, 0)


def batch_states(state, chunk):
    xs = [state[i] for i in chunk]
    dev = xs[0].device
    xs = [x.to(dev) for x in xs]
    return torch.stack(xs, 0) if xs[0].dim() == 2 else torch.cat(xs, 0)


def unbatch_states(rs, chunk, state):
    if state[chunk[0]].dim() == 2:
        return [rs[j] for j in range(len(chunk))]
    return [rs[j:j + 1] for j in range(len(chunk))]


def capture_module_parallel(
    model,
    modules,
    devices,
    device_ratios,
    state,
    original_input_ids,
    get_preserve,
    put_preserve,
    slicing,
    current_slice,
    title,
    bad_rows,
):
    """
    Run the Hessian-capture forward pass with calibration rows split across devices, each device forwarding its
    shard through its own replica of the module. Per-device capture dicts are merged by summing H (the proxy is
    a plain sum over token batches), counts and inf/nan counters onto the primary device. The output sensitivity
    accumulators of the gated MLPs merge the same way.
    """
    shards = calibration_row_shards(len(state), devices, device_ratios)
    captures = [{} for _ in modules]
    captures_sens = [{} for _ in modules]
    ref_map = {}
    lock = threading.Lock()
    progress_count = [0]

    def make_worker(t_idx):
        def worker():
            module = modules[t_idx]
            t0 = time.time()
            done_rows = 0

            def one(i):
                nonlocal done_rows
                if i in bad_rows:
                    with lock:
                        progress_count[0] += 1
                    return
                params = {
                    "attn_mode": "flash_attn_nc",
                    "capture": captures[t_idx],
                    "capture_sens": captures_sens[t_idx],
                    "activate_all_experts": model.calibration_all_experts,
                    "input_ids": original_input_ids[i],
                }
                if slicing:
                    params["q_mlp_slice"] = current_slice
                get_preserve(i, params)
                rs = module.prepare_for_device(state[i], params)
                rs = module.forward(rs, params)
                put_preserve(i, params)
                if i < num_ref_states:
                    if model.calibration_all_experts:
                        # Do not activate all experts for reference state, for error measurement
                        params = {
                            "attn_mode": "flash_attn_nc",
                            "input_ids": original_input_ids[i],
                        }
                        if slicing:
                            params["q_mlp_slice"] = current_slice
                        get_preserve(i, params)
                        rs = module.prepare_for_device(state[i], params)
                        rs = module.forward(rs, params)
                        put_preserve(i, params)
                    if torch.isfinite(rs).all().item():
                        with lock:
                            ref_map[i] = rs.cpu()
                    else:
                        with lock:
                            bad_rows.add(i)
                        print(f" !! Non-finite reference state in calibration row {i}, excluding row")
                rs = None
                done_rows += 1
                with lock:
                    progress_count[0] += 1

            def batch(chunk):
                nonlocal done_rows
                attempt_capture = {}
                attempt_sens = {}
                params = {
                    "attn_mode": "flash_attn_nc",
                    "capture": attempt_capture,
                    "capture_sens": attempt_sens,
                    "activate_all_experts": model.calibration_all_experts,
                    "input_ids": batch_input_ids(original_input_ids, chunk),
                    "quant_preserve": {},
                }
                if slicing:
                    params["q_mlp_slice"] = current_slice
                rs = module.prepare_for_device(batch_states(state, chunk), params)
                rs = module.forward(rs, params)
                if params["quant_preserve"]:
                    raise RuntimeError("--calib_batch_rows: module uses quant_preserve, not batchable")
                for qmap, hd in attempt_capture.items():
                    if qmap not in captures[t_idx]:
                        captures[t_idx][qmap] = hd
                    else:
                        accumulated = captures[t_idx][qmap]
                        accumulated["H"] += hd["H"]
                        accumulated["count"] += hd["count"]
                        accumulated["num_total"] += hd["num_total"]
                        accumulated["inf_nan"] += hd["inf_nan"]
                merge_out_sensitivity(captures_sens[t_idx], attempt_sens)
                rs = None
                done_rows += len(chunk)
                with lock:
                    progress_count[0] += len(chunk)

            run_calib_chunks(shards[t_idx], bad_rows, get_preserve, one, batch)
            torch.cuda.synchronize(torch.device(devices[t_idx]))
            auto_split.report("calib", devices[t_idx], done_rows, time.time() - t0)
        return worker

    run_row_workers(title, len(state), [make_worker(i) for i in range(len(modules))], progress_count)

    # Merge secondary capture dicts into the primary one
    capture_H = captures[0]
    device = torch.device(devices[0])
    for cap in captures[1:]:
        for qmap, hd in cap.items():
            if qmap not in capture_H:
                hd["H"] = hd["H"].to(device)
                hd["inf_nan"] = hd["inf_nan"].to(device)
                hd["device"] = device
                capture_H[qmap] = hd
            else:
                m = capture_H[qmap]
                m["H"] += hd["H"].to(device)
                m["count"] += hd["count"]
                m["num_total"] += hd["num_total"]
                m["inf_nan"] += hd["inf_nan"].to(device)
        cap.clear()
    capture_sens = captures_sens[0]
    for cap in captures_sens[1:]:
        merge_out_sensitivity(capture_sens, cap)
        cap.clear()

    # Keyed by row index: rows excluded as non-finite leave gaps, so a list would misalign
    return capture_H, capture_sens, ref_map


def advance_state_parallel(
    model,
    modules,
    devices,
    device_ratios,
    state,
    original_input_ids,
    get_preserve,
    put_preserve,
    ref_states,
    have_linears,
    is_last_module,
    title,
    bad_rows,
):
    """
    Advance the calibration state through the (re-quantized) module with rows split across devices. Returns
    summed rfn/cos/sqnr over the reference rows and the number of rows measured. Rows in bad_rows are
    skipped; rows whose advanced state comes out non-finite are added to it.
    """
    shards = calibration_row_shards(len(state), devices, device_ratios)
    lock = threading.Lock()
    progress_count = [0]
    sums = [0.0, 0.0, 0.0, 0]

    def make_worker(t_idx):
        def worker():
            module = modules[t_idx]
            t0 = time.time()
            done_rows = 0

            def one(i):
                nonlocal done_rows
                if i in bad_rows:
                    with lock:
                        progress_count[0] += 1
                    return
                params = {
                    "attn_mode": "flash_attn_nc",
                    "input_ids": original_input_ids[i],
                }
                state[i] = module.prepare_for_device(state[i], params)
                row_bad = False
                if i < num_ref_states or not is_last_module:
                    get_preserve(i, params)
                    rs = module.forward(state[i], params)
                    if not torch.isfinite(rs).all().item():
                        row_bad = True
                        with lock:
                            bad_rows.add(i)
                        print(f" !! Non-finite hidden state in calibration row {i}, excluding row")
                    state[i] = rs.cpu()
                    put_preserve(i, params)
                ref = ref_states.get(i) if i < num_ref_states else None
                if ref is not None and have_linears and not row_bad:
                    ref = ref.to(state[i].device)
                    rfn, cos, sq = get_state_error(state[i], ref)
                    ref_states[i] = None
                    with lock:
                        sums[0] += rfn
                        sums[1] += cos
                        sums[2] += sq
                        sums[3] += 1
                done_rows += 1
                with lock:
                    progress_count[0] += 1

            def batch(chunk):
                nonlocal done_rows
                params = {
                    "attn_mode": "flash_attn_nc",
                    "input_ids": batch_input_ids(original_input_ids, chunk),
                    "quant_preserve": {},
                }
                x = module.prepare_for_device(batch_states(state, chunk), params)
                rs = module.forward(x, params)
                x = None
                if params["quant_preserve"]:
                    raise RuntimeError("--calib_batch_rows: module uses quant_preserve, not batchable")
                parts = unbatch_states(rs, chunk, state)
                for i, r in zip(chunk, parts):
                    if not torch.isfinite(r).all().item():
                        with lock:
                            bad_rows.add(i)
                        print(f" !! Non-finite hidden state in calibration row {i}, excluding row")
                    state[i] = r.cpu()
                rs = None
                done_rows += len(chunk)
                with lock:
                    progress_count[0] += len(chunk)

            run_calib_chunks(shards[t_idx], bad_rows, get_preserve, one, batch, allow = not is_last_module)
            torch.cuda.synchronize(torch.device(devices[t_idx]))
            auto_split.report("calib", devices[t_idx], done_rows, time.time() - t0)
        return worker

    run_row_workers(title, len(state), [make_worker(i) for i in range(len(modules))], progress_count)
    return sums[0], sums[1], sums[2], sums[3]


def image_dump(args, linears):
    if args["image_dump"]:
        for linear in linears:
            filename = f"images/{linear.key}.jpg"
            print(f" -- Saving image: {filename}")
            w = linear.inner.get_weight_tensor()
            assert w.dim() == 2
            save_tensor_image(w, os.path.join(args["work_dir"], filename))


def host_rss_str():
    """Resident set size of this process, for the per-module feedback line (empty string where
    /proc is unavailable)."""
    try:
        with open("/proc/self/statm") as f:
            rss_pages = int(f.read().split()[1])
        return f"  rss: {rss_pages * os.sysconf('SC_PAGE_SIZE') / 1024**3:.2f} GB"
    except Exception:
        return ""


def feedback_module(state, module, config, final_bpw, error, cos_error, sqnr_, module_time):
    if state:
        print(
            f" -- Quantized: {module.key:{config.stc.max_key_len() + 8}}" +
            (f"  bpw: {final_bpw:5.2f}" if final_bpw else f"  no_weights") +
            (f"  rfn: {error:.6f}" if module.num_slices == 1 else "        rfn: N/A     ") +
            f"  cos: {cos_error:.6f}"
            f"  sqnr: {sqnr_:.6f}"
            f"  [{module_time:.2f} s]" +
            host_rss_str(),
            flush = True
        )
    else:
        print(
            f" -- Quantized: {module.key:{config.stc.max_key_len() + 8}}" +
            (f"  bpw: {final_bpw:5.2f}" if final_bpw else f"  no_weights") +
            f"  [{module_time:.2f} s]" +
            host_rss_str(),
            flush = True
        )

timed_blocks = 0
eta_window = deque(maxlen = 8)

def feedback_eta(idx, model, module_time):
    global timed_blocks, eta_window
    if idx >= model.first_block_idx:
        timed_blocks += 1
        eta_window.append(module_time)
        remaining_blocks = max(0, len(model.modules) - idx - 1)
        if timed_blocks < 3:
            print(
                " -- Estimated remaining time: warming up "
                f"({timed_blocks}/3 timed blocks)"
            )
        else:
            avg_block_time = sum(eta_window) / len(eta_window)
            est_remaining = avg_block_time * remaining_blocks
            print(
                f" -- Estimated remaining time: {human_time(est_remaining)} "
                f"(avg over last {len(eta_window)} blocks)"
            )


def clear_temp_files(args):
    clear_files = args.get("clear_files")
    if clear_files:
        for p in clear_files:
            p.unlink()
        del args["clear_files"]


@torch.inference_mode()
def main(args, job_state):
    global max_progress, curr_progress, timed_blocks
    global CALIB_BATCH
    CALIB_BATCH = int(args.get("calib_batch_rows", 1) or 1)
    print(f" -- Calibration forwards batch {CALIB_BATCH} rows; devices {args.get('calib_devices', 0) or 'all'}")

    torch.set_printoptions(precision = 5, sci_mode = False, linewidth = 200)

    torch.set_grad_enabled(False)

    devices = [int(d) for d in args["devices"].split(",")]
    device = torch.device(devices[0])
    if args.get("device_ratios"):
        device_ratios = [int(d) for d in args["device_ratios"].split(",")]
        assert len(devices) == len(device_ratios), "--devices and --device_ratios must be same length"
    else:
        device_ratios = None

    # Without explicit --device_ratios, split workloads start even and adapt: each split
    # workload reports per-device busy times, and subsequent modules divide work in proportion
    # to the measured speeds (see AutoSplit). Workload kinds are tracked separately since
    # per-unit costs differ between quantization and calibration forwards
    def eff_ratios(kind):
        if device_ratios is not None or len(devices) == 1:
            return device_ratios
        return auto_split.ratios(kind, devices)

    last_auto_split = [None]
    def report_auto_split():
        if device_ratios is not None or len(devices) == 1:
            return
        parts = []
        for kind, label in (("quant_thread", "quant"), ("quant_tiles", "tiles"), ("calib", "calib")):
            if not auto_split.has_measured(kind, devices):
                continue
            r = auto_split.ratios(kind, devices)
            if r:
                tot = sum(r)
                parts.append(label + " " + ":".join(f"{100 * x / tot:.0f}" for x in r))
        if parts:
            line = ", ".join(parts)
            if line != last_auto_split[0]:
                last_auto_split[0] = line
                print(f" -- Auto device split: {line}")

    last_checkpoint_time = time.time()

    # Get model
    config, model, mtp_model, vision_model, tokenizer, use_reference_state = get_base_model(args)
    if args.get("hessians"):
        # Precomputed Hessians with an input-side factor replace the online capture: no calibration state, no forward
        # passes. An export with output-side factors only adds two-sided LDLQ to the normal calibrated conversion
        probe = next((f for f in sorted(os.listdir(args["hessians"])) if f.endswith(".safetensors") and "layers." in f), None)
        assert probe, f"No per-tensor Hessian files in {args['hessians']}"
        with safe_open(os.path.join(args["hessians"], probe), framework = "pt", device = "cpu") as f:
            ext_hin = "hin" in f.keys()
            ext_hout = "hout" in f.keys()
        args["hessians_two_sided"] = ext_hout and not args.get("hessians_one_sided")
        print(
            f" -- Using precomputed Hessians: {args['hessians']}" +
            ("" if ext_hin else " (output side only, input side captured online)") +
            ("" if args["hessians_two_sided"] else ", one-sided LDLQ")
        )
        if ext_hin:
            use_reference_state = False

    # Models with a hashed n-gram embedding table get it quantized (or copied from --ngram_file)
    # into the output directory up front, so the calibration forward pass runs on the quantized
    # table; resumable and skipped when already complete
    from .ngram import prepare_ngram_table_for_conversion
    prepare_ngram_table_for_conversion(args, config, model)

    # Check caps
    can_resume_quant = model.caps.get("can_resume_quant", use_reference_state)
    if not can_resume_quant:
        print(" !! Warning, resuming an interrupted quant is not possible for this architecture.")
        print(" !! Checkpoints will not be saved because they are redundant.")
        assert job_state["next_module_idx"] == 0, \
            "Current implementation of this architecture does not support resuming an interrupted quant job."

    # Get initial state or resume state
    if use_reference_state:
        state, original_input_ids = prepare_state(args, job_state, config, model, tokenizer)
        if original_input_ids is None:
            original_input_ids = (
                state.copy()
                if job_state["next_module_idx"] == 0 else
                [{} for _ in range(len(state))]
            )
        quant_preserves = [{} for _ in range(len(state))]
        # Rows whose hidden state (or unquantized reference) has gone non-finite are excluded
        # from all further capture, state advancement and error measurement. Persisted through
        # checkpoints; the job aborts if more than 10% of all rows break
        bad_rows = set(job_state.get("bad_rows") or [])
        if bad_rows:
            print(f" -- Resuming with {len(bad_rows)} excluded calibration rows")
    else:
        print(" -- Performing uncalibrated quantization")
        state = None
        bad_rows = set()

    def get_preserve(si, params_):
        params_.update(quant_preserves[si])
        params_["quant_preserve"] = quant_preserves[si]

    def put_preserve(si, params_):
        quant_preserves[si] = params_["quant_preserve"]

    # Get quantization strategy for model @bitrate
    print(" -- Deciding quantization strategy")
    hq = args["hq"]
    if args.get("recipe_strategy"):
        print(f"    Applying recipe: {args.get('recipe')}")
        strategy, final_bpw = create_q_strategy_from_recipe(
            model, mtp_model, config, args["recipe_strategy"], args["head_bits"], args["mtp_bits"],
            vision_model = vision_model, vision_bpw = args.get("vision_bits", 16),
        )
    else:
        strategy, final_bpw = create_q_strategy(
            model, mtp_model, config, args["bits"], args["head_bits"], args["mtp_bits"], hq,
            vision_model = vision_model, vision_bpw = args.get("vision_bits", 16),
            half_steps = args["codebook"] == "mul1",   # 1.5 / 2.5 / 3.5 bpw exist for the mul1 codebook only
        )
    args["final_bits"] = round(final_bpw, 2)
    print(" -- Quantization strategy, summary:")
    print(print_strategy(strategy))
    print(f" -- Final bitrate (excluding head): {final_bpw:4.2f}" + (" (--hq enabled)" if hq else ""))

    # With multiple devices, run the capture and state-advance forward passes with calibration rows split
    # across replicas of the current module, one per device. Calibration rows are independent and the H proxy
    # is a plain sum over token batches, so shards merge exactly.
    n_cd = int(args.get("calib_devices") or 0)
    calib_devices = devices[:n_cd] if 0 < n_cd < len(devices) else devices
    if calib_devices is not devices:
        print(f" -- Calibration forwards on {len(calib_devices)} of {len(devices)} devices")
    def calib_ratios():
        if device_ratios is not None:
            return device_ratios[:len(calib_devices)]
        if len(calib_devices) == 1:
            return None
        return auto_split.ratios("calib", calib_devices)
    parallel_calib = (
        state is not None and
        (len(calib_devices) > 1 or CALIB_BATCH > 1)
    )
    replica_models = [Model.from_config(config) for _ in calib_devices[1:]] if parallel_calib else []

    # Iterate over modules
    for idx, module in enumerate(model.modules):

        get_temp_buffers.cache_clear()
        free_mem()

        start_module_time = time.time()
        if idx == model.first_block_idx:
            timed_blocks = 0

        # If resuming, skip along to checkpoint index
        if idx < job_state["next_module_idx"]:
            continue

        if args["max_module"] is not None and idx > args["max_module"]:
            print(" !! --max_module reached, stopping job")
            sys.exit()

        # Collect output tensors
        q_tensors = {}
        capture_H = None
        capture_sens = None
        ref_states = {}

        # Slice module if necessary
        slicing = module.num_slices > 1
        for current_slice in range(module.num_slices):

            # Load current module
            slice_str = f" (slice {current_slice + 1}/{module.num_slices})" if slicing else ""
            print(f" -- Loading unquantized module: {module.key}" + slice_str)
            # Deferred mode batches every tensor of the module into coalesced, multithreaded
            # engine reads; big sparse layers otherwise pay one synchronous round trip per
            # expert tensor, which is latency-bound on slow/network storage. can_defer_load()
            # excludes modules whose load derives copies from unfilled tensors (e.g. sliced
            # Linears, whose LinearFP16 copies each slice out of its source at construction)
            defer = module.can_defer_load()
            if defer:
                module.config.stc.begin_deferred_load()
            try:
                module.load(
                    torch.device("cpu") if module.caps.get("prefer_cpu") else device,
                    load_slice = current_slice if slicing else None,
                    keep_source_weights = True
                )
            finally:
                if defer:
                    module.config.stc.end_deferred_load()
            for m in module:
                if m.used_alt_key and not slicing:
                    print(f"     - Cloned {m.key} from {m.alt_key}")
            module.config.stc.close()

            # Skip modules without quant targets
            qmaps = module.get_qmaps()
            if len(qmaps) > 0:

                # Capture calibration input states during forward pass. For block-sparse models, all expert layers
                # are activated to ensure all down projections capture at least some calibration data. When the
                # state is advanced later, only selected experts will be used.
                if state is not None:
                    capture_replicas = None
                    if parallel_calib and not module.caps.get("prefer_cpu"):
                        capture_replicas = load_parallel_calib_modules(
                            replica_models, idx, calib_devices, current_slice if slicing else None)
                    if capture_replicas is not None:
                        capture_H, capture_sens, ref_states = capture_module_parallel(
                            model,
                            [module] + capture_replicas,
                            calib_devices,
                            calib_ratios(),
                            state,
                            original_input_ids,
                            get_preserve,
                            put_preserve,
                            slicing,
                            current_slice,
                            f" -- Capturing: {module.key}" + slice_str,
                            bad_rows,
                        )
                        for rep in capture_replicas:
                            rep.unload()
                        free_mem()
                    else:
                        with ProgressBar(f" -- Capturing: {module.key}" + slice_str, len(state)) as progress:
                            capture_H = {}
                            capture_sens = {}
                            ref_states = {}
                            for i in range(len(state)):
                                progress.update(i)
                                if i in bad_rows:
                                    continue
                                params = {
                                    "attn_mode": "flash_attn_nc",
                                    "capture": capture_H,
                                    "capture_sens": capture_sens,
                                    "activate_all_experts": model.calibration_all_experts,
                                    "input_ids": original_input_ids[i],
                                }
                                if slicing:
                                     params["q_mlp_slice"] = current_slice
                                get_preserve(i, params)
                                rs = module.prepare_for_device(state[i], params)
                                rs = module.forward(rs, params)
                                put_preserve(i, params)
                                if i < num_ref_states:
                                    if model.calibration_all_experts:
                                        # Do not activate all experts for reference state, for error measurement
                                        params = {
                                            "attn_mode": "flash_attn_nc",
                                            "input_ids": original_input_ids[i],
                                        }
                                        if slicing:
                                            params["q_mlp_slice"] = current_slice
                                        get_preserve(i, params)
                                        rs = module.prepare_for_device(state[i], params)
                                        rs = module.forward(rs, params)
                                        put_preserve(i, params)
                                    if torch.isfinite(rs).all().item():
                                        ref_states[i] = rs.cpu()
                                    else:
                                        bad_rows.add(i)
                                        print(f" !! Non-finite reference state in calibration row {i}, excluding row")
                                rs = None
                    print(f" -- Captured: {module.key}" + slice_str, flush = True)

                    # More feedback
                    if len(capture_H):
                        hfb_keys = [re.sub(r'\d+', '*', k) for k in capture_H.keys()]
                        hfb_keys = sorted(list(set(hfb_keys)))
                        print(f" -- Hessians: " + ", ".join(hfb_keys))
                    else:
                        print(f" !! Hessians: None")

                    # Check for infs or NaNs in H
                    for k, v in capture_H.items():
                        infs, nans = v["inf_nan"][0].item(), v["inf_nan"][1].item()
                        if infs or nans:
                            numel = v["num_total"]
                            print(f" !! Warning: {k} state has {infs:,} inf values and {nans:,} NaN values (out of {numel:,})")

                    # Swap captured H to system RAM
                    for k, v in capture_H.items():
                        v["H_swap_device"] = v["H"].device
                        v["H"] = v["H"].cpu()

            # Get submodules to quantize
            linears = [m for m in module if isinstance(m, Linear) and m.qmap and m.device is not None]
            for linear in linears:
                assert linear.key in strategy, \
                    f" ## Logic error, no quantization strategy for module {linear.key}"
            assert all(isinstance(linear.inner, LinearFP16) for linear in linears)

            # Write images
            image_dump(args, linears)

            # Move original tensors to system RAM (load to GPU one by one when quantizing)
            for linear in linears:
                linear.inner.swap_cpu()

            # Output sensitivity of the gate and up projections (auto output scales)
            out_sens = finalize_out_sensitivity(capture_sens) if capture_sens else None
            capture_sens = None

            # Opt-in, both off by default and then nothing below runs: dump the raw Hessians, and keep
            # what a re-encode of outlier matrices needs (raw H, original weights, biases)
            if args.get("dump_hessians") and capture_H:
                nbytes = dump_raw_hessians(
                    args["dump_hessians"], module, current_slice if slicing else None, capture_H, linears
                )
                print(f" -- Dumped Hessians: {module.key}{slice_str} ({nbytes / 1024**2:.1f} MB)", flush = True)
            retry_ctx = None
            if args.get("retry_outliers") and state is not None and capture_H:
                retry_ctx = (
                    snapshot_raw_H(capture_H, linears),
                    {l.key: l.inner.get_weight_tensor() for l in linears if strategy[l.key] != 16},
                    {l.key: l.inner.get_bias_tensor() for l in linears},
                )
                retry_capture_begin()

            # Quantize: one linear per device in parallel when the layer has enough
            # tensors to occupy every device, else tile-split each tensor across devices
            # (single large tensors, e.g. lm_head)
            if (
                len(linears) >= len(devices) and
                all(strategy[l.key] <= 8 for l in linears)
            ):
                quantize_linears_parallel(
                    args, linears, config, strategy, idx, devices, eff_ratios("quant_thread"), capture_H, state, out_sens)
            else:
                quantize_linears_single(
                    args, linears, config, strategy, idx, devices, eff_ratios("quant_tiles"), capture_H, state, out_sens)

            # --retry_outliers: re-encode matrices that look like a scale search collapse (seeds idx + 1000 k)
            if retry_ctx is not None:
                retry_raw_H, retry_weights, retry_biases = retry_ctx
                retry_module_outliers(
                    args, module.key + slice_str, linears, strategy, idx, device,
                    retry_weights, retry_biases, retry_raw_H, retry_capture_end()
                )
                retry_ctx = retry_raw_H = retry_weights = retry_biases = None

            # Collect converted module tensors
            for m in module:
                if m is module and isinstance(m, Embedding) and m.allow_table and args["embed_bits"] < 16:
                    tensors, rfn = quantize_embedding(m.key, m.embedding.weight.data, args["embed_bits"], device)
                    print(f" -- Quantized: {m.key}  bpw: {args['embed_bits']}  rfn: {rfn:.6f}")
                    q_tensors.update(tensors)
                else:
                    q_tensors.update(m.get_tensors())

            # Unload module
            if not module.caps.get("retain_during_quant"):
                module.unload()
            capture_H = None
            config.stc.close()

        # Save layer tensors to working directory
        clear_temp_files(args)
        save_tensor(q_tensors, f"qtensors/{module.key}.safetensors", args)

        # Output final bpw for layer
        num_bytes = dsize(q_tensors)
        num_bits = num_bytes * 8
        final_bpw = num_bits / module.weights_numel() if module.weights_numel() else None

        # Reload module from memory
        config.stc.set_new_tensors(q_tensors)
        module.load(
            torch.device("cpu") if module.caps.get("prefer_cpu") else device,
            source = q_tensors,
            keep_source_weights = True
        )
        advance_replicas = None
        if state is not None and parallel_calib and not module.caps.get("prefer_cpu"):
            advance_replicas = load_parallel_calib_modules(
                replica_models, idx, calib_devices, None, source = q_tensors)
        config.stc.set_new_tensors(None)
        del q_tensors

        # Advance state
        error = 0
        cos_error = 0
        sqnr_ = 0
        if state is not None:
            if advance_replicas is not None:
                error, cos_error, sqnr_, num_measured = advance_state_parallel(
                    model,
                    [module] + advance_replicas,
                    calib_devices,
                    calib_ratios(),
                    state,
                    original_input_ids,
                    get_preserve,
                    put_preserve,
                    ref_states,
                    len(linears) > 0,
                    idx >= len(model.modules) - 1,
                    f" -- Forward pass: {module.key}",
                    bad_rows,
                )
                for rep in advance_replicas:
                    rep.unload()
                free_mem()
                n = max(num_measured, 1)
                error /= n
                cos_error /= n
                sqnr_ /= n
                check_bad_rows(bad_rows, len(state))
            else:
                num_measured = 0
                with ProgressBar(f" -- Forward pass: {module.key}", len(state)) as progress:
                    for i in range(len(state)):
                        progress.update(i)
                        if i in bad_rows:
                            continue
                        params = {
                            "attn_mode": "flash_attn_nc",
                            "input_ids": original_input_ids[i],
                        }
                        state[i] = module.prepare_for_device(state[i], params)
                        if i < num_ref_states or idx < len(model.modules) - 1:
                            get_preserve(i, params)
                            rs = module.forward(state[i], params)
                            if not torch.isfinite(rs).all().item():
                                bad_rows.add(i)
                                print(f" !! Non-finite hidden state in calibration row {i}, excluding row")
                            state[i] = rs.cpu()
                            put_preserve(i, params)
                        ref = ref_states.get(i) if i < num_ref_states else None
                        if ref is not None and len(linears) and i not in bad_rows:
                            ref = ref.to(state[i].device)
                            rfn, cos, sq = get_state_error(state[i], ref)
                            error += rfn
                            cos_error += cos
                            sqnr_ += sq
                            num_measured += 1
                            ref_states[i] = None
                n = max(num_measured, 1)
                error /= n
                cos_error /= n
                sqnr_ /= n
                check_bad_rows(bad_rows, len(state))

        # Feedback after module. Trim first so the reported RSS reflects what the job actually
        # retains, not what the allocator happens to be holding
        malloc_trim()
        module_time = time.time() - start_module_time
        feedback_module(state, module, config, final_bpw, error, cos_error, sqnr_, module_time)
        report_auto_split()
        feedback_eta(idx, model, module_time)

        # Unload current module
        if not module.caps.get("retain_during_quant"):
            module.unload()

        # Checkpoint
        job_state["next_module_idx"] = idx + 1
        if can_resume_quant and \
            time.time() > last_checkpoint_time + args["checkpoint_interval"] and \
            (args.get("last_checkpoint_index", -1) < 0 or idx <= args["last_checkpoint_index"]):
            print(f" -- Saving checkpoint")
            ckpt_dir = os.path.join(args["work_dir"], "ckpt")
            ckpt_dir_old = os.path.join(args["work_dir"], "ckpt_old")
            ckpt_dir_new = os.path.join(args["work_dir"], "ckpt_new")
            os.makedirs(ckpt_dir_new, exist_ok = True)
            job_state["bad_rows"] = sorted(bad_rows)
            save_dict("ckpt_new/job.json", job_state, args)
            save_tensor(state, "ckpt_new/state.safetensors", args)
            save_tensor(original_input_ids, "ckpt_new/original_input_ids.safetensors", args)
            if os.path.exists(ckpt_dir_old):
                shutil.rmtree(ckpt_dir_old)
            os.rename(ckpt_dir, ckpt_dir_old)
            os.rename(ckpt_dir_new, ckpt_dir)
            last_checkpoint_time = time.time()

    # Quantize additional modules (uncalibrated side models: MTP head, vision tower)
    def quantize_side_model(side_model, title):
        print(f" -- Quantizing {title} tensors")

        for idx, module in enumerate(side_model.modules):
            assert module.num_slices <= 1
            get_temp_buffers.cache_clear()   # see main loop
            free_mem()
            start_module_time = time.time()

            q_tensors = {}
            print(f" -- Loading unquantized module: {module.key}")
            defer = module.can_defer_load()
            if defer:
                module.config.stc.begin_deferred_load()
            try:
                module.load(torch.device("cpu") if module.caps.get("prefer_cpu") else device,
                            keep_source_weights = True)
            finally:
                if defer:
                    module.config.stc.end_deferred_load()
            for m in module:
                if m.used_alt_key:
                    print(f"     - Cloned {m.key} from {m.alt_key}")
            module.config.stc.close()

            linears = [m for m in module if isinstance(m, Linear) and m.qmap and m.device is not None]
            for linear in linears:
                assert linear.key in strategy, \
                    f" ## Logic error, no quantization strategy for module {linear.key}"
            assert all(isinstance(linear.inner, LinearFP16) for linear in linears)

            # Write images
            image_dump(args, linears)

            # Move original tensors to system RAM (load to GPU one by one when quantizing)
            for linear in linears:
                linear.inner.swap_cpu()

            # Quantize (same dispatch as the main loop)
            if (
                len(linears) >= len(devices) and
                all(strategy[l.key] <= 8 for l in linears)
            ):
                quantize_linears_parallel(args, linears, config, strategy, idx, devices, eff_ratios("quant_thread"), None, None)
            else:
                quantize_linears_single(args, linears, config, strategy, idx, devices, eff_ratios("quant_tiles"), None, None)

            # Collect converted module tensors
            for m in module:
                q_tensors.update(m.get_tensors())

            # Unload module
            module.unload()
            config.stc.close()

            # Save layer tensors to working directory
            clear_temp_files(args)
            save_tensor(q_tensors, f"qtensors/{module.key}.safetensors", args)

            # Output final bpw for layer
            num_bytes = dsize(q_tensors)
            num_bits = num_bytes * 8
            final_bpw = num_bits / module.weights_numel() if module.weights_numel() else None

            # Feedback after module
            malloc_trim()
            module_time = time.time() - start_module_time
            feedback_module(state, module, config, final_bpw, 0, 0, 0, module_time)

            # Unload current module
            module.unload()
            del q_tensors

    if mtp_model:
        quantize_side_model(mtp_model, "MTP")
    if vision_model:
        quantize_side_model(vision_model, "vision model")

    # Compile model
    compile_model(args, model, config, tokenizer, mtp_model, vision_model)

    # All done
    print(" -- All done")


if __name__ == "__main__":
    _args = parser.parse_args()
    _in_args, _job_state, _ok, _err = prepare(_args)
    if not _ok:
        print(f" !! Error: {_err}")
    else:
        main(_in_args, _job_state)
