from __future__ import annotations
from typing_extensions import override
import os, json
import numpy as np
import torch
from ..model.config import Config
from ..model.model import Model
from ..util.rope import RopeSettings, RopeStyle
from ..util.file import read_dict, no_default
from .mm_processing.common import convert_to_rgb, normalize_image, size_to_longest_edge_and_patch_size
from ..modules import (
    RMSNorm,
    Embedding,
    TransformerBlock,
    Attention,
    GatedMLP,
    Linear,
    Conv,
    MLP,
)
from ..modules.arch_specific.mistral3 import Mistral3PatchMerger
from ..modules.attn import prepare_for_attn
from ..tokenizer import Tokenizer, MMEmbedding
from types import SimpleNamespace
from PIL import Image
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .ministral3 import Ministral3Config

class Mistral3Config(Config):
    arch_string = "Mistral3ForConditionalGeneration"

    def __init__(
        self,
        directory: str,
        **kwargs,
    ):
        # Mistral-Small-4 shares the Mistral3ForConditionalGeneration wrapper (same Pixtral
        # tower and projector) around an MLA + MoE text stack; dispatch on the text model_type
        with open(os.path.join(directory, "config.json"), encoding = "utf8") as f:
            text_model_type = json.load(f).get("text_config", {}).get("model_type")
        if text_model_type == "mistral4":
            from .mistral4 import mistral4_init_config
            mistral4_init_config(self, directory, **kwargs)
            self._read_vision_config()
            return

        super().__init__(
            directory,
            {"text": Mistral3Model, "vision": Mistral3VisionModel},
            **kwargs
        )

        # Attention params
        self.head_dim = self.read_cfg(int, "text_config->head_dim", None)
        self.hidden_size = self.read_cfg(int, "text_config->hidden_size", no_default)
        self.num_q_heads = self.read_cfg(int, "text_config->num_attention_heads", no_default)
        self.num_kv_heads = self.read_cfg(int, "text_config->num_key_value_heads", self.num_q_heads)

        if not self.head_dim:
            self.head_dim = self.hidden_size // self.num_q_heads

        # MLP params
        self.assert_cfg(str, "text_config->hidden_act", "silu", True)
        self.intermediate_size = self.read_cfg(int, "text_config->intermediate_size", no_default)

        # Norms
        self.rms_norm_eps = self.read_cfg(float, "text_config->rms_norm_eps", no_default)

        # Layers
        self.num_hidden_layers = self.read_cfg(int, "text_config->num_hidden_layers", no_default)
        self.tie_word_embeddings = self.read_cfg(bool, "text_config->tie_word_embeddings", False)

        # RoPE
        text_cfg = self.read_cfg(dict, "text_config", no_default)
        self.rope_settings = self.read_rope_settings_default(RopeStyle.NEOX, config_dict = text_cfg)

        self._read_vision_config()


    def _read_vision_config(self):
        """Vision tower / projector / preprocessor settings, shared between the mistral text
        stack and the mistral4 (MLA + MoE) text stack. Requires rms_norm_eps to be set."""

        def unpack_patch_size(patch_temp: dict | int):
            if isinstance(patch_temp, dict):
                h, w = (patch_temp.get(x) for x in ["height", "width"])
                assert w == h, f"Pixtral image preprocessor requires square patches, not {h} x {w}"
                patch_temp = h
            assert isinstance(patch_temp, int), "Unexpected type for patch_size"
            return patch_temp

        self.vision = SimpleNamespace(
            head_dim = self.read_cfg(int, ["vision_config->head_dim"], no_default),
            num_q_heads = self.read_cfg(int, ["vision_config->num_attention_heads"], no_default),
            multimodal_projector_bias = self.read_cfg(bool, ["multimodal_projector_bias"], False),
            hidden_size = self.read_cfg(int, ["vision_config->hidden_size"], no_default),
            patch_size = unpack_patch_size(self.read_cfg(object, ["vision_config->patch_size"], int(14))),
            num_hidden_layers = self.read_cfg(int, ["vision_config->num_hidden_layers"], 24),
            intermediate_size = self.read_cfg(int, ["vision_config->intermediate_size"], no_default),
            rms_norm_eps = self.rms_norm_eps,
            image_size = self.read_cfg(int, ["vision_config->image_size"], 1540),
            spatial_merge_size = self.read_cfg(int, ["spatial_merge_size"], 1),
            rope_theta = self.read_cfg(int, ["vision_config->rope_theta"], 10000.0),
        )
        self.vision.num_kv_heads = self.read_cfg(int, ["vision_config->num_key_value_heads"], self.vision.num_q_heads)
        self.vision.merger_intermediate_size = self.vision.intermediate_size

        vision_cfg = self.read_cfg(dict, "vision_config", no_default)
        self.vision.rope_settings = self.read_rope_settings_default(RopeStyle.NEOX, config_dict = vision_cfg)

        self.vision.num_channels = 3
        self.vision.feature_layer = -1
        self.assert_cfg(int, "vision_config->num_channels", self.vision.num_channels, True)
        self.assert_cfg(int, "vision_feature_layer", self.vision.feature_layer, True)

        # Vision preprocessor
        prep_path = os.path.join(self.directory, "preprocessor_config.json")
        if os.path.exists(prep_path):
            with open(prep_path, encoding = "utf8") as f:
                read_prep_config = json.load(f)
        else:
            prep_path = os.path.join(self.directory, "processor_config.json")
            with open(prep_path, encoding = "utf8") as f:
                read_prep_config = json.load(f)
                read_prep_config = read_prep_config["image_processor"]
        image_processor_type = read_dict(read_prep_config, str, ["image_processor_type"], no_default)
        assert image_processor_type in ["PixtralImageProcessor", "PixtralImageProcessorFast"], \
            f"Wrong image processor type: {image_processor_type}"
        self.vision_pp = SimpleNamespace(
            image_mean = read_dict(read_prep_config, list, ["image_mean"], no_default),
            image_std = read_dict(read_prep_config, list, ["image_std"], no_default),
            resample = read_dict(read_prep_config, int, ["resample"], no_default),
            rescale_factor = read_dict(read_prep_config, float, ["rescale_factor"], no_default),
            size = read_dict(read_prep_config, dict, ["size"], no_default),
            patch_size = unpack_patch_size(read_dict(read_prep_config, object, ["patch_size"], no_default)),
        )


        assert self.vision.patch_size == self.vision_pp.patch_size, \
            "Vision model and vision preprocessor patch sizes do not match"

        # New style:  model.language_model.embed_tokens.weight
        # Old style:  language_model.model.embed_tokens.weight
        self.new_key_style = self.stc.has_tensor("model.language_model.embed_tokens.weight")

class Mistral3Model(Model):
    config_class = Mistral3Config

    def __init__(
        self,
        config: Mistral3Config | Ministral3Config,
        key_prefix = "language_model",
        **kwargs
    ):
        super().__init__(config, **kwargs)

        # Auto-detect key naming convention
        if config.new_key_style:
            # New keys: model.language_model.{name}
            lm = f"model.{key_prefix}"
            head = "lm_head"
        else:
            # Original keys: language_model.model.{name}
            lm = f"{key_prefix}.model" if key_prefix else "model"
            head = f"{key_prefix}.lm_head" if key_prefix else "lm_head"

        self.modules += [
            Embedding(
                config = config,
                key = f"{lm}.embed_tokens",
                vocab_size = config.vocab_size,
                hidden_size = config.hidden_size,
            )
        ]

        self.first_block_idx = len(self.modules)
        self.modules += [
            TransformerBlock(
                config = config,
                key = f"{lm}.layers.{idx}",
                layer_idx = idx,
                attn_norm = RMSNorm(
                    config = config,
                    key = f"{lm}.layers.{idx}.input_layernorm",
                    rms_norm_eps = config.rms_norm_eps,
                ),
                attn = Attention(
                    config = config,
                    key = f"{lm}.layers.{idx}.self_attn",
                    layer_idx = idx,
                    hidden_size = config.hidden_size,
                    head_dim = config.head_dim,
                    num_q_heads = config.num_q_heads,
                    num_kv_heads = config.num_kv_heads,
                    rope_settings = config.rope_settings,
                    sm_scale = None,
                    key_q = "q_proj",
                    key_k = "k_proj",
                    key_v = "v_proj",
                    key_o = "o_proj",
                    qmap = "block.attn",
                    out_dtype = torch.float,
                ),
                mlp_norm = RMSNorm(
                    config = config,
                    key = f"{lm}.layers.{idx}.post_attention_layernorm",
                    rms_norm_eps = config.rms_norm_eps,
                ),
                mlp = GatedMLP(
                    config = config,
                    key = f"{lm}.layers.{idx}.mlp",
                    hidden_size = config.hidden_size,
                    intermediate_size = config.intermediate_size,
                    key_up = "up_proj",
                    key_gate = "gate_proj",
                    key_down = "down_proj",
                    qmap = "block.mlp",
                    # interm_dtype = torch.float,
                    out_dtype = torch.float,
                ),
            )
            for idx in range(config.num_hidden_layers)
        ]

        self.last_kv_module_idx = len(self.modules) - 1

        head_alt_key = None
        if config.tie_word_embeddings and not self.config.stc.has_tensor(head):
            head_alt_key = f"{lm}.embed_tokens"

        self.modules += [
            RMSNorm(
                config = config,
                key = f"{lm}.norm",
                rms_norm_eps = config.rms_norm_eps,
                out_dtype = torch.half,
            ),
            Linear(
                config = config,
                key = head,
                qbits_key = "head_bits",
                alt_key = head_alt_key,
                in_features = config.hidden_size,
                out_features = config.vocab_size,
                qmap = "block",
                caps = {"logits_output": True}
            )
        ]
        self.logit_layer_idx = len(self.modules) - 1

    @override
    def prepare_inputs(self, input_ids: torch.Tensor, params: dict) -> torch.Tensor:
        input_ids = prepare_for_attn(input_ids, params)
        return input_ids


    @override
    def default_chat_prompt(self, prompt: str, system_prompt: str = None) -> str:
        p = "<s>"
        if system_prompt:
            p += f"[SYSTEM_PROMPT]{system_prompt}[/SYSTEM_PROMPT]"
        p += f"[INST]{prompt}[/INST]"
        return p



class Mistral3VisionModel(Model):
    @staticmethod
    @override
    def get_additional_compiled_tensors(config: Mistral3Config) -> dict:
        # Try both prefixes
        vlm_tensors = config.stc.list_tensors(prefix = "vision_tower")
        if not vlm_tensors:
            vlm_tensors = config.stc.list_tensors(prefix = "model.vision_tower")
        mmp_tensors = config.stc.list_tensors(prefix = "multi_modal_projector")
        if not mmp_tensors:
            mmp_tensors = config.stc.list_tensors(prefix = "model.multi_modal_projector")
        return vlm_tensors | mmp_tensors

    def __init__(
        self,
        config: Mistral3Config,
        key_prefix = "vision_tower",
        **kwargs
    ):
        super().__init__(config, **kwargs)
        self.config = config

        # Auto-detect key naming convention
        if config.new_key_style:
            vt = "model.vision_tower"
            mmp = "model.multi_modal_projector"
        else:
            vt = key_prefix
            mmp = "multi_modal_projector"

        self.caps.update({"image_input": True})

        self.modules += [
            Conv(
                config = config,
                key = f"{vt}.patch_conv",
                in_channels = config.vision.num_channels,
                out_channels = config.vision.hidden_size,
                kernel_size = (config.vision.patch_size, config.vision.patch_size),
            ),
            RMSNorm(
                config = config,
                key = f"{vt}.ln_pre",
                rms_norm_eps = config.rms_norm_eps,
            )
        ]

        self.modules += [
            TransformerBlock(
                config = config,
                key = f"{vt}.transformer.layers.{idx}",
                layer_idx = idx,
                attn_norm = RMSNorm(
                    config = config,
                    key = f"{vt}.transformer.layers.{idx}.attention_norm",
                    rms_norm_eps = config.vision.rms_norm_eps
                ),
                attn = Attention(
                    config = config,
                    key = f"{vt}.transformer.layers.{idx}.attention",
                    layer_idx = idx,
                    hidden_size = config.vision.hidden_size,
                    head_dim = config.vision.head_dim,
                    num_q_heads = config.vision.num_q_heads,
                    num_kv_heads = config.vision.num_kv_heads,
                    rope_settings = RopeSettings(
                        head_dim = config.vision.head_dim,
                        rope_theta = config.vision.rope_theta,
                    ),
                    key_q = "q_proj",
                    key_k = "k_proj",
                    key_v = "v_proj",
                    key_o = "o_proj",
                    qmap = "block.attn"
                ),
                mlp_norm = RMSNorm(
                    config = config,
                    key = f"{vt}.transformer.layers.{idx}.ffn_norm",
                    rms_norm_eps = config.vision.rms_norm_eps
                ),
                mlp = GatedMLP(
                    config = config,
                    key = f"{vt}.transformer.layers.{idx}.feed_forward",
                    hidden_size = config.vision.hidden_size,
                    intermediate_size = config.vision.intermediate_size,
                    key_gate = "gate_proj",
                    key_up = "up_proj",
                    key_down = "down_proj",
                    activation_fn = "silu",
                    qmap = "block.mlp",
                    pad_to = 1,
                ),
            )
            for idx in range(config.vision.num_hidden_layers)
        ]

        self.modules += [
            RMSNorm(
                config = config,
                key = f"{mmp}.norm",
                rms_norm_eps = config.vision.rms_norm_eps,
                out_dtype = torch.half,
            ),
            Mistral3PatchMerger(
                config = config,
                key = f"{mmp}.patch_merger",
                hidden_size = config.vision.hidden_size,
                merge = config.vision.spatial_merge_size,
                out_dtype = torch.half,
            ),
            MLP(
                config = config,
                key = mmp,
                key_up = "linear_1",
                key_down = "linear_2",
                hidden_size = config.vision.hidden_size,
                intermediate_size = config.hidden_size,
                out_size = config.hidden_size,
                activation_fn = "gelu",
                qmap = "block",
            )
        ]

        # Precomputed RoPE table following Transformers implementation
        self.max_edge_features = config.vision_pp.size["longest_edge"] // config.vision_pp.patch_size
        freqs = 1.0 / (
            config.vision.rope_theta ** (
                torch.arange(0, config.vision.head_dim, 2).float()
                / config.vision.head_dim
            )
        )
        h = torch.arange(self.max_edge_features).float()
        w = torch.arange(self.max_edge_features).float()
        freqs_h = torch.outer(h, freqs[::2])
        freqs_w = torch.outer(w, freqs[1::2])
        self.inv_freq = torch.cat(
            [
                freqs_h[:, None, :].repeat(1, self.max_edge_features, 1),
                freqs_w[None, :, :].repeat(self.max_edge_features, 1, 1),
            ],
            dim = -1,
        ).reshape(-1, config.vision.head_dim // 2)


    def preprocess(
        self,
        image: Image
    ) -> (torch.Tensor, tuple):
        """
        Convert input image to the size and format expected by the vision tower. Image is scaled proportionally to
        fit a bounding box of longest_edge x longest_edge pixels as defined by the preprocessor config, while still
        being divisible into tiles of spatial_merge_size x spatial_merge_size input patches. Each such tile will be
        merged into one multimodal feature token by the vision tower.
        """

        patch_2d = (
            self.config.vision_pp.patch_size * self.config.vision.spatial_merge_size,
            self.config.vision_pp.patch_size * self.config.vision.spatial_merge_size,
        )
        longest_edge = self.config.vision_pp.size["longest_edge"]
        resample = Image.Resampling(self.config.vision_pp.resample)
        image_mean = tuple(self.config.vision_pp.image_mean)
        image_std = tuple(self.config.vision_pp.image_std)
        rescale_factor = self.config.vision_pp.rescale_factor

        # Convert to RGB and resize as necessary
        image = convert_to_rgb(image)
        old_size = image.size
        new_size = size_to_longest_edge_and_patch_size(image.size, (longest_edge, longest_edge), patch_2d)
        if old_size != new_size:
            image = image.resize(new_size, resample = resample)

        # Convert to numpy array and normalize
        image = np.array(image).astype(np.float32)
        image = image * rescale_factor
        image = normalize_image(image, image_mean, image_std)

        # Convert to tensor, shape (1, 3, resized_height, resized_width)
        image = image.transpose(2, 0, 1)
        image = torch.from_numpy(image).half().unsqueeze(0)
        return image, new_size


    def default_load_shape_dtype(self, chunk_size):
        return (
            (
                1,
                self.config.vision.num_channels,
                self.config.vision_pp.size["longest_edge"],
                self.config.vision_pp.size["longest_edge"]
            ),
            torch.half
        )


    def default_load_params(self, max_chunk_size):
        return {
            "features_size": (
                self.config.vision_pp.size["longest_edge"] // self.config.vision_pp.patch_size,
                self.config.vision_pp.size["longest_edge"] // self.config.vision_pp.patch_size,
            )
        }


    def get_image_embeddings(
        self,
        tokenizer: Tokenizer,
        image: Image | list[Image],
        text_alias: str | None = None,
    ):
        if isinstance(image, list):
            assert text_alias is None, "Cannot apply single alias to list of images"

            # Images in Mistral3 have uneven numbers of MM tokens so each image is actually processed at bsz 1
            return [self.get_image_embeddings(tokenizer, i) for i in image]

        image_tensor, prep_image_size = self.preprocess(image)
        features_size = (
            prep_image_size[1] // self.config.vision_pp.patch_size,
            prep_image_size[0] // self.config.vision_pp.patch_size,
        )

        # Flattened position ID grid matching inv_freq table
        h, w = features_size
        row_indices = torch.arange(h, dtype = torch.int).unsqueeze(1) * self.max_edge_features
        col_indices = torch.arange(w, dtype = torch.int).unsqueeze(0)
        position_ids_grid = (row_indices + col_indices).flatten().unsqueeze(0)

        embedding_tensor = self.forward(
            image_tensor,
            params = {
                "causal": False,
                "features_size": features_size,
                "inv_freq": self.inv_freq,
                "position_ids": position_ids_grid,
            }
        ).cpu().squeeze(0)

        w //= self.config.vision.spatial_merge_size
        h //= self.config.vision.spatial_merge_size
        id_break = tokenizer.single_id("[IMG_BREAK]")
        id_end = tokenizer.single_id("[IMG_END]")
        token_string = torch.tensor([([-1] * w + [id_break]) * h + [id_end]] , dtype = torch.long)

        mme = MMEmbedding(
            embeddings = embedding_tensor,
            text_alias = text_alias,
            token_string = token_string
        )

        mme.metadata.update({
            "original_size": image.size,
            "preprocessed_size": prep_image_size,
            "model_architecture": self.config.architecture,
        })

        return mme


    @override
    def prepare_inputs(self, input_ids: torch.Tensor, params: dict) -> torch.Tensor:
        return input_ids
