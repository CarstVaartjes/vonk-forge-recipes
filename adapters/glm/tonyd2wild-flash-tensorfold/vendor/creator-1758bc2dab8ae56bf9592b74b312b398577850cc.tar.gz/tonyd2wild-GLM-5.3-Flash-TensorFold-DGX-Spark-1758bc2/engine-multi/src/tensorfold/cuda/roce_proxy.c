// Adapted from b12x (https://github.com/local-inference-lab/b12x), b12x/comm/roce/_roce_proxy.c at commit
// 8a99d639410e39d5f39cb4037675331beceea1d4: "RoCEnante", Copyright the b12x contributors, Apache License 2.0
// (http://www.apache.org/licenses/LICENSE-2.0). Used by tensorfold/cuda/roce.py. Changes from b12x's file (TensorFold,
// 2026-10-01, ABI 5): up to 4 HCAs, a GID index per HCA, and routes: each peer's stripes go over chosen (local HCA,
// peer HCA) pairs (roce_set_route; default HCA h to the peer's HCA h, every HCA), so ranks cabled to each other
// directly (a triangle of Sparks: one /24 and two rails a pair) reach each peer over its own rails only. Flags are
// indexed by stripe (``n_flag`` stripes a peer, the same for every peer).
// TensorFold, 2026-10-05, ABI 6 (Mia's AI Lab): a ring of four (roce_set_ring), for four Sparks cabled to their two
// neighbours without a switch: a rank's payload goes to its neighbours only, each stripe with a length word before
// its flag, and the proxy relays the neighbours' stripes to the rank across the ring (even stripes onward from the
// previous rank to the next, odd ones from the next to the previous), so every peer's flags arrive as before and the
// GPU side is unchanged. A rank posts its next payload only once it has relayed, and the NIC has finished reading,
// everything up to the one before: so a relayed slot is never overwritten while it is still being sent on.
// TensorFold, 2026-10-05 (Mia's AI Lab): the queue pairs' ACK timeout is 20, NCCL's default (b12x's is 14), and
// TF_ROCE_IB_TIMEOUT overrides it.

// RDMA proxy for the b12x RoCE one-shot all-reduce.
//
// One rank owns one pinned host region laid out as:
//
//   recv[src][slot]  (world * SLOTS * slot_bytes)  filled by peers' RDMA writes
//   flag[src][slot][hca] sequence number written on each HCA after that HCA's
//                         payload stripe
//   send[slot]       (SLOTS * slot_bytes)          staged by the local GPU kernel
//   ctrl             (FLAG_STRIDE)                 {u32 seq, u32 nbytes, u32 error,
//                                                   u32 missing_peer} doorbell; the
//                                                  last two are set by the kernel
//                                                  when a wait times out
//
// The GPU kernel stages its input into send[seq & 1], publishes nbytes and seq
// in ctrl, then spins on flag[peer][seq & 1][hca] for every peer and HCA.  The
// proxy thread
// below spins on ctrl.seq and, for every peer, stripes the payload across every
// HCA.  Each stripe is followed by its own 4-byte seq write on the same reliable
// QP, so its flag cannot become visible before its payload.  The GPU waits for
// every stripe flag before consuming the receive slot.  Nothing on the receive
// path involves the host.
//
// This file is compiled by b12x.comm.roce._proxy at first use with the host
// gcc and libibverbs; it must stay plain C with no CUDA dependency.

#define _GNU_SOURCE
#include <errno.h>
#include <infiniband/verbs.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ROCE_MAX_PEERS 16
#define ROCE_MAX_HCAS 4
#define ROCE_SLOTS 2
#define ROCE_FLAG_STRIDE 128
#define ROCE_PORT 1
#define ROCE_SEND_DEPTH 256
#define ROCE_ABI_VERSION 6
#define ROCE_LEN_OFFSET 64            // a stripe flag's length word (ring), in its ROCE_FLAG_STRIDE bytes
#define ROCE_FWD_BIT ((uint64_t)1 << 32)   // wr_id of a relayed stripe
#define ROCE_MAX_RELAY ROCE_MAX_HCAS
// Model graphs leave sub-millisecond gaps between collectives.  Keep the
// proxy hot across those gaps; sleeping there adds one scheduler wakeup to
// every collective on the graph's critical path.
#define ROCE_IDLE_SPINS 20000000

typedef struct {
    uint64_t region_addr;
    uint32_t rkey[ROCE_MAX_HCAS];
    uint16_t lid[ROCE_MAX_HCAS];
    uint8_t gid[ROCE_MAX_HCAS][16];
    uint32_t mtu[ROCE_MAX_HCAS];
    uint32_t qp_num[ROCE_MAX_HCAS][ROCE_MAX_PEERS];
} roce_blob_t;

typedef struct {
    struct ibv_context *ctx;
    struct ibv_pd *pd;
    struct ibv_mr *mr;
    struct ibv_cq *cq;
    struct ibv_qp *qp[ROCE_MAX_PEERS];
    uint32_t outstanding[ROCE_MAX_PEERS];
    uint64_t writes_completed;
    uint64_t bytes_posted;
    union ibv_gid gid;
    uint16_t lid;
    enum ibv_mtu mtu;
} roce_hca_t;

typedef struct {
    int world;
    int rank;
    int n_hca;
    int gid_index[ROCE_MAX_HCAS];
    int traffic_class;
    // routes: stripe s to peer p leaves on local HCA stripe_hca[p][s] for the peer's HCA stripe_remote[p][s]
    int n_stripe[ROCE_MAX_PEERS];
    int stripe_hca[ROCE_MAX_PEERS][ROCE_MAX_HCAS];
    int stripe_remote[ROCE_MAX_PEERS][ROCE_MAX_HCAS];
    int n_flag;                      // stripes (flags) a peer, the same for every peer and on every rank
    // ring (roce_set_ring): relayed[p] for the peer across, reached through the neighbours; relay entry e sends
    // stripe relay_stripe[e] of relay_src[e]'s payload on to relay_dst[e], last done for sequence relay_last[e]
    int ring;
    int relayed[ROCE_MAX_PEERS];
    int n_relay;
    int relay_src[ROCE_MAX_RELAY], relay_stripe[ROCE_MAX_RELAY], relay_dst[ROCE_MAX_RELAY];
    uint32_t relay_last[ROCE_MAX_RELAY];
    uint64_t fwd_outstanding;
    uint64_t fwd_posted;
    roce_hca_t hca[ROCE_MAX_HCAS];
    uint8_t *region;
    size_t region_bytes;
    size_t slot_bytes;
    size_t recv_off;
    size_t flag_off;
    size_t send_off;
    size_t ctrl_off;
    int started;
    uint64_t peer_addr[ROCE_MAX_PEERS];
    uint32_t peer_rkey[ROCE_MAX_HCAS][ROCE_MAX_PEERS];   // by stripe
    pthread_t thread;
    atomic_int running;
    atomic_int failed;
    uint32_t last_seq;
    uint64_t ops_posted;
    uint64_t writes_completed;
    char err[512];
} roce_ctx_t;

void roce_destroy(roce_ctx_t *c);

static void set_err(roce_ctx_t *c, const char *what, int e) {
    snprintf(c->err, sizeof(c->err), "%s: %s", what, e ? strerror(e) : "failed");
}

int roce_abi_version(void) { return ROCE_ABI_VERSION; }

int roce_layout(int world, uint64_t slot_bytes, uint64_t *out) {
    // out = {recv_off, flag_off, send_off, ctrl_off, total_bytes, flag_stride, slots}
    if (world < 2 || world > ROCE_MAX_PEERS || slot_bytes == 0 || (slot_bytes % 4096) != 0) {
        return -1;
    }
    // Reject a layout whose arithmetic would wrap; the caller sizes slots from
    // configuration, so a wrapped region must fail here rather than at the NIC.
    uint64_t recv_bytes, flag_bytes, send_bytes, send_off, ctrl_off, total;
    if (slot_bytes > ((uint64_t)1 << 40) ||
        __builtin_mul_overflow((uint64_t)world * ROCE_SLOTS, slot_bytes, &recv_bytes) ||
        __builtin_mul_overflow(
            (uint64_t)world * ROCE_SLOTS * ROCE_MAX_HCAS,
            (uint64_t)ROCE_FLAG_STRIDE,
            &flag_bytes) ||
        __builtin_mul_overflow((uint64_t)ROCE_SLOTS, slot_bytes, &send_bytes) ||
        __builtin_add_overflow(recv_bytes, flag_bytes, &send_off) ||
        __builtin_add_overflow(send_off, send_bytes, &ctrl_off) ||
        __builtin_add_overflow(ctrl_off, (uint64_t)ROCE_FLAG_STRIDE, &total)) {
        return -1;
    }
    uint64_t recv_off = 0;
    uint64_t flag_off = recv_off + recv_bytes;
    out[0] = recv_off;
    out[1] = flag_off;
    out[2] = send_off;
    out[3] = ctrl_off;
    out[4] = total;
    out[5] = ROCE_FLAG_STRIDE;
    out[6] = ROCE_SLOTS;
    return 0;
}

uint64_t roce_blob_bytes(void) { return sizeof(roce_blob_t); }

static int open_hca(roce_ctx_t *c, int h, const char *name) {
    int num = 0;
    struct ibv_device **list = ibv_get_device_list(&num);
    if (list == NULL) {
        set_err(c, "ibv_get_device_list", errno);
        return -1;
    }
    struct ibv_device *dev = NULL;
    for (int i = 0; i < num; i++) {
        if (strcmp(ibv_get_device_name(list[i]), name) == 0) {
            dev = list[i];
            break;
        }
    }
    if (dev == NULL) {
        ibv_free_device_list(list);
        snprintf(c->err, sizeof(c->err), "RDMA device %s not found", name);
        return -1;
    }
    roce_hca_t *hca = &c->hca[h];
    hca->ctx = ibv_open_device(dev);
    ibv_free_device_list(list);
    if (hca->ctx == NULL) {
        set_err(c, "ibv_open_device", errno);
        return -1;
    }
    struct ibv_port_attr port;
    if (ibv_query_port(hca->ctx, ROCE_PORT, &port) != 0) {
        set_err(c, "ibv_query_port", errno);
        return -1;
    }
    if (port.state != IBV_PORT_ACTIVE) {
        snprintf(c->err, sizeof(c->err), "RDMA device %s port %d is not active", name, ROCE_PORT);
        return -1;
    }
    hca->lid = port.lid;
    hca->mtu = port.active_mtu;
    if (ibv_query_gid(hca->ctx, ROCE_PORT, c->gid_index[h], &hca->gid) != 0) {
        set_err(c, "ibv_query_gid", errno);
        return -1;
    }
    hca->pd = ibv_alloc_pd(hca->ctx);
    if (hca->pd == NULL) {
        set_err(c, "ibv_alloc_pd", errno);
        return -1;
    }
    hca->mr = ibv_reg_mr(hca->pd, c->region, c->region_bytes,
                         IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE);
    if (hca->mr == NULL) {
        set_err(c, "ibv_reg_mr(pinned region)", errno);
        return -1;
    }
    hca->cq = ibv_create_cq(hca->ctx, ROCE_SEND_DEPTH * ROCE_MAX_PEERS, NULL, NULL, 0);
    if (hca->cq == NULL) {
        set_err(c, "ibv_create_cq", errno);
        return -1;
    }
    for (int p = 0; p < c->world; p++) {
        if (p == c->rank) {
            continue;
        }
        struct ibv_qp_init_attr attr;
        memset(&attr, 0, sizeof(attr));
        attr.send_cq = hca->cq;
        attr.recv_cq = hca->cq;
        attr.qp_type = IBV_QPT_RC;
        attr.cap.max_send_wr = ROCE_SEND_DEPTH;
        attr.cap.max_recv_wr = 1;
        attr.cap.max_send_sge = 1;
        attr.cap.max_recv_sge = 1;
        attr.cap.max_inline_data = 16;
        hca->qp[p] = ibv_create_qp(hca->pd, &attr);
        if (hca->qp[p] == NULL) {
            set_err(c, "ibv_create_qp", errno);
            return -1;
        }
        struct ibv_qp_attr init;
        memset(&init, 0, sizeof(init));
        init.qp_state = IBV_QPS_INIT;
        init.pkey_index = 0;
        init.port_num = ROCE_PORT;
        init.qp_access_flags = IBV_ACCESS_REMOTE_WRITE;
        int rc = ibv_modify_qp(hca->qp[p], &init,
                               IBV_QP_STATE | IBV_QP_PKEY_INDEX | IBV_QP_PORT | IBV_QP_ACCESS_FLAGS);
        if (rc != 0) {
            set_err(c, "ibv_modify_qp(INIT)", rc);
            return -1;
        }
    }
    return 0;
}

roce_ctx_t *roce_create(int world, int rank, const char *const *hca_names, int n_hca,
                        const int *gid_index, int traffic_class, void *region, uint64_t region_bytes,
                        uint64_t slot_bytes, char *err, uint64_t err_len) {
    uint64_t layout[7];
    if (roce_layout(world, slot_bytes, layout) != 0 || layout[4] > region_bytes ||
        rank < 0 || rank >= world || n_hca < 1 || n_hca > ROCE_MAX_HCAS ||
        traffic_class < 0 || traffic_class > 255) {
        snprintf(err, err_len, "invalid roce runtime geometry");
        return NULL;
    }
    roce_ctx_t *c = calloc(1, sizeof(*c));
    if (c == NULL) {
        snprintf(err, err_len, "out of memory");
        return NULL;
    }
    c->world = world;
    c->rank = rank;
    c->n_hca = n_hca;
    for (int h = 0; h < n_hca; h++) {
        c->gid_index[h] = gid_index[h];
    }
    for (int p = 0; p < world; p++) {           // default routes: HCA h to the peer's HCA h, every HCA
        c->n_stripe[p] = p == rank ? 0 : n_hca;
        for (int h = 0; h < n_hca; h++) {
            c->stripe_hca[p][h] = h;
            c->stripe_remote[p][h] = h;
        }
    }
    c->n_flag = n_hca;
    c->traffic_class = traffic_class;
    c->region = region;
    c->region_bytes = region_bytes;
    c->slot_bytes = slot_bytes;
    c->recv_off = layout[0];
    c->flag_off = layout[1];
    c->send_off = layout[2];
    c->ctrl_off = layout[3];
    for (int h = 0; h < n_hca; h++) {
        if (open_hca(c, h, hca_names[h]) != 0) {
            snprintf(err, err_len, "%s", c->err);
            roce_destroy(c);
            return NULL;
        }
    }
    return c;
}

int roce_set_routes(roce_ctx_t *c, int peer, int n, const int *local, const int *remote, int n_flag) {
    // before roce_connect: peer's stripes (n of them) over (local[s], remote[s]); n_flag: the stripes every peer has
    if (c->started || peer < 0 || peer >= c->world || peer == c->rank || n < 1 || n > ROCE_MAX_HCAS ||
        n != n_flag || n_flag > ROCE_MAX_HCAS) {
        snprintf(c->err, sizeof(c->err), "invalid RoCE route to rank %d (%d stripes, %d a peer)", peer, n, n_flag);
        return -1;
    }
    for (int s = 0; s < n; s++) {
        if (local[s] < 0 || local[s] >= c->n_hca || remote[s] < 0 || remote[s] >= ROCE_MAX_HCAS) {
            snprintf(c->err, sizeof(c->err), "invalid RoCE route to rank %d: stripe %d", peer, s);
            return -1;
        }
        c->stripe_hca[peer][s] = local[s];
        c->stripe_remote[peer][s] = remote[s];
    }
    c->n_stripe[peer] = n;
    c->n_flag = n_flag;
    return 0;
}

int roce_set_ring(roce_ctx_t *c) {
    // after roce_set_routes to both neighbours, before roce_connect: four ranks in a ring in rank order, each cabled
    // to rank - 1 and rank + 1 only
    const int w = c->world, prev = (c->rank + w - 1) % w, next = (c->rank + 1) % w, across = (c->rank + 2) % w;
    if (c->started || w != 4 || c->n_stripe[prev] != c->n_flag || c->n_stripe[next] != c->n_flag ||
        c->n_flag > ROCE_MAX_RELAY) {
        snprintf(c->err, sizeof(c->err), "RoCE ring: four ranks, routes to both neighbours with %d stripes each",
                 c->n_flag);
        return -1;
    }
    c->ring = 1;
    c->relayed[across] = 1;
    c->n_stripe[across] = 0;
    c->n_relay = c->n_flag;
    for (int s = 0; s < c->n_flag; s++) {
        c->relay_stripe[s] = s;
        c->relay_src[s] = (s % 2 == 0) ? prev : next;
        c->relay_dst[s] = (s % 2 == 0) ? next : prev;
    }
    return 0;
}

int roce_local_blob(roce_ctx_t *c, void *out, uint64_t out_len) {
    if (out_len < sizeof(roce_blob_t)) {
        return -1;
    }
    roce_blob_t blob;
    memset(&blob, 0, sizeof(blob));
    blob.region_addr = (uint64_t)(uintptr_t)c->region;
    for (int h = 0; h < c->n_hca; h++) {
        blob.rkey[h] = c->hca[h].mr->rkey;
        blob.lid[h] = c->hca[h].lid;
        blob.mtu[h] = (uint32_t)c->hca[h].mtu;
        memcpy(blob.gid[h], c->hca[h].gid.raw, 16);
        for (int p = 0; p < c->world; p++) {
            blob.qp_num[h][p] = (p == c->rank) ? 0 : c->hca[h].qp[p]->qp_num;
        }
    }
    memcpy(out, &blob, sizeof(blob));
    return 0;
}

static uint8_t roce_ib_timeout(void) {
    const char *v = getenv("TF_ROCE_IB_TIMEOUT");
    int t = (v && *v) ? atoi(v) : 20;
    return (uint8_t)((t >= 1 && t <= 31) ? t : 20);
}

static int connect_qp(roce_ctx_t *c, int h, int p, const roce_blob_t *peer, int rh) {
    // local HCA h's QP for peer p <-> the peer's HCA rh's QP for this rank
    roce_hca_t *hca = &c->hca[h];
    struct ibv_qp_attr rtr;
    memset(&rtr, 0, sizeof(rtr));
    rtr.qp_state = IBV_QPS_RTR;
    rtr.path_mtu = (enum ibv_mtu)(peer->mtu[rh] < (uint32_t)hca->mtu ? peer->mtu[rh] : (uint32_t)hca->mtu);
    rtr.dest_qp_num = peer->qp_num[rh][c->rank];
    rtr.rq_psn = 0;
    rtr.max_dest_rd_atomic = 1;
    rtr.min_rnr_timer = 12;
    rtr.ah_attr.is_global = 1;
    rtr.ah_attr.dlid = peer->lid[rh];
    rtr.ah_attr.sl = 0;
    rtr.ah_attr.src_path_bits = 0;
    rtr.ah_attr.port_num = ROCE_PORT;
    memcpy(rtr.ah_attr.grh.dgid.raw, peer->gid[rh], 16);
    rtr.ah_attr.grh.sgid_index = (uint8_t)c->gid_index[h];
    rtr.ah_attr.grh.hop_limit = 64;
    rtr.ah_attr.grh.traffic_class = (uint8_t)c->traffic_class;
    rtr.ah_attr.grh.flow_label = 0;
    int rc = ibv_modify_qp(hca->qp[p], &rtr,
                           IBV_QP_STATE | IBV_QP_AV | IBV_QP_PATH_MTU | IBV_QP_DEST_QPN |
                               IBV_QP_RQ_PSN | IBV_QP_MAX_DEST_RD_ATOMIC | IBV_QP_MIN_RNR_TIMER);
    if (rc != 0) {
        set_err(c, "ibv_modify_qp(RTR)", rc);
        return -1;
    }
    struct ibv_qp_attr rts;
    memset(&rts, 0, sizeof(rts));
    rts.qp_state = IBV_QPS_RTS;
    // ACK timeout 4.096 us x 2^timeout a try, 7 retries: 14 (b12x's) gave up after ~0.5 s without ACKs, which a
    // four-Spark ring's link once stalled for while NCCL (its default 20: ~4 s a try) rode it out; TF_ROCE_IB_TIMEOUT
    // overrides it (1-31)
    rts.timeout = roce_ib_timeout();
    rts.retry_cnt = 7;
    rts.rnr_retry = 7;
    rts.sq_psn = 0;
    rts.max_rd_atomic = 1;
    rc = ibv_modify_qp(hca->qp[p], &rts,
                       IBV_QP_STATE | IBV_QP_TIMEOUT | IBV_QP_RETRY_CNT | IBV_QP_RNR_RETRY |
                           IBV_QP_SQ_PSN | IBV_QP_MAX_QP_RD_ATOMIC);
    if (rc != 0) {
        set_err(c, "ibv_modify_qp(RTS)", rc);
        return -1;
    }
    return 0;
}

int roce_connect(roce_ctx_t *c, const void *blobs, uint64_t blobs_len) {
    if (blobs_len < sizeof(roce_blob_t) * (uint64_t)c->world) {
        snprintf(c->err, sizeof(c->err), "peer blob buffer too small");
        return -1;
    }
    const roce_blob_t *all = (const roce_blob_t *)blobs;
    for (int p = 0; p < c->world; p++) {
        if (p == c->rank) {
            continue;
        }
        c->peer_addr[p] = all[p].region_addr;
        if (c->relayed[p]) {
            continue;
        }
        if (c->n_stripe[p] != c->n_flag) {
            snprintf(c->err, sizeof(c->err), "rank %d has %d stripes, every peer needs %d", p, c->n_stripe[p],
                     c->n_flag);
            return -1;
        }
        for (int s = 0; s < c->n_stripe[p]; s++) {
            const int h = c->stripe_hca[p][s], rh = c->stripe_remote[p][s];
            c->peer_rkey[s][p] = all[p].rkey[rh];
            if (connect_qp(c, h, p, &all[p], rh) != 0) {
                return -1;
            }
        }
    }
    return 0;
}

static int drain_cq(roce_ctx_t *c, int h) {
    struct ibv_wc wc[32];
    int n = ibv_poll_cq(c->hca[h].cq, 32, wc);
    if (n < 0) {
        set_err(c, "ibv_poll_cq", errno);
        return -1;
    }
    for (int i = 0; i < n; i++) {
        if (wc[i].status != IBV_WC_SUCCESS) {
            snprintf(c->err, sizeof(c->err),
                     "RDMA write to rank %u failed: %s (vendor_err 0x%x, seq %u)",
                     (unsigned)(wc[i].wr_id & 0xffu), ibv_wc_status_str(wc[i].status),
                     wc[i].vendor_err, c->last_seq);
            return -1;
        }
        c->hca[h].outstanding[wc[i].wr_id & 0xffu] -= 1;
        if (wc[i].wr_id & ROCE_FWD_BIT) {
            c->fwd_outstanding -= 1;
        }
        c->hca[h].writes_completed += 1;
        c->writes_completed += 1;
    }
    return 0;
}

static int post_op(roce_ctx_t *c, uint32_t seq, uint32_t nbytes) {
    if (nbytes == 0 || nbytes % 16 != 0) {
        snprintf(c->err, sizeof(c->err),
                 "RoCE payload size must be a positive multiple of 16 bytes, got %u",
                 nbytes);
        return -1;
    }
    uint32_t slot = seq & 1u;
    uint8_t *send = c->region + c->send_off + (size_t)slot * c->slot_bytes;
    uint32_t seq_copy = seq;
    uint32_t len_copy = nbytes;
    uint32_t total_packs = nbytes / 16;
    for (int p = 0; p < c->world; p++) {
        if (p == c->rank || c->relayed[p]) {
            continue;
        }
        uint32_t pack_offset = 0;
        const int n_stripe = c->n_stripe[p];
        for (int s = 0; s < n_stripe; s++) {
            const int h = c->stripe_hca[p][s];
            roce_hca_t *hca = &c->hca[h];
            // Two work requests per stripe; keep the queue at most a quarter
            // full so a provider that needs extra entries can never fail a post.
            while (hca->outstanding[p] >= ROCE_SEND_DEPTH / 4) {
                if (drain_cq(c, h) != 0) {
                    return -1;
                }
                // A peer that stopped acknowledging keeps the QP retrying for
                // a long time; honour a stop request instead of blocking
                // roce_stop (and so teardown) behind it.
                if (!atomic_load_explicit(&c->running, memory_order_relaxed)) {
                    snprintf(c->err, sizeof(c->err),
                             "RoCE proxy stopped with %u writes outstanding to rank %d",
                             hca->outstanding[p], p);
                    return -1;
                }
            }
            uint32_t stripe_packs = total_packs / (uint32_t)n_stripe;
            if ((uint32_t)s < total_packs % (uint32_t)n_stripe) {
                stripe_packs += 1;
            }
            uint32_t stripe_bytes = stripe_packs * 16;
            uint64_t byte_offset = (uint64_t)pack_offset * 16;
            uint64_t remote = c->peer_addr[p];
            struct ibv_sge flag_sge = {
                .addr = (uint64_t)(uintptr_t)&seq_copy,
                .length = 4,
                .lkey = 0,
            };
            struct ibv_send_wr flag_wr;
            memset(&flag_wr, 0, sizeof(flag_wr));
            flag_wr.wr_id = (uint64_t)p;
            flag_wr.sg_list = &flag_sge;
            flag_wr.num_sge = 1;
            flag_wr.opcode = IBV_WR_RDMA_WRITE;
            flag_wr.send_flags = IBV_SEND_SIGNALED | IBV_SEND_INLINE;
            flag_wr.wr.rdma.remote_addr =
                remote + c->flag_off +
                (((uint64_t)c->rank * ROCE_SLOTS + slot) * (uint64_t)c->n_flag +
                 (uint64_t)s) * ROCE_FLAG_STRIDE;
            flag_wr.wr.rdma.rkey = c->peer_rkey[s][p];

            struct ibv_send_wr data_wr;
            struct ibv_sge data_sge;
            struct ibv_send_wr *first_wr = &flag_wr;
            // ring: the payload's length ahead of the flag, for the neighbour that relays this stripe on
            struct ibv_sge len_sge = {.addr = (uint64_t)(uintptr_t)&len_copy, .length = 4, .lkey = 0};
            struct ibv_send_wr len_wr;
            if (c->ring) {
                memset(&len_wr, 0, sizeof(len_wr));
                len_wr.wr_id = (uint64_t)p;
                len_wr.next = &flag_wr;
                len_wr.sg_list = &len_sge;
                len_wr.num_sge = 1;
                len_wr.opcode = IBV_WR_RDMA_WRITE;
                len_wr.send_flags = IBV_SEND_INLINE;
                len_wr.wr.rdma.remote_addr = flag_wr.wr.rdma.remote_addr + ROCE_LEN_OFFSET;
                len_wr.wr.rdma.rkey = c->peer_rkey[s][p];
                first_wr = &len_wr;
            }
            if (stripe_bytes != 0) {
                data_sge = (struct ibv_sge){
                    .addr = (uint64_t)(uintptr_t)(send + byte_offset),
                    .length = stripe_bytes,
                    .lkey = hca->mr->lkey,
                };
                memset(&data_wr, 0, sizeof(data_wr));
                data_wr.wr_id = (uint64_t)p;
                data_wr.next = first_wr;
                data_wr.sg_list = &data_sge;
                data_wr.num_sge = 1;
                data_wr.opcode = IBV_WR_RDMA_WRITE;
                data_wr.wr.rdma.remote_addr =
                    remote + c->recv_off +
                    ((uint64_t)c->rank * ROCE_SLOTS + slot) * c->slot_bytes +
                    byte_offset;
                data_wr.wr.rdma.rkey = c->peer_rkey[s][p];
                first_wr = &data_wr;
            }
            struct ibv_send_wr *bad = NULL;
            int rc = ibv_post_send(hca->qp[p], first_wr, &bad);
            if (rc != 0) {
                set_err(c, "ibv_post_send", rc);
                return -1;
            }
            hca->outstanding[p] += 1;
            hca->bytes_posted += stripe_bytes;
            pack_offset += stripe_packs;
        }
    }
    c->ops_posted += 1;
    for (int h = 0; h < c->n_hca; h++) {
        if (drain_cq(c, h) != 0) {
            return -1;
        }
    }
    return 0;
}

// stripe s's [byte offset, bytes) of an n-byte payload split into n_stripe stripes (post_op's split)
static void stripe_range(uint32_t nbytes, int n_stripe, int s, uint64_t *offset, uint32_t *bytes) {
    const uint32_t total = nbytes / 16, base = total / (uint32_t)n_stripe, extra = total % (uint32_t)n_stripe;
    uint32_t start = 0;
    for (int i = 0; i < s; i++) {
        start += base + ((uint32_t)i < extra ? 1u : 0u);
    }
    *offset = (uint64_t)start * 16;
    *bytes = (base + ((uint32_t)s < extra ? 1u : 0u)) * 16;
}

// relay entry e's stripe of sequence seq (arrived here in recv[src][slot]) on to dst, at the same place there
static int forward(roce_ctx_t *c, int e, uint32_t seq) {
    const int src = c->relay_src[e], s = c->relay_stripe[e], dst = c->relay_dst[e];
    const uint32_t slot = seq & 1u;
    const uint64_t flag_index = (((uint64_t)src * ROCE_SLOTS + slot) * (uint64_t)c->n_flag + (uint64_t)s);
    volatile uint32_t *len = (volatile uint32_t *)(c->region + c->flag_off + flag_index * ROCE_FLAG_STRIDE +
                                                   ROCE_LEN_OFFSET);
    const uint32_t nbytes = __atomic_load_n(len, __ATOMIC_ACQUIRE);
    if (nbytes == 0 || nbytes % 16 != 0 || nbytes > c->slot_bytes) {
        snprintf(c->err, sizeof(c->err), "RoCE ring: rank %d's payload length %u (seq %u) is invalid", src, nbytes,
                 seq);
        return -1;
    }
    uint64_t offset;
    uint32_t bytes;
    stripe_range(nbytes, c->n_flag, s, &offset, &bytes);
    const int h = c->stripe_hca[dst][s];
    roce_hca_t *hca = &c->hca[h];
    while (hca->outstanding[dst] >= ROCE_SEND_DEPTH / 4) {
        if (drain_cq(c, h) != 0) {
            return -1;
        }
        if (!atomic_load_explicit(&c->running, memory_order_relaxed)) {
            snprintf(c->err, sizeof(c->err), "RoCE proxy stopped while relaying to rank %d", dst);
            return -1;
        }
    }
    uint32_t seq_copy = seq;
    const uint64_t remote = c->peer_addr[dst];
    struct ibv_sge flag_sge = {.addr = (uint64_t)(uintptr_t)&seq_copy, .length = 4, .lkey = 0};
    struct ibv_send_wr flag_wr;
    memset(&flag_wr, 0, sizeof(flag_wr));
    flag_wr.wr_id = (uint64_t)dst | ROCE_FWD_BIT;
    flag_wr.sg_list = &flag_sge;
    flag_wr.num_sge = 1;
    flag_wr.opcode = IBV_WR_RDMA_WRITE;
    flag_wr.send_flags = IBV_SEND_SIGNALED | IBV_SEND_INLINE;
    flag_wr.wr.rdma.remote_addr = remote + c->flag_off + flag_index * ROCE_FLAG_STRIDE;
    flag_wr.wr.rdma.rkey = c->peer_rkey[s][dst];
    struct ibv_send_wr data_wr, *first_wr = &flag_wr;
    struct ibv_sge data_sge;
    if (bytes != 0) {
        const uint64_t at = c->recv_off + ((uint64_t)src * ROCE_SLOTS + slot) * c->slot_bytes + offset;
        data_sge = (struct ibv_sge){.addr = (uint64_t)(uintptr_t)(c->region + at), .length = bytes,
                                    .lkey = hca->mr->lkey};
        memset(&data_wr, 0, sizeof(data_wr));
        data_wr.wr_id = (uint64_t)dst | ROCE_FWD_BIT;
        data_wr.next = &flag_wr;
        data_wr.sg_list = &data_sge;
        data_wr.num_sge = 1;
        data_wr.opcode = IBV_WR_RDMA_WRITE;
        data_wr.wr.rdma.remote_addr = remote + at;
        data_wr.wr.rdma.rkey = c->peer_rkey[s][dst];
        first_wr = &data_wr;
    }
    struct ibv_send_wr *bad = NULL;
    int rc = ibv_post_send(hca->qp[dst], first_wr, &bad);
    if (rc != 0) {
        set_err(c, "ibv_post_send(relay)", rc);
        return -1;
    }
    hca->outstanding[dst] += 1;
    hca->bytes_posted += bytes;
    c->fwd_outstanding += 1;
    c->fwd_posted += 1;
    return 0;
}

// relay every stripe that has arrived (until: 0), or every one up to sequence ``until``, waiting for those (they
// have arrived: this rank's kernel for that sequence waited on them); returns how many were relayed, -1 on failure
static int relay(roce_ctx_t *c, uint32_t until) {
    int done = 0;
    for (int e = 0; e < c->n_relay; e++) {
        for (;;) {
            const uint32_t seq = c->relay_last[e] + 1;
            if (until != 0 && (int32_t)(seq - until) > 0) {
                break;
            }
            const uint64_t flag_index = (((uint64_t)c->relay_src[e] * ROCE_SLOTS + (seq & 1u)) * (uint64_t)c->n_flag +
                                         (uint64_t)c->relay_stripe[e]);
            volatile uint32_t *flag = (volatile uint32_t *)(c->region + c->flag_off + flag_index * ROCE_FLAG_STRIDE);
            if (__atomic_load_n(flag, __ATOMIC_ACQUIRE) != seq) {
                if (until == 0) {
                    break;
                }
                if (!atomic_load_explicit(&c->running, memory_order_relaxed)) {
                    snprintf(c->err, sizeof(c->err), "RoCE proxy stopped waiting to relay rank %d's seq %u",
                             c->relay_src[e], seq);
                    return -1;
                }
                continue;
            }
            if (forward(c, e, seq) != 0) {
                return -1;
            }
            c->relay_last[e] = seq;
            done++;
        }
    }
    return done;
}

// every relayed stripe read out by the NIC (its signaled flag completed)
static int relays_drained(roce_ctx_t *c) {
    while (c->fwd_outstanding != 0) {
        for (int h = 0; h < c->n_hca; h++) {
            if (drain_cq(c, h) != 0) {
                return -1;
            }
        }
        if (!atomic_load_explicit(&c->running, memory_order_relaxed)) {
            snprintf(c->err, sizeof(c->err), "RoCE proxy stopped with %llu relays outstanding",
                     (unsigned long long)c->fwd_outstanding);
            return -1;
        }
    }
    return 0;
}

static void *proxy_main(void *arg) {
    roce_ctx_t *c = (roce_ctx_t *)arg;
    volatile uint32_t *ctrl = (volatile uint32_t *)(c->region + c->ctrl_off);
    // Spin while ops are flowing.  After ROCE_IDLE_SPINS polls without a
    // doorbell, request a short nanosleep between polls (the OS decides the
    // actual delay) so an idle runtime does not hold a core next to the
    // serving process.  The missed-doorbell catch-up below keeps the protocol
    // correct however long the thread is away.
    uint64_t idle = 0;
    const struct timespec nap = {0, 20000};
    while (atomic_load_explicit(&c->running, memory_order_relaxed)) {
        if (c->ring) {
            int n = relay(c, 0);
            if (n < 0) {
                atomic_store(&c->failed, 1);
                return NULL;
            }
            if (n > 0) {
                idle = 0;
            }
        }
        uint32_t seq = __atomic_load_n(&ctrl[0], __ATOMIC_ACQUIRE);
        if (seq == c->last_seq) {
            idle++;
            if (idle % 64 == 0) {
                for (int h = 0; h < c->n_hca; h++) {
                    if (drain_cq(c, h) != 0) {
                        atomic_store(&c->failed, 1);
                        return NULL;
                    }
                }
            }
            if (idle >= ROCE_IDLE_SPINS) {
                nanosleep(&nap, NULL);
            }
            continue;
        }
        idle = 0;
        // The doorbell holds only the newest sequence.  Our kernel for op N
        // completes on the peers' payloads alone, so op N+1 can ring before
        // this thread has seen op N (it slept, or the scheduler moved it).
        // Peers cannot get further than one op ahead of us, so at most
        // ROCE_SLOTS doorbells are pending and every send slot is intact:
        // post each missed sequence in order using its per-slot byte count.
        uint32_t pending = seq - c->last_seq;
        if (pending > ROCE_SLOTS) {
            snprintf(c->err, sizeof(c->err),
                     "doorbell skipped %u ops (last %u, now %u)", pending, c->last_seq, seq);
            atomic_store(&c->failed, 1);
            return NULL;
        }
        for (uint32_t s = c->last_seq + 1; pending > 0; s++, pending--) {
            uint32_t nbytes = ctrl[4 + (s & 1u)];
            // ring: sequence s - 1's relays posted and read out first, so no neighbour's s + 1 (which waits on
            // this payload) can overwrite a slot that is still being relayed
            if (c->ring && s != 1 && (relay(c, s - 1) < 0 || relays_drained(c) != 0)) {
                atomic_store(&c->failed, 1);
                return NULL;
            }
            if (post_op(c, s, nbytes) != 0) {
                atomic_store(&c->failed, 1);
                return NULL;
            }
            c->last_seq = s;
        }
    }
    return NULL;
}

int roce_start(roce_ctx_t *c) {
    if (atomic_load(&c->running)) {
        return 0;
    }
    if (!c->started) {
        // A restart continues from the last posted sequence so ops that rang
        // the doorbell while the thread was stopped are still posted.
        volatile uint32_t *ctrl = (volatile uint32_t *)(c->region + c->ctrl_off);
        c->last_seq = ctrl[0];
        for (int e = 0; e < c->n_relay; e++) {
            c->relay_last[e] = c->last_seq;
        }
        c->started = 1;
    }
    atomic_store(&c->failed, 0);
    atomic_store(&c->running, 1);
    int rc = pthread_create(&c->thread, NULL, proxy_main, c);
    if (rc != 0) {
        atomic_store(&c->running, 0);
        set_err(c, "pthread_create", rc);
        return -1;
    }
    return 0;
}

void roce_stop(roce_ctx_t *c) {
    if (atomic_exchange(&c->running, 0)) {
        pthread_join(c->thread, NULL);
    }
}

int roce_failed(roce_ctx_t *c) { return atomic_load(&c->failed); }

const char *roce_error(roce_ctx_t *c) { return c->err; }

uint64_t roce_stat(roce_ctx_t *c, int which) {
    switch (which) {
    case 0:
        return c->ops_posted;
    case 1:
        return c->writes_completed;
    case 2:
        return c->last_seq;
    case 3:
        return c->fwd_posted;
    default:
        return 0;
    }
}

uint64_t roce_hca_stat(roce_ctx_t *c, int hca, int which) {
    if (hca < 0 || hca >= c->n_hca) {
        return -1;
    }
    switch (which) {
    case 0:
        return c->hca[hca].writes_completed;
    case 1:
        return c->hca[hca].bytes_posted;
    default:
        return 0;
    }
}

void roce_destroy(roce_ctx_t *c) {
    if (c == NULL) {
        return;
    }
    roce_stop(c);
    for (int h = 0; h < ROCE_MAX_HCAS; h++) {
        roce_hca_t *hca = &c->hca[h];
        for (int p = 0; p < ROCE_MAX_PEERS; p++) {
            if (hca->qp[p] != NULL) {
                ibv_destroy_qp(hca->qp[p]);
            }
        }
        if (hca->cq != NULL) {
            ibv_destroy_cq(hca->cq);
        }
        if (hca->mr != NULL) {
            ibv_dereg_mr(hca->mr);
        }
        if (hca->pd != NULL) {
            ibv_dealloc_pd(hca->pd);
        }
        if (hca->ctx != NULL) {
            ibv_close_device(hca->ctx);
        }
    }
    free(c);
}
