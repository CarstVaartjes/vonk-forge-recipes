"""Resolve local model directories or Hugging Face snapshots, downloading missing weights when requested."""

from __future__ import annotations

import json
from pathlib import Path
import re
from typing import Any

_REPO_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*/[A-Za-z0-9][A-Za-z0-9._-]*$")


def is_repo_id(name: str) -> bool:
    """``owner/name`` that is not an existing local path."""

    return bool(_REPO_ID.match(str(name))) and not Path(str(name)).expanduser().exists()


def cached(repo_id: str, *, cache_dir: Any = None) -> Path | None:
    """Use the cached snapshot, falling back to the newest config-bearing snapshot when refs/main is absent."""

    from huggingface_hub import snapshot_download

    try:
        return Path(snapshot_download(repo_id, local_files_only=True, cache_dir=cache_dir))
    except Exception:  # noqa: BLE001 - not cached, or cached without a ref: look at the snapshots themselves
        pass
    if cache_dir is None:
        from huggingface_hub import constants

        cache_dir = constants.HF_HUB_CACHE
    snapshots = Path(cache_dir) / f"models--{repo_id.replace('/', '--')}" / "snapshots"
    found = [s for s in snapshots.glob("*") if (s / "config.json").is_file()] if snapshots.is_dir() else []
    return max(found, key=lambda s: s.stat().st_mtime) if found else None


def pull(repo_id: str, *, cache_dir: Any = None) -> Path:
    """Download (or finish downloading) a repo into the cache; returns its snapshot directory."""

    from huggingface_hub import snapshot_download

    print(f"[tensorfold] downloading {repo_id} from Hugging Face", flush=True)
    return Path(snapshot_download(repo_id, cache_dir=cache_dir))


def _cached_weights_complete(snapshot: Path, *, required_files: tuple[str, ...] = ()) -> bool:
    """Require complete weights before serving because Hugging Face also returns partial local snapshots."""

    if not all((snapshot / name).is_file() for name in required_files):
        return False

    index = snapshot / "model.safetensors.index.json"
    if index.is_file():
        try:
            weight_map = json.loads(index.read_text())["weight_map"]
        except (OSError, ValueError, KeyError, TypeError):
            return False
        if not isinstance(weight_map, dict) or not weight_map:
            return False
        try:
            files = set(weight_map.values())
        except TypeError:
            return False
        return all(isinstance(name, str) and not Path(name).is_absolute() and ".." not in Path(name).parts
                   and (snapshot / name).is_file() for name in files)

    shards = list(snapshot.glob("model-*-of-*.safetensors"))
    if shards:
        matches = [re.fullmatch(r"model-(\d+)-of-(\d+)\.safetensors", path.name) for path in shards]
        if not all(matches):
            return False
        totals = {int(match.group(2)) for match in matches}
        if len(totals) != 1:
            return False
        total = totals.pop()
        return len(shards) == total and {int(match.group(1)) for match in matches} == set(range(1, total + 1))

    return (snapshot / "model.safetensors").is_file()


def resolve(name: str, *, download: bool = True, cache_dir: Any = None,
            required_files: tuple[str, ...] = ()) -> Path:
    """A model directory for ``name``: the directory itself, or a repo id's snapshot (downloaded if needed)."""

    path = Path(str(name)).expanduser()
    if path.is_dir():
        return path
    if not is_repo_id(str(name)):
        raise FileNotFoundError(f"{name} is neither a directory nor a Hugging Face repo id (owner/name)")
    found = cached(str(name), cache_dir=cache_dir)
    if found is not None and (found / "config.json").is_file() and (
        not download or _cached_weights_complete(found, required_files=required_files)
    ):
        return found
    if not download:
        raise FileNotFoundError(f"{name} is not in the Hugging Face cache; run: tensorfold pull {name}")
    downloaded = pull(str(name), cache_dir=cache_dir)
    if required_files and not _cached_weights_complete(downloaded, required_files=required_files):
        raise FileNotFoundError(f"{name} is missing required files: {', '.join(required_files)}")
    return downloaded


def size_of(directory: Path) -> int:
    """Bytes of the files under ``directory`` (following the cache's symlinks)."""

    return sum(p.stat().st_size for p in Path(directory).rglob("*") if p.is_file())
